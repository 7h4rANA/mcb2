require("dotenv").config();
const logger = require("./src/logger");

const REQUIRED = [
  "DISCORD_TOKEN",
  "OWNER_ID",
  "LOG_CHANNEL_ID",
  "COMMAND_CHANNEL_ID",
  "CHAT_CHANNEL_ID",
  "MC_EMAIL",
  "MC_HOST",
];
const missing = REQUIRED.filter((k) => !process.env[k]);
if (missing.length) {
  logger.error("Missing required .env values:", missing.join(", "));
  logger.error("Copy .env.example to .env and fill it in - see README.md.");
  process.exit(1);
}

const mc = require("./src/minecraftBot");
const discord = require("./src/discordBot");
require("./src/ramWatchdog").start();

process.on("uncaughtException", (err) => logger.error("uncaughtException:", err));
process.on("unhandledRejection", (err) => logger.error("unhandledRejection:", err));

function shutdown(signal) {
  logger.info(`${signal} received, shutting down cleanly...`);
  try {
    mc.stopBot(`process ${signal}`);
  } catch {}
  setTimeout(() => process.exit(0), 500);
}
process.on("SIGINT", () => shutdown("SIGINT"));
process.on("SIGTERM", () => shutdown("SIGTERM"));

discord
  .login()
  .then(() => logger.info("Discord login OK. Waiting for !start (or auto-resuming a previous session)."))
  .catch((err) => {
    logger.error("Discord login failed:", err.message);
    process.exit(1);
  });
