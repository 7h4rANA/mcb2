'use strict'
const config = require('./src/config')
const log = require('./src/logger')
const McBotManager = require('./src/mcBot')
const { createDiscordBot } = require('./src/discordBot')

let discord // forward-declared so hooks below can use it once created

const mcBot = new McBotManager(config.minecraft, log, {
  onMsaCode: (data) => {
    // First run only (until auth_cache/ has a cached token): forward the
    // Microsoft device-code login to Discord so you don't have to watch
    // the VPS console.
    if (discord) discord.notifyChannel(`**Microsoft sign-in required**\n${data.message}`)
  },
  onSpawn: () => {
    if (discord) discord.notifyChannel('🟢 Minecraft bot connected.')
  },
  onEnd: (status) => {
    if (discord) {
      const reason = status.lastKickReason || status.lastError
      discord.notifyChannel(`🔴 Minecraft bot disconnected${reason ? `: ${reason}` : '.'}`)
    }
  }
})

discord = createDiscordBot(config.discord, mcBot, log)

async function main() {
  await discord.login()
  log.info('Ready. Use /mc start in Discord to connect the Minecraft bot.')
}

main().catch(err => {
  log.error(`Fatal startup error: ${err.message}`)
  process.exit(1)
})

function shutdown(signal) {
  log.info(`Received ${signal}, shutting down…`)
  mcBot.stop()
  discord.client.destroy()
  process.exit(0)
}

process.on('SIGINT', () => shutdown('SIGINT'))
process.on('SIGTERM', () => shutdown('SIGTERM'))
