/**
 * All the "tune this to match YOUR server" settings live here.
 * I can't see your server's actual chat strings, so I've filled in the
 * most common wording pattern for each thing. If an alert never fires,
 * 9 times out of 10 it's because a regex here doesn't match your server's
 * exact message - watch the console (it logs every raw chat line) and
 * adjust the matching regex below.
 */

module.exports = {
  // ---------------- Connection ----------------
  mc: {
    host: process.env.MC_HOST,
    port: Number(process.env.MC_PORT || 25565),
    email: process.env.MC_EMAIL,
    version: process.env.MC_VERSION || false, // false = auto-detect
    // 'tiny' keeps chunk cache/RAM low. Raise only if you need more render
    // distance for something - it does NOT control server-side chunk
    // ticking/simulation, only what the server sends this client.
    viewDistance: "tiny",
  },

  // ---------------- Hub -> SMP flow ----------------
  flow: {
    // sent automatically once we detect we've spawned in the hub
    joinQueueCommand: "/joinqueue smp",
    // small random delay range (ms) before sending it, so it doesn't look instant/robotic
    joinQueueDelay: [1500, 4000],

    // optional command sent once we detect we're actually in the smp world,
    // e.g. a warp to your farm so those chunks stay loaded. Leave "" to disable.
    afkWarpCommand: "", // e.g. "/warp afk"
    afkWarpDelay: [2000, 5000],
  },

  // ---------------- Chat pattern matching ----------------
  // These decide what shows up as a Discord alert. Edit the regexes to match
  // your server's real wording (case-insensitive already).
  patterns: {
    hubJoined: [/joined the hub/i, /you are now connected to hub/i, /^\s*hub\s*$/i],
    smpJoined: [/joined the smp/i, /you have joined smp/i, /teleporting.*smp/i],
    queueStatus: [/queue position/i, /you are (now )?in (the )?queue/i, /position:\s*\d+/i],
    kicked: [/you have been kicked/i, /disconnected/i],

    // vanilla-ish "PlayerName whispers: msg" / "PlayerName -> you: msg" formats.
    // Add more alternatives as needed - first capturing group = sender, second = message.
    incomingTell: [
      /^(\w+) whispers(?: to you)?:\s*(.+)$/i,
      /^\[(\w+) -> me\]\s*(.+)$/i,
      /^(\w+) -> you:\s*(.+)$/i,
      /^from (\w+):\s*(.+)$/i,
    ],

    // used to catch anticheat/violation spam in console/chat so it gets logged
    anticheatFlag: [/vulcan/i, /badpackets/i, /flagged/i],
  },

  // ---------------- World / server name detection ----------------
  // mineflayer can't see Bukkit/Paper "world" names directly (only the
  // dimension: overworld/nether/end), so we sniff the scoreboard + chat
  // titles for hints. Keys are the friendly labels shown in !status,
  // values are regexes tested against scoreboard lines / titles / chat.
  worldHints: {
    world: [/\bworld\b/i],
    world_nether: [/nether/i],
    world_end: [/\bend\b/i],
    spawn: [/spawn/i],
    afk: [/\bafk\b/i],
  },

  // ---------------- Scoreboard-based real ping ----------------
  // The tab list shows 0ms, but you said the real ping is exposed as a
  // scoreboard placeholder. We read mineflayer's already-cached scoreboard
  // state (no extra packets/polling - the server pushes these updates on
  // its own) whenever !status runs, so this costs ~nothing.
  scoreboard: {
    // if set, only this objective is checked; leave "" to scan all of them
    objectiveName: "",
    pingLineRegex: /ping[^0-9]{0,6}(\d{1,4})/i,
  },

  // ---------------- Shards ----------------
  shards: {
    enabled: true,
    // command sent every intervalMs to collect the shard the server hands out.
    // change this to whatever your server actually uses (a command, right-click, etc.)
    command: "/shards claim",
    intervalMs: 60_000,
  },

  // ---------------- Anti-AFK / human-ness ----------------
  antiAfk: {
    enabled: true,
    // small look/jump every 20-45s so the bot isn't perfectly frozen
    // (helps against AFK-kick timers and looks like a real idle player)
    minIntervalMs: 20_000,
    maxIntervalMs: 45_000,
    jumpChance: 0.35,
  },

  // ---------------- Reconnect ----------------
  reconnect: {
    baseDelayMs: 5_000,
    maxDelayMs: 120_000,
    // after this many consecutive failed attempts, ping the owner that
    // the server looks fully offline instead of just retrying quietly
    alertAfterAttempts: 5,
  },

  // ---------------- Playtime persistence ----------------
  playtime: {
    filePath: "./data/playtime.json",
    flushIntervalMs: 5 * 60_000,
  },
};
