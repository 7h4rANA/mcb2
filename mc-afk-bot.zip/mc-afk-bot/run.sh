#!/usr/bin/env bash
# Keeps the bot alive forever. When !restart calls process.exit(0), or the
# process crashes, this loop just starts it right back up.
cd "$(dirname "$0")"
while true; do
  node --max-old-space-size=220 index.js
  echo "[run.sh] process exited, restarting in 2s..."
  sleep 2
done
