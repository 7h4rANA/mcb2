'use strict'
require('dotenv').config()

function required(name) {
  const v = process.env[name]
  if (!v) throw new Error(`Missing required environment variable: ${name}`)
  return v
}

function list(name) {
  const v = process.env[name] || ''
  return v.split(',').map(s => s.trim()).filter(Boolean)
}

module.exports = {
  discord: {
    token: required('DISCORD_TOKEN'),
    clientId: required('DISCORD_CLIENT_ID'),
    guildId: process.env.DISCORD_GUILD_ID || null,
    ownerIds: list('OWNER_IDS'),
    statusChannelId: process.env.STATUS_CHANNEL_ID || null
  },
  minecraft: {
    host: required('MC_HOST'),
    port: Number(process.env.MC_PORT || 25565),
    email: required('MC_EMAIL'),
    version: process.env.MC_VERSION || false,
    viewDistance: Number(process.env.VIEW_DISTANCE || 3),
    joinCommand: process.env.JOIN_COMMAND || '/smp',
    joinCommandDelayMs: Number(process.env.JOIN_COMMAND_DELAY_MS || 3000)
  }
}
