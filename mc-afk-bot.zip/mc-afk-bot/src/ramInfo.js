const os = require("os");

// All of this reads already-available OS/process counters - nothing here
// polls in the background, it's only computed the moment !status asks for it.
function getRamInfo() {
  const mem = process.memoryUsage();
  const totalMem = os.totalmem();
  const freeMem = os.freemem();
  const usedMem = totalMem - freeMem;

  const mb = (bytes) => (bytes / 1024 / 1024).toFixed(1);

  return {
    processRssMb: mb(mem.rss),
    vpsUsedMb: mb(usedMem),
    vpsTotalMb: mb(totalMem),
    vpsUsedPct: ((usedMem / totalMem) * 100).toFixed(1),
  };
}

module.exports = { getRamInfo };
