const fs = require("fs");
const path = require("path");
const config = require("../config");
const logger = require("./logger");

const filePath = path.resolve(__dirname, "..", config.playtime.filePath);

function load() {
  try {
    const raw = fs.readFileSync(filePath, "utf8");
    const data = JSON.parse(raw);
    return { totalMs: data.totalMs || 0 };
  } catch {
    return { totalMs: 0 };
  }
}

let data = load();
let sessionStartedAt = null;
let flushTimer = null;

function save() {
  try {
    fs.mkdirSync(path.dirname(filePath), { recursive: true });
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
  } catch (err) {
    logger.error("Failed saving playtime.json:", err.message);
  }
}

function startSession() {
  sessionStartedAt = Date.now();
  if (!flushTimer) {
    flushTimer = setInterval(() => {
      flushSession();
      save();
    }, config.playtime.flushIntervalMs);
    flushTimer.unref?.();
  }
}

// folds elapsed time since session start into the stored total, then
// resets the session clock (used both by the periodic flush and stopSession)
function flushSession() {
  if (sessionStartedAt) {
    data.totalMs += Date.now() - sessionStartedAt;
    sessionStartedAt = Date.now();
  }
}

function stopSession() {
  flushSession();
  save();
  sessionStartedAt = null;
  if (flushTimer) {
    clearInterval(flushTimer);
    flushTimer = null;
  }
}

function getTotalMs() {
  let total = data.totalMs;
  if (sessionStartedAt) total += Date.now() - sessionStartedAt;
  return total;
}

function formatDuration(ms) {
  const s = Math.floor(ms / 1000);
  const d = Math.floor(s / 86400);
  const h = Math.floor((s % 86400) / 3600);
  const m = Math.floor((s % 3600) / 60);
  const parts = [];
  if (d) parts.push(`${d}d`);
  if (h) parts.push(`${h}h`);
  parts.push(`${m}m`);
  return parts.join(" ");
}

module.exports = { startSession, stopSession, getTotalMs, formatDuration };
