'use strict'
const mineflayer = require('mineflayer')
const path = require('path')

const MIN_RECONNECT_MS = 15_000
const MAX_RECONNECT_MS = 5 * 60_000

/**
 * Wraps a single mineflayer bot instance with start/stop control,
 * automatic (backed-off) reconnection, and a status snapshot -
 * everything the Discord side needs, nothing it doesn't.
 */
class McBotManager {
  constructor(config, log, hooks = {}) {
    this.config = config
    this.log = log
    this.hooks = hooks // { onMsaCode, onSpawn, onEnd, onLog }

    this.bot = null
    this.desiredOnline = false
    this.reconnectTimer = null
    this.reconnectDelay = MIN_RECONNECT_MS
    this.startedAt = null
    this.lastError = null
    this.lastKickReason = null
    this.joinCommandSent = false
  }

  isRunning() {
    return !!this.bot
  }

  getStatus() {
    const base = {
      desiredOnline: this.desiredOnline,
      lastError: this.lastError,
      lastKickReason: this.lastKickReason
    }
    if (!this.bot || !this.bot.entity) {
      return { online: false, ...base }
    }
    const b = this.bot
    return {
      online: true,
      ...base,
      username: b.username,
      health: b.health,
      food: b.food,
      position: b.entity.position ? {
        x: Math.round(b.entity.position.x),
        y: Math.round(b.entity.position.y),
        z: Math.round(b.entity.position.z)
      } : null,
      dimension: b.game ? b.game.dimension : null,
      ping: (b.player && b.player.ping) || null,
      uptimeMs: this.startedAt ? Date.now() - this.startedAt : 0
    }
  }

  start() {
    if (this.bot) return false
    this.desiredOnline = true
    this.reconnectDelay = MIN_RECONNECT_MS
    this._connect()
    return true
  }

  stop() {
    const wasRunning = !!this.bot
    this.desiredOnline = false
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer)
      this.reconnectTimer = null
    }
    if (this.bot) {
      try { this.bot.quit('stopped from discord') } catch (_) { /* already gone */ }
      this.bot = null
      this.startedAt = null
    }
    return wasRunning
  }

  _log(msg) {
    this.log.info(msg)
    if (this.hooks.onLog) this.hooks.onLog(msg)
  }

  _connect() {
    const cfg = this.config
    let bot
    try {
      bot = mineflayer.createBot({
        host: cfg.host,
        port: cfg.port,
        username: cfg.email,
        auth: 'microsoft',
        version: cfg.version,
        viewDistance: cfg.viewDistance,
        profilesFolder: path.join(__dirname, '..', 'auth_cache'),
        checkTimeoutInterval: 60_000,
        hideErrors: false,
        onMsaCode: (data) => {
          this._log(`Microsoft login needed: ${data.message}`)
          if (this.hooks.onMsaCode) this.hooks.onMsaCode(data)
        }
      })
    } catch (err) {
      this.lastError = err.message
      this._log(`Failed to create bot: ${err.message}`)
      this._scheduleReconnect()
      return
    }

    this.bot = bot
    this.joinCommandSent = false

    bot.once('spawn', () => {
      this.startedAt = Date.now()
      this.lastError = null
      this.reconnectDelay = MIN_RECONNECT_MS // reset backoff on a good connection
      this._log(`Spawned as ${bot.username} on ${cfg.host}`)

      if (!this.joinCommandSent && cfg.joinCommand) {
        this.joinCommandSent = true
        setTimeout(() => {
          if (this.bot === bot) {
            bot.chat(cfg.joinCommand)
            this._log(`Sent join command: ${cfg.joinCommand}`)
          }
        }, cfg.joinCommandDelayMs)
      }

      if (this.hooks.onSpawn) this.hooks.onSpawn(this.getStatus())
    })

    bot.on('kicked', (reason) => {
      this.lastKickReason = typeof reason === 'string' ? reason : JSON.stringify(reason)
      this._log(`Kicked: ${this.lastKickReason}`)
    })

    bot.on('error', (err) => {
      this.lastError = err && err.message ? err.message : String(err)
      this._log(`Bot error: ${this.lastError}`)
    })

    bot.on('end', (reason) => {
      const wasThisBot = this.bot === bot
      if (!wasThisBot) return // a newer bot instance already replaced this one
      this.bot = null
      this.startedAt = null
      this._log(`Disconnected${reason ? ` (${reason})` : ''}`)
      if (this.hooks.onEnd) this.hooks.onEnd(this.getStatus())
      if (this.desiredOnline) this._scheduleReconnect()
    })
  }

  _scheduleReconnect() {
    if (this.reconnectTimer) clearTimeout(this.reconnectTimer)
    const delay = this.reconnectDelay
    this._log(`Reconnecting in ${Math.round(delay / 1000)}s`)
    this.reconnectTimer = setTimeout(() => {
      if (this.desiredOnline) this._connect()
    }, delay)
    // exponential backoff with a cap, so a hard-down server doesn't turn into
    // a rapid reconnect loop that looks like a bot flood to anti-bot systems
    this.reconnectDelay = Math.min(this.reconnectDelay * 2, MAX_RECONNECT_MS)
  }
}

module.exports = McBotManager
