const fs = require("fs");
const path = require("path");

const filePath = path.resolve(__dirname, "..", "data", "runstate.json");

function load() {
  try {
    return JSON.parse(fs.readFileSync(filePath, "utf8"));
  } catch {
    return { wantOnline: false };
  }
}

function save(wantOnline) {
  try {
    fs.mkdirSync(path.dirname(filePath), { recursive: true });
    fs.writeFileSync(filePath, JSON.stringify({ wantOnline }, null, 2));
  } catch {
    // non-fatal, worst case it just won't auto-resume next boot
  }
}

module.exports = { load, save };
