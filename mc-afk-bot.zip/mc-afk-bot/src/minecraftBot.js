const path = require("path");
const mineflayer = require("mineflayer");
const config = require("../config");
const logger = require("./logger");
const playtime = require("./playtime");
const runState = require("./runState");
const { bus, state } = require("./state");

let bot = null;
let reconnectTimer = null;
let antiAfkTimer = null;
let shardTimer = null;

const rand = ([min, max]) => Math.floor(min + Math.random() * (max - min));

// ---------------- public API ----------------

function startBot() {
  if (state.mcStatus === "online" || state.mcStatus === "connecting") {
    return { ok: false, reason: "already running" };
  }
  state.wantOnline = true;
  runState.save(true);
  state.reconnectAttempts = 0;
  connect();
  return { ok: true };
}

function stopBot(reason = "manual stop") {
  state.wantOnline = false;
  runState.save(false);
  clearTimers();
  if (bot) {
    try {
      bot.quit(reason);
    } catch {}
    bot = null;
  }
  if (state.mcStatus !== "offline") {
    playtime.stopSession();
  }
  state.mcStatus = "offline";
  state.currentServer = "unknown";
  state.currentWorld = "unknown";
  state.connectedSince = null;
  bus.emit("statusChange");
  return { ok: true };
}

// raw = full string, may or may not start with "/"
function sendRaw(raw) {
  if (!bot || state.mcStatus !== "online") return { ok: false, reason: "bot is offline" };
  bot.chat(raw);
  return { ok: true };
}

function sendCommand(cmd) {
  const clean = cmd.startsWith("/") ? cmd : `/${cmd}`;
  return sendRaw(clean);
}

// collects the next `windowMs` of chat lines after sending `cmd`, resolves with them.
// Reuses the "__cmdCollect" event that the message handler already emits for
// every incoming line - no extra listeners on the underlying connection.
function runCommandCollectOutput(cmd, windowMs = 3000) {
  return new Promise((resolve) => {
    if (!bot || state.mcStatus !== "online") {
      resolve({ ok: false, reason: "bot is offline", lines: [] });
      return;
    }
    const lines = [];
    const onLine = (text) => lines.push(text);
    bus.on("__cmdCollect", onLine);
    sendCommand(cmd);
    setTimeout(() => {
      bus.off("__cmdCollect", onLine);
      resolve({ ok: true, lines });
    }, windowMs);
  });
}

function getRealPing() {
  const line = scanScoreboardLines().find((l) => config.scoreboard.pingLineRegex.test(l));
  if (!line) return null;
  const m = line.match(config.scoreboard.pingLineRegex);
  return m ? Number(m[1]) : null;
}

function getWorldGuess() {
  const lines = scanScoreboardLines();
  for (const [label, regexes] of Object.entries(config.worldHints)) {
    if (regexes.some((re) => lines.some((l) => re.test(l)))) return label;
  }
  return state.currentWorld !== "unknown" ? state.currentWorld : "unknown";
}

function getLiveHealthFood() {
  if (!bot || state.mcStatus !== "online") return { health: null, food: null };
  return { health: bot.health ?? null, food: bot.food ?? null };
}

// ---------------- internals ----------------

function scanScoreboardLines() {
  if (!bot || !bot.scoreboards) return [];
  const lines = [];
  const wanted = config.scoreboard.objectiveName;
  for (const sb of Object.values(bot.scoreboards)) {
    if (wanted && sb.name !== wanted) continue;
    if (sb.title) lines.push(String(sb.title));
    for (const item of sb.items) {
      try {
        lines.push(item.displayName.toString());
      } catch {
        lines.push(item.name);
      }
    }
  }
  return lines;
}

function clearTimers() {
  if (reconnectTimer) clearTimeout(reconnectTimer);
  if (antiAfkTimer) clearInterval(antiAfkTimer);
  if (shardTimer) clearInterval(shardTimer);
  reconnectTimer = antiAfkTimer = shardTimer = null;
}

function startAntiAfk() {
  if (!config.antiAfk.enabled || antiAfkTimer) return;
  const tick = () => {
    if (!bot || state.mcStatus !== "online") return;
    try {
      const yaw = bot.entity.yaw + (Math.random() - 0.5) * 0.6;
      const pitch = Math.max(-1, Math.min(1, bot.entity.pitch + (Math.random() - 0.5) * 0.3));
      bot.look(yaw, pitch, true).catch(() => {});
      if (Math.random() < config.antiAfk.jumpChance) {
        bot.setControlState("jump", true);
        setTimeout(() => bot && bot.setControlState("jump", false), 250);
      }
    } catch (err) {
      logger.warn("anti-afk tick failed:", err.message);
    }
    antiAfkTimer = setTimeout(tick, rand([config.antiAfk.minIntervalMs, config.antiAfk.maxIntervalMs]));
  };
  antiAfkTimer = setTimeout(tick, rand([config.antiAfk.minIntervalMs, config.antiAfk.maxIntervalMs]));
}

function startShardTimer() {
  if (!config.shards.enabled || shardTimer) return;
  shardTimer = setInterval(() => {
    if (!bot || state.mcStatus !== "online") return;
    sendCommand(config.shards.command);
  }, config.shards.intervalMs);
}

function scheduleReconnect() {
  if (!state.wantOnline) return; // owner ran !stop, don't fight that
  clearTimers();
  state.reconnectAttempts += 1;
  const delay = Math.min(
    config.reconnect.baseDelayMs * 2 ** (state.reconnectAttempts - 1),
    config.reconnect.maxDelayMs
  );
  bus.emit("log", {
    kind: "reconnect",
    text: `Reconnecting in ${Math.round(delay / 1000)}s (attempt ${state.reconnectAttempts})`,
  });
  const n = config.reconnect.alertAfterAttempts;
  if (state.reconnectAttempts === n || (state.reconnectAttempts > n && state.reconnectAttempts % (n * 4) === 0)) {
    bus.emit("log", {
      kind: "alert",
      text: `${state.reconnectAttempts} reconnect attempts failed in a row - the server may be offline/restarting. Still retrying automatically.`,
    });
  }
  reconnectTimer = setTimeout(connect, delay);
}

function connect() {
  state.mcStatus = "connecting";
  bus.emit("statusChange");
  bus.emit("log", { kind: "info", text: `Connecting to ${config.mc.host}:${config.mc.port}...` });

  bot = mineflayer.createBot({
    host: config.mc.host,
    port: config.mc.port,
    username: config.mc.email,
    auth: "microsoft",
    version: config.mc.version,
    viewDistance: config.mc.viewDistance,
    profilesFolder: path.join(__dirname, "..", "mc-auth-cache"),
    onMsaCode: (data) => {
      logger.info(`>>> Microsoft login required: go to ${data.verification_uri} and enter code ${data.user_code}`);
      bus.emit("log", {
        kind: "auth",
        text: `Microsoft sign-in needed.\nGo to **${data.verification_uri}**\nEnter code: **${data.user_code}**\n(expires in ~${Math.round((data.expires_in || 900) / 60)} min)`,
      });
    },
  });

  wireEvents(bot);
}

function wireEvents(b) {
  b.once("spawn", () => {
    const firstSpawn = !state.connectedSince;
    if (firstSpawn) {
      state.connectedSince = new Date();
      playtime.startSession();
      startAntiAfk();
      startShardTimer();
    }
    const isRecovery = state.reconnectAttempts > 0;
    state.mcStatus = "online";
    state.reconnectAttempts = 0;
    state.username = b.username;
    if (state.currentServer === "unknown") state.currentServer = "hub";
    bus.emit("statusChange");
    bus.emit("log", { kind: "spawn", text: `Spawned in as **${b.username}**` });
    if (isRecovery) {
      bus.emit("log", { kind: "info", text: "✅ Back online after reconnecting." });
    }

    setTimeout(() => {
      if (state.currentServer !== "smp") {
        sendCommand(config.flow.joinQueueCommand.replace(/^\//, ""));
        bus.emit("log", { kind: "queue", text: `Sent \`${config.flow.joinQueueCommand}\`` });
      }
    }, rand(config.flow.joinQueueDelay));
  });

  b.on("message", (jsonMsg) => {
    let text;
    try {
      text = jsonMsg.toString();
    } catch {
      return;
    }
    if (!text || !text.trim()) return;
    logger.chat(text);
    bus.emit("__cmdCollect", text);
    handleChatLine(text);
  });

  b.on("kicked", (reason) => {
    let reasonText;
    try {
      reasonText = typeof reason === "string" ? reason : JSON.stringify(reason);
    } catch {
      reasonText = String(reason);
    }
    state.lastError = reasonText;
    bus.emit("log", { kind: "kicked", text: `Kicked: ${reasonText}` });
  });

  b.on("error", (err) => {
    state.lastError = err.message;
    bus.emit("log", { kind: "error", text: `Error: ${err.message}` });
  });

  b.on("end", () => {
    if (state.mcStatus === "offline") return; // already handled by stopBot()
    const wasOnline = state.mcStatus === "online";
    state.mcStatus = "offline";
    bus.emit("statusChange");
    if (wasOnline) playtime.stopSession();
    bot = null;
    if (state.wantOnline) {
      bus.emit("log", { kind: "disconnect", text: "Disconnected from server." });
      scheduleReconnect();
    }
  });
}

function handleChatLine(text) {
  const p = config.patterns;
  let handled = false;

  if (p.anticheatFlag.some((re) => re.test(text))) {
    bus.emit("log", { kind: "anticheat", text });
    handled = true;
  }
  if (p.hubJoined.some((re) => re.test(text))) {
    state.currentServer = "hub";
    state.currentWorld = "hub";
    bus.emit("log", { kind: "hub", text });
    handled = true;
  }
  if (p.smpJoined.some((re) => re.test(text))) {
    state.currentServer = "smp";
    bus.emit("log", { kind: "smp", text });
    if (config.flow.afkWarpCommand) {
      setTimeout(() => sendCommand(config.flow.afkWarpCommand.replace(/^\//, "")), rand(config.flow.afkWarpDelay));
    }
    handled = true;
  }
  if (p.queueStatus.some((re) => re.test(text))) {
    bus.emit("log", { kind: "queue", text });
    handled = true;
  }

  if (!handled) {
    for (const re of p.incomingTell) {
      const m = text.match(re);
      if (m) {
        bus.emit("tell", { from: m[1], msg: m[2], raw: text });
        handled = true;
        break;
      }
    }
  }

  if (!handled && state.username && text.toLowerCase().includes(state.username.toLowerCase())) {
    bus.emit("mention", { text });
    handled = true;
  }

  if (!handled) {
    bus.emit("chat", { text });
  }
}

function shouldAutoResume() {
  return runState.load().wantOnline === true;
}

module.exports = {
  startBot,
  stopBot,
  shouldAutoResume,
  sendRaw,
  sendCommand,
  runCommandCollectOutput,
  getRealPing,
  getWorldGuess,
  getLiveHealthFood,
};
