'use strict'
const { Client, GatewayIntentBits, EmbedBuilder } = require('discord.js')

function formatUptime(ms) {
  if (!ms) return '0s'
  const s = Math.floor(ms / 1000)
  const h = Math.floor(s / 3600)
  const m = Math.floor((s % 3600) / 60)
  const sec = s % 60
  return [h && `${h}h`, m && `${m}m`, `${sec}s`].filter(Boolean).join(' ')
}

function statusEmbed(status) {
  const embed = new EmbedBuilder()
    .setTitle('Minecraft AFK Bot')
    .setColor(status.online ? 0x43b581 : 0xed4245)
    .addFields(
      { name: 'State', value: status.online ? '🟢 Online' : (status.desiredOnline ? '🟡 Reconnecting…' : '🔴 Offline'), inline: true }
    )
    .setTimestamp()

  if (status.online) {
    embed.addFields(
      { name: 'Account', value: status.username || 'unknown', inline: true },
      { name: 'Uptime', value: formatUptime(status.uptimeMs), inline: true },
      { name: 'Health / Food', value: `${status.health ?? '?'} / ${status.food ?? '?'}`, inline: true },
      { name: 'Position', value: status.position ? `${status.position.x}, ${status.position.y}, ${status.position.z}` : 'unknown', inline: true },
      { name: 'Ping', value: status.ping != null ? `${status.ping}ms` : 'unknown', inline: true }
    )
  }
  if (status.lastKickReason) {
    embed.addFields({ name: 'Last kick reason', value: String(status.lastKickReason).slice(0, 1000) })
  }
  if (!status.online && status.lastError) {
    embed.addFields({ name: 'Last error', value: String(status.lastError).slice(0, 1000) })
  }
  return embed
}

function createDiscordBot(config, mcBotManager, log) {
  // Only the Guilds intent is needed for slash commands - keeps the
  // gateway connection (and its memory footprint) minimal.
  const client = new Client({ intents: [GatewayIntentBits.Guilds] })

  function isOwner(userId) {
    return config.ownerIds.length === 0 || config.ownerIds.includes(userId)
  }

  async function notifyChannel(text) {
    if (!config.statusChannelId) return
    try {
      const channel = await client.channels.fetch(config.statusChannelId)
      if (channel && channel.isTextBased()) await channel.send(text)
    } catch (err) {
      log.warn(`Could not post to status channel: ${err.message}`)
    }
  }

  client.once('clientReady', () => {
    log.info(`Discord bot logged in as ${client.user.tag}`)
  })

  client.on('interactionCreate', async (interaction) => {
    if (!interaction.isChatInputCommand()) return
    if (interaction.commandName !== 'mc') return

    if (!isOwner(interaction.user.id)) {
      await interaction.reply({ content: "You're not allowed to control this bot.", ephemeral: true })
      return
    }

    const sub = interaction.options.getSubcommand()

    if (sub === 'start') {
      const started = mcBotManager.start()
      await interaction.reply(started
        ? '🟢 Starting the Minecraft bot…'
        : 'Already running (or already trying to connect).')
    } else if (sub === 'stop') {
      const stopped = mcBotManager.stop()
      await interaction.reply(stopped ? '🔴 Stopped.' : 'It was already offline.')
    } else if (sub === 'status') {
      await interaction.reply({ embeds: [statusEmbed(mcBotManager.getStatus())] })
    }
  })

  return {
    client,
    login: () => client.login(config.token),
    notifyChannel
  }
}

module.exports = { createDiscordBot, statusEmbed }
