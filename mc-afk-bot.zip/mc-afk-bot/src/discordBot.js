const {
  Client,
  GatewayIntentBits,
  Partials,
  Options,
  EmbedBuilder,
  ActivityType,
} = require("discord.js");
const logger = require("./logger");
const playtime = require("./playtime");
const ramInfo = require("./ramInfo");
const { bus, state } = require("./state");
const mc = require("./minecraftBot");

const PREFIX = process.env.COMMAND_PREFIX || "!";
const OWNER_ID = process.env.OWNER_ID;
const LOG_CHANNEL_ID = process.env.LOG_CHANNEL_ID;
const COMMAND_CHANNEL_ID = process.env.COMMAND_CHANNEL_ID;
const CHAT_CHANNEL_ID = process.env.CHAT_CHANNEL_ID;

const COLORS = {
  online: 0x57f287,
  offline: 0xed4245,
  connecting: 0xfee75c,
  info: 0x5865f2,
  hub: 0x5865f2,
  smp: 0x57f287,
  queue: 0xfee75c,
  kicked: 0xed4245,
  disconnect: 0xed4245,
  reconnect: 0xfee75c,
  alert: 0xed4245,
  error: 0xed4245,
  anticheat: 0xeb459e,
  auth: 0x5865f2,
  tell: 0x5865f2,
  mention: 0xfee75c,
};

// Keep caches tiny - this bot never needs to remember much about the guild,
// which is most of what actually eats RAM in long running discord.js bots.
const client = new Client({
  intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent],
  partials: [Partials.Message, Partials.Channel],
  makeCache: Options.cacheWithLimits({
    MessageManager: 25,
    UserManager: 10,
    GuildMemberManager: 10,
    PresenceManager: 0,
    ReactionManager: 0,
    ...Object.fromEntries(
      ["GuildBanManager", "GuildEmojiManager", "GuildInviteManager", "GuildStickerManager", "ThreadManager", "VoiceStateManager"].map(
        (k) => [k, 0]
      )
    ),
  }),
  sweepers: {
    messages: { interval: 600, lifetime: 900 },
  },
});

let restartRequested = false;

// ---------------- helpers ----------------

function isOwner(message) {
  return message.author.id === OWNER_ID;
}

async function getChannel(id) {
  if (!id) return null;
  try {
    return await client.channels.fetch(id);
  } catch {
    return null;
  }
}

function baseEmbed(kind, description) {
  return new EmbedBuilder()
    .setColor(COLORS[kind] ?? COLORS.info)
    .setDescription(description)
    .setTimestamp();
}

async function sendLog(kind, text) {
  const ch = await getChannel(LOG_CHANNEL_ID);
  if (!ch) return;
  const titles = {
    info: "ℹ️ Info",
    spawn: "🎮 Spawned",
    hub: "🏠 Hub",
    smp: "🟩 SMP",
    queue: "⏳ Queue",
    kicked: "👢 Kicked",
    disconnect: "🔌 Disconnected",
    reconnect: "🔁 Reconnecting",
    alert: "🚨 Alert",
    error: "❗ Error",
    anticheat: "🛡️ Anticheat flag",
    auth: "🔑 Microsoft sign-in",
  };
  const embed = baseEmbed(kind, text).setTitle(titles[kind] || "Log");
  const mentionOwner = kind === "alert";
  await ch.send({ content: mentionOwner ? `<@${OWNER_ID}>` : undefined, embeds: [embed] }).catch(() => {});
}

async function sendChatLine(text) {
  const ch = await getChannel(CHAT_CHANNEL_ID);
  if (!ch) return;
  // Plain chat = plain text, on purpose, so embeds always mean "this is a
  // mention/tell and needs your attention", never confused with normal chat.
  await ch.send({ content: text.slice(0, 1900) }).catch(() => {});
}

async function sendTellAlert({ from, msg, raw }) {
  const ch = await getChannel(CHAT_CHANNEL_ID);
  if (!ch) return;
  const embed = baseEmbed("tell", msg).setTitle(`✉️ Tell from ${from}`).setFooter({ text: raw.slice(0, 200) });
  await ch.send({ content: `<@${OWNER_ID}>`, embeds: [embed] }).catch(() => {});
}

async function sendMentionAlert({ text }) {
  const ch = await getChannel(CHAT_CHANNEL_ID);
  if (!ch) return;
  const embed = baseEmbed("mention", text).setTitle("👀 You were mentioned");
  await ch.send({ content: `<@${OWNER_ID}>`, embeds: [embed] }).catch(() => {});
}

function updatePresence() {
  if (!client.user) return;
  const online = state.mcStatus === "online";
  const connecting = state.mcStatus === "connecting";
  const emoji = online ? "🟢" : connecting ? "🟡" : "🔴";
  const label = online ? state.currentServer : connecting ? "connecting..." : "offline";

  client.user.setPresence({
    status: online ? "online" : connecting ? "idle" : "dnd",
    activities: [
      online
        ? { name: `${emoji} ${label}`, type: ActivityType.Playing }
        : { name: `${emoji} ${label}`, type: ActivityType.Custom, state: `${emoji} ${label}` },
    ],
  });
}

function fmtUptime(since) {
  if (!since) return "—";
  return playtime.formatDuration(Date.now() - new Date(since).getTime());
}

async function buildStatusEmbed() {
  const online = state.mcStatus === "online";
  const connecting = state.mcStatus === "connecting";
  const { health, food } = mc.getLiveHealthFood();
  const ping = online ? mc.getRealPing() : null;
  const world = online ? mc.getWorldGuess() : "—";
  const ram = ramInfo.getRamInfo();

  const embed = new EmbedBuilder()
    .setColor(online ? COLORS.online : connecting ? COLORS.connecting : COLORS.offline)
    .setTitle(online ? "🟢 Online" : connecting ? "🟡 Connecting..." : "🔴 Offline")
    .addFields(
      { name: "Account", value: state.username || "—", inline: true },
      { name: "Server", value: online ? state.currentServer : "—", inline: true },
      { name: "World", value: online ? world : "—", inline: true },
      { name: "Uptime (session)", value: fmtUptime(state.connectedSince), inline: true },
      { name: "Health", value: online && health != null ? `${health.toFixed(1)} ❤️` : "—", inline: true },
      { name: "Food", value: online && food != null ? `${food}/20 🍖` : "—", inline: true },
      { name: "Real ping", value: online ? (ping != null ? `${ping}ms` : "not found on scoreboard") : "—", inline: true },
      { name: "Total playtime", value: playtime.formatDuration(playtime.getTotalMs()), inline: true },
      { name: "\u200b", value: "\u200b", inline: true },
      { name: "Bot RAM", value: `${ram.processRssMb} MB`, inline: true },
      { name: "VPS RAM used", value: `${ram.vpsUsedMb} MB (${ram.vpsUsedPct}%)`, inline: true },
      { name: "VPS RAM total", value: `${ram.vpsTotalMb} MB`, inline: true }
    )
    .setTimestamp();
  return embed;
}

// ---------------- command handlers ----------------

const commands = {
  async start(message) {
    const res = mc.startBot();
    await message.reply(res.ok ? "🟡 Starting the Minecraft bot..." : `Already running (${res.reason}).`);
  },

  async stop(message) {
    mc.stopBot("stopped via discord");
    await message.reply("🔴 Stopped. You're free to log in yourself now.");
  },

  async restart(message) {
    if (restartRequested) return;
    restartRequested = true;
    await message.reply("🔁 Restarting everything (Minecraft bot + Discord bot)...");
    await sendLog("info", "Full restart requested via Discord.");
    mc.stopBot("restarting");
    // small delay so the messages above actually reach Discord before we die.
    // The process must be run under run.sh (or pm2/systemd) for it to come back -
    // see README. On boot, index.js sees the saved run-state and auto-resumes.
    setTimeout(() => process.exit(0), 1500);
  },

  async status(message) {
    const embed = await buildStatusEmbed();
    await message.reply({ embeds: [embed] });
  },

  async chat(message, args) {
    const text = args.join(" ");
    if (!text) return message.reply("Usage: `!chat <message>`");
    const res = mc.sendRaw(text);
    if (!res.ok) return message.reply(`Couldn't send - ${res.reason}`);
    await message.react("✅").catch(() => {});
  },

  async cmd(message, args) {
    const command = args.join(" ");
    if (!command) return message.reply("Usage: `!cmd <command>`");
    const result = await mc.runCommandCollectOutput(command, 3000);
    if (!result.ok) return message.reply(`Couldn't run - ${result.reason}`);
    const body = result.lines.length ? result.lines.join("\n").slice(0, 3900) : "(no output within 3s)";
    const embed = baseEmbed("info", "```" + body + "```").setTitle(`🖥️ /${command.replace(/^\//, "")}`);
    await message.reply({ embeds: [embed] });
  },

  async msg(message, args) {
    const [player, ...rest] = args;
    const text = rest.join(" ");
    if (!player || !text) return message.reply("Usage: `!msg <player> <message>`");
    const res = mc.sendCommand(`msg ${player} ${text}`);
    if (!res.ok) return message.reply(`Couldn't send - ${res.reason}`);
    await message.react("✅").catch(() => {});
  },

  async r(message, args) {
    const text = args.join(" ");
    if (!text) return message.reply("Usage: `!r <message>`");
    const res = mc.sendCommand(`r ${text}`);
    if (!res.ok) return message.reply(`Couldn't send - ${res.reason}`);
    await message.react("✅").catch(() => {});
  },
};
commands.tell = commands.msg; // alias, as requested

// ---------------- wiring ----------------

client.once("ready", async () => {
  logger.info(`Discord bot logged in as ${client.user.tag}`);
  updatePresence();

  const auto = mc.shouldAutoResume();
  if (auto) {
    await sendLog("info", "Resuming previous session (was online before last restart)...");
    mc.startBot();
  }
});

client.on("messageCreate", async (message) => {
  if (message.author.bot || !message.guild) return;
  if (!message.content.startsWith(PREFIX)) {
    // plain (non-command) text: only relays to in-game chat from the owner,
    // and only in the dedicated chat channel. Everyone else is ignored so
    // random members can't puppet the in-game account.
    if (message.channel.id === CHAT_CHANNEL_ID && isOwner(message)) {
      const res = mc.sendRaw(message.content);
      if (!res.ok) await message.react("⚠️").catch(() => {});
    }
    return;
  }

  // command message
  if (!isOwner(message)) return; // single-owner control, by design
  if (![COMMAND_CHANNEL_ID, CHAT_CHANNEL_ID].includes(message.channel.id)) return;

  const [name, ...args] = message.content.slice(PREFIX.length).trim().split(/\s+/);
  const handler = commands[name?.toLowerCase()];
  if (!handler) return;
  try {
    await handler(message, args);
  } catch (err) {
    logger.error(`command !${name} failed:`, err);
    await message.reply(`Something broke running that: ${err.message}`).catch(() => {});
  }
});

bus.on("statusChange", updatePresence);
bus.on("log", ({ kind, text }) => sendLog(kind, text).catch((e) => logger.error(e)));
bus.on("chat", ({ text }) => sendChatLine(text).catch((e) => logger.error(e)));
bus.on("tell", (data) => sendTellAlert(data).catch((e) => logger.error(e)));
bus.on("mention", (data) => sendMentionAlert(data).catch((e) => logger.error(e)));

function login() {
  return client.login(process.env.DISCORD_TOKEN);
}

module.exports = { login, client };
