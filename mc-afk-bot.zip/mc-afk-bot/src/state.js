const { EventEmitter } = require("events");

// Central event bus so minecraftBot.js and discordBot.js never require each
// other directly - keeps restart/reconnect logic from tangling.
class Bus extends EventEmitter {}
const bus = new Bus();
bus.setMaxListeners(30);

const state = {
  mcStatus: "offline", // offline | connecting | online
  currentServer: "unknown", // hub | smp | unknown
  currentWorld: "unknown",
  connectedSince: null, // Date
  reconnectAttempts: 0,
  lastPing: null,
  health: null,
  food: null,
  username: null,
  wantOnline: false, // true once the owner runs !start, false after !stop
  lastError: null,
};

module.exports = { bus, state };
