const ramInfo = require("./ramInfo");
const { bus } = require("./state");

const CHECK_INTERVAL_MS = 10 * 60_000; // 10 min - cheap enough not to matter,
// but infrequent enough it will never compete with the VPS's v2ray traffic.
const HIGH_PCT = 90;
const RECOVER_PCT = 80; // hysteresis so it doesn't spam right at the edge

let alerted = false;

function start() {
  setInterval(() => {
    const { vpsUsedPct } = ramInfo.getRamInfo();
    const pct = Number(vpsUsedPct);
    if (!alerted && pct >= HIGH_PCT) {
      alerted = true;
      bus.emit("log", {
        kind: "alert",
        text: `VPS memory is at ${vpsUsedPct}% - the box is running low on RAM.`,
      });
    } else if (alerted && pct <= RECOVER_PCT) {
      alerted = false;
      bus.emit("log", { kind: "info", text: `VPS memory back down to ${vpsUsedPct}%.` });
    }
  }, CHECK_INTERVAL_MS).unref();
}

module.exports = { start };
