'use strict'
const { REST, Routes, SlashCommandBuilder } = require('discord.js')
const config = require('./config')

const commands = [
  new SlashCommandBuilder()
    .setName('mc')
    .setDescription('Control the Minecraft AFK bot')
    .addSubcommand(sub => sub.setName('start').setDescription('Connect the bot to the server'))
    .addSubcommand(sub => sub.setName('stop').setDescription('Disconnect the bot'))
    .addSubcommand(sub => sub.setName('status').setDescription('Show current bot status'))
].map(c => c.toJSON())

async function main() {
  const rest = new REST({ version: '10' }).setToken(config.discord.token)
  if (config.discord.guildId) {
    await rest.put(
      Routes.applicationGuildCommands(config.discord.clientId, config.discord.guildId),
      { body: commands }
    )
    console.log('Registered guild commands (instant).')
  } else {
    await rest.put(
      Routes.applicationCommands(config.discord.clientId),
      { body: commands }
    )
    console.log('Registered global commands (can take up to ~1 hour to appear).')
  }
}

main().catch(err => {
  console.error('Failed to register commands:', err)
  process.exit(1)
})
