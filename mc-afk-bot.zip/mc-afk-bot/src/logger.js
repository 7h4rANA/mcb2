function ts() {
  return new Date().toISOString().replace("T", " ").split(".")[0];
}

module.exports = {
  info: (...a) => console.log(`[${ts()}] [INFO]`, ...a),
  warn: (...a) => console.warn(`[${ts()}] [WARN]`, ...a),
  error: (...a) => console.error(`[${ts()}] [ERROR]`, ...a),
  chat: (...a) => console.log(`[${ts()}] [CHAT]`, ...a),
};
