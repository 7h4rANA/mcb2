# Minecraft AFK Bot + Discord Control Panel

A [mineflayer](https://github.com/PrismarineJS/mineflayer) bot that logs into your
**premium (Microsoft) Minecraft account**, sits in your server's hub, auto-queues
into SMP, stays AFK on your farm, and is fully controlled from Discord - including
two-way chat relay, live status, and auto-reconnect.

Built for a small VPS (works fine at ~200-300MB RAM, tested config caps Node's
heap at 220MB) that's also running something else (you mentioned v2ray) - see
**"Keeping RAM usage low"** below.

## What it does

- Logs in with your Microsoft account (device-code flow - no password stored anywhere)
- On spawn: waits a moment, sends `/joinqueue smp` automatically
- Auto-reconnects if kicked/disconnected from **hub or smp**, and re-queues for smp
- Alerts you in Discord if the server looks fully offline (keeps retrying anyway)
- Relays hub-join / smp-join / queue-position messages to a Discord **logs** channel
- Relays public in-game chat to a Discord **chat** channel (plain text)
- Sends **embeds** (so you never confuse them with normal chat) for:
  - someone `/tell`ing or `/msg`ing you
  - someone mentioning your username in public chat
- Full remote control from Discord (owner-only)
- Shows real ping by reading the scoreboard placeholder instead of the (fake/0ms) tab list
- Claims your server's "shard" drop every minute
- Tracks total playtime across restarts
- Small idle look/jump loop so the bot isn't perfectly frozen (helps with AFK-kick
  timers and generally behaves like a normal idle player - see the anti-cheat note below)
- Discord bot shows 🟢/🟡/🔴 + "Playing `<server>`" so you can see bot state at a glance
- Resumes automatically after `!restart` or a crash - no need to `!start` again
- RAM watchdog: warns you if the whole VPS starts running low on memory (checked
  every 10 minutes using free OS counters, not by polling anything live)

## 1. Requirements

- A small VPS (Ubuntu/Debian is easiest) - Node.js 18+
- A **premium** Minecraft account (Microsoft login)
- A Discord bot application + 3 text channels in your server

## 2. Create the Discord bot

1. Go to https://discord.com/developers/applications → **New Application**
2. **Bot** tab → Add Bot → copy the **token** (this is `DISCORD_TOKEN`)
3. Under **Privileged Gateway Intents**, enable **Message Content Intent**
   (required to read your `!` commands)
4. **OAuth2 → URL Generator**: scopes `bot`, permissions `Send Messages`,
   `Embed Links`, `Read Message History`, `Add Reactions` → open the generated
   URL and invite it to your server
5. Create 3 text channels (name them whatever you like) and copy their IDs
   (enable Developer Mode in Discord settings, then right-click a channel →
   Copy Channel ID):
   - **logs** - join/kick/queue/reconnect/error alerts
   - **commands** - where you run `!start` `!stop` `!status` `!restart`
   - **chat** - live in-game chat + where you type plain messages / `!r` / `!msg` / `!tell`
6. Right-click your own username → Copy User ID → this is `OWNER_ID`. Only this
   user can control the bot - it's a single-owner setup by design.

## 3. Install on the VPS

```bash
# unzip this project on your VPS, then:
cd mc-afk-bot
npm install
cp .env.example .env
nano .env        # fill in every value - see below
```

### Filling in `.env`

| Variable | What it is |
|---|---|
| `DISCORD_TOKEN` | from step 2 |
| `OWNER_ID` | your Discord user ID |
| `GUILD_ID` | your Discord server ID |
| `LOG_CHANNEL_ID` / `COMMAND_CHANNEL_ID` / `CHAT_CHANNEL_ID` | the 3 channel IDs |
| `MC_EMAIL` | the email of your Microsoft/Minecraft account |
| `MC_HOST` / `MC_PORT` | your server's **hub** address (where you first connect) |
| `MC_VERSION` | leave blank unless auto-detect fails |

### First run / Microsoft login

```bash
node index.js
```

The **first** time you `!start` the bot, it has no cached login, so it will print
(and also post in your **logs** channel) something like:

```
Go to https://microsoft.com/link and enter code ABCD-EFGH
```

Open that link on your phone/PC, sign in with the Minecraft account, enter the
code. That's it - the session token is cached in `mc-auth-cache/` so you won't
have to do this again unless you delete that folder or the token expires.

**Do not commit or share `mc-auth-cache/` or `.env` - they contain live
credentials.** Both are already in `.gitignore`.

## 4. Run it 24/7

The Discord bot needs to run all the time (so you can `!start` it whenever you
want), and `!restart` needs *something* outside the Node process to bring it
back after it exits. Pick one:

**Option A - the included run.sh (simplest, no extra software):**
```bash
chmod +x run.sh
nohup ./run.sh > bot.log 2>&1 &
```
This loops `node index.js` forever, so `!restart` (which calls `process.exit(0)`
internally) always comes back up in ~2 seconds.

**Option B - systemd (recommended if you want it to survive a VPS reboot too):**
```ini
# /etc/systemd/system/mc-afk-bot.service
[Unit]
Description=Minecraft AFK bot + Discord control
After=network.target

[Service]
WorkingDirectory=/path/to/mc-afk-bot
ExecStart=/usr/bin/node --max-old-space-size=220 index.js
Restart=always
RestartSec=2
User=youruser

[Install]
WantedBy=multi-user.target
```
```bash
sudo systemctl enable --now mc-afk-bot
```

Either way: you only ever need to `!start` the Minecraft bot once. If it's
online when you `!restart` (or the process crashes, or the VPS reboots with
systemd), it automatically resumes without you touching Discord again -
the login token is already cached, so no device-code step either.

## 5. Discord commands

All commands are **owner-only** (your `OWNER_ID`). Prefix is `!` by default
(change via `COMMAND_PREFIX` in `.env`).

| Command | What it does |
|---|---|
| `!start` | Connects the Minecraft bot |
| `!stop` | Disconnects it (so you can log in yourself) |
| `!restart` | Restarts **everything** - Minecraft bot + Discord bot |
| `!status` | Embed: online/offline, uptime, health, food, real ping, server, world, total playtime, RAM |
| `!chat <msg>` | Sends `<msg>` to **public** in-game chat |
| `!cmd <command>` | Runs `/command` in-game and replies with whatever the server printed back |
| `!msg <player> <msg>` / `!tell <player> <msg>` | Sends `/msg <player> <msg>` |
| `!r <msg>` | Sends `/r <msg>` (reply to last tell) |

**In the chat channel specifically**, anything you type that *isn't* a `!command`
gets sent to public in-game chat as-is. Anything that *is* a recognized command
(`!r`, `!msg`, `!tell`, etc.) is treated as a command and never leaks into public
chat. Other members typing in the chat channel are ignored entirely (this bot
only ever acts on your account).

## 6. Tuning to match your actual server

I can't see your server's real chat strings, kick messages, scoreboard layout,
or shard command - so `config.js` has sensible guesses with regexes you can
tweak. Everything is commented. The two most important bits to check first
run (watch the console, it logs every raw chat line):

- `patterns.hubJoined` / `patterns.smpJoined` / `patterns.queueStatus` - what
  your server actually prints when you join hub/smp/queue
- `scoreboard.pingLineRegex` - matches a scoreboard line containing "ping" and
  a number; adjust if your server's placeholder is labeled differently
- `shards.command` - whatever your server actually uses to claim shards
- `flow.afkWarpCommand` - e.g. `/warp afk`, if you want the bot to warp to your
  farm after joining smp (leave `""` to just stay wherever smp spawns you)

## Notes on anti-cheat / "bad packets"

The bot uses mineflayer's normal built-in physics, so it responds to knockback
and gravity the same way a real client would - nothing here is a packet
spoofer. If Vulcan is flagging `BadPackets`, by far the most common cause is a
**protocol version mismatch** (mineflayer guessing the wrong version). Set
`MC_VERSION` in `.env` explicitly to your server's exact version (e.g. `1.20.4`)
and that usually clears it up. No bot can guarantee it'll never be flagged -
that's ultimately between you and the server's staff/rules.

## Keeping RAM usage low

- `run.sh` and the systemd unit both cap Node's heap at 220MB (`--max-old-space-size`)
- `mc.viewDistance` is set to `"tiny"` in `config.js` (doesn't affect whether
  your farm's chunks stay loaded server-side - that's about your server's
  simulation distance and the bot being nearby, not the client's view distance)
- The Discord client is built with tiny cache limits (`makeCache`) and message
  sweeping enabled - it doesn't hoard guild member/message history like a
  default discord.js bot would
- `!status`'s RAM/ping numbers are only computed the moment you ask for them -
  nothing runs in the background polling memory, ping, or health
- The RAM watchdog only checks free OS counters (basically free) every 10 minutes

## Project layout

```
index.js              entry point, env validation, graceful shutdown
config.js              all the tunable/regex settings - edit this to match your server
src/minecraftBot.js    mineflayer bot: login, hub->smp flow, chat parsing, reconnect
src/discordBot.js      discord.js bot: commands, embeds, presence, channel routing
src/state.js           shared status + event bus between the two bots
src/playtime.js         persisted playtime tracker
src/runState.js         remembers "should be online" across restarts
src/ramInfo.js           RAM usage helpers (only run on demand)
src/ramWatchdog.js       10-min VPS memory check
src/logger.js            console logging
run.sh                  restart-forever wrapper (Option A above)
data/                   playtime.json + runstate.json get created here at runtime
mc-auth-cache/          Microsoft login token cache - created after first login
```
