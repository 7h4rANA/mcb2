# mc-afk-bot

A Minecraft AFK bot (mineflayer) controlled from Discord (discord.js), built to run
comfortably on a 512MB VPS. It's one Node.js process — not two — because running
Discord and Minecraft as separate processes would mean paying for two V8 runtimes,
which is real memory you don't have to spare.

What it does:
- Logs into the server with your **premium Microsoft account** (device-code flow, no password stored).
- Joins the hub, waits a few seconds, sends `/smp`, then just sits there.
- Requests a **view distance of 3** chunks from the server (less chunk data sent to the bot = less RAM/bandwidth).
- Reconnects automatically with backoff if disconnected, unless you told it to stop.
- Discord slash command `/mc start|stop|status` to control it and see health/position/uptime.

## 1. Create the Discord application

1. Go to the Discord Developer Portal → **New Application**.
2. **Bot** tab → Add Bot → copy the **token** (this is `DISCORD_TOKEN`).
3. **General Information** tab → copy the **Application ID** (this is `DISCORD_CLIENT_ID`).
4. **OAuth2 → URL Generator**: scopes `bot` + `applications.commands`, permission `Send Messages` +
   `Use Slash Commands`. Open the generated URL to invite it to your server.
5. Turn on Developer Mode in Discord (User Settings → Advanced), right-click yourself → **Copy User ID**
   → that's your `OWNER_IDS` value. Right-click your server → **Copy Server ID** → that's `DISCORD_GUILD_ID`
   (guild-scoped commands register instantly; global ones take up to ~1 hour).

## 2. Configure

```bash
cp .env.example .env
nano .env
```

Fill in `DISCORD_TOKEN`, `DISCORD_CLIENT_ID`, `DISCORD_GUILD_ID`, `OWNER_IDS`, `MC_HOST`, `MC_EMAIL`.
Leave `MC_VERSION` blank unless the server needs a specific one. `VIEW_DISTANCE=3` and
`JOIN_COMMAND=/smp` are already set to what you asked for.

## 3. Install and register commands

```bash
npm install --omit=dev
npm run deploy-commands   # only needs to be re-run if you change the slash commands
```

## 4. First run — Microsoft login

The first time the bot connects, Microsoft's device-code flow kicks in: a message like
*"open https://microsoft.com/link and enter code ABCD-EFGH"* appears in your console **and**,
if you set `STATUS_CHANNEL_ID`, is posted to that Discord channel too. Open the link on any
device, sign in with the Microsoft account that owns the license, enter the code. After that,
the token is cached under `auth_cache/` and you won't need to do this again unless you delete it
or it expires.

```bash
npm start
```

Once you see "Ready." in the logs, use `/mc start` in Discord.

## 5. Running it 24/7 on the VPS (512MB RAM)

Skip pm2 for a box this small — the pm2 daemon itself is another Node process and eats
50-100MB you don't have. A plain systemd unit does the same job (auto-restart, start on boot)
for near-zero overhead.

`/etc/systemd/system/mc-afk-bot.service`:

```ini
[Unit]
Description=Minecraft AFK bot + Discord control
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=youruser
WorkingDirectory=/home/youruser/mc-afk-bot
ExecStart=/usr/bin/node --max-old-space-size=384 index.js
Restart=on-failure
RestartSec=10
Environment=NODE_ENV=production

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl daemon-reload
sudo systemctl enable --now mc-afk-bot
sudo journalctl -u mc-afk-bot -f     # logs
```

### If the VPS doesn't have swap yet

On a 512MB box, add 512MB-1GB of swap so a transient spike (npm install, a big chunk burst)
doesn't get the process OOM-killed:

```bash
sudo fallocate -l 1G /swapfile && sudo chmod 600 /swapfile
sudo mkswap /swapfile && sudo swapon /swapfile
echo '/swapfile none swap sw 0 0' | sudo tee -a /etc/fstab
```

### What actually costs RAM here, and what I did about it

- Two Node processes (Discord + Minecraft separately) → merged into one process, one V8 heap.
- discord.js is opened with **only the `Guilds` intent** — no message content, no presence
  tracking, no member caching, since the bot never reads messages, only handles slash commands.
- No `pathfinder`, `prismarine-viewer`, or other mineflayer plugins are loaded — nothing here
  needs to move or render, so nothing extra is in memory.
- `viewDistance: 3` caps how many chunks the server sends, which is the single biggest lever
  on a bot that just stands still.
- `--max-old-space-size=384` caps the V8 heap so Node fails a GC before the OS OOM-kills the
  whole process (an OOM-kill loses the reconnect state; a capped heap can at least let it recover).

## 6. About Papyrus / FlameCord

FlameCord is a BungeeCord/Waterfall fork sold as an anti-bot/anti-VPN layer; I don't have
public documentation on "Papyrus" specifically, so I can't promise byte-for-byte compatibility.
What I can say: anti-bot systems like this are built to catch unauthenticated connection floods,
fake/offline accounts, and packet-level exploits — not a real, Microsoft-authenticated client that
completes a normal handshake, which is what this bot is. mineflayer implements the full protocol
(encryption, compression, keep-alives) so it looks like a normal client at the connection level.

Two things I deliberately did **not** try to build in:
- Anything that fakes human-like movement to dodge behavioural bot-detection — that crosses into
  actively evading anti-abuse systems, which isn't something I'll help engineer.
- Any kind of CAPTCHA/verification solver, if the network's anti-bot ever presents one. If that
  happens, the practical fix is asking the server's staff to allowlist the bot's account/IP — a
  normal, common request for utility/AFK bots, and one only they can grant.

If FlameCord's bot-check does block the first join, the most likely cause is connecting too fast
after a previous disconnect — the exponential backoff in `mcBot.js` (15s → up to 5min) already
guards against that, since a tight reconnect loop is exactly the pattern anti-bot systems flag as
a flood.

## Files

```
mc-afk-bot/
├── index.js              entry point, wires Discord + Minecraft together
├── src/
│   ├── config.js          loads/validates .env
│   ├── logger.js          tiny timestamped logger
│   ├── mcBot.js            mineflayer connection, reconnect/backoff, status
│   ├── discordBot.js       discord.js client, /mc command handling
│   └── deployCommands.js   one-off script to register the slash command
├── .env.example
└── package.json
```
