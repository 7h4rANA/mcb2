require('dotenv').config({ quiet: true });

const fs = require('node:fs');
const path = require('node:path');
const mineflayer = require('mineflayer');
const { Authflow, Titles } = require('prismarine-auth');
const { Client, GatewayIntentBits, ActivityType, Options } = require('discord.js');

const ROOT = path.resolve(__dirname, '..');
const AUTH_DIR = path.join(ROOT, 'auth-cache');
const LOG_DIR = path.join(ROOT, 'logs');
const RUNTIME_FILE = path.join(ROOT, 'config.runtime.json');
fs.mkdirSync(AUTH_DIR, { recursive: true, mode: 0o700 });
fs.mkdirSync(LOG_DIR, { recursive: true, mode: 0o700 });
try { fs.chmodSync(AUTH_DIR, 0o700); } catch {}

const env = (k, d = '') => process.env[k] || d;
const int = (k, d) => Number.isFinite(Number.parseInt(env(k, String(d)), 10)) ? Number.parseInt(env(k, String(d)), 10) : d;
const list = k => env(k).split(',').map(x => x.trim()).filter(Boolean);

const config = {
  mc: {
    host: env('MC_HOST'),
    port: int('MC_PORT', 25565),
    version: env('MC_VERSION', '1.21.11'),
    email: env('MC_EMAIL'),
    viewDistance: Math.min(3, Math.max(2, int('VIEW_DISTANCE', 3))),
    hubCommand: env('HUB_COMMAND', '/smp'),
    hubWaitMs: int('HUB_WAIT_MS', 5000),
    smpReadyTimeoutMs: int('SMP_READY_TIMEOUT_MS', 45000),
    authRefreshCooldownMs: int('AUTH_REFRESH_COOLDOWN_MS', 600000)
  },
  discord: {
    token: env('DISCORD_TOKEN'),
    owners: new Set(list('OWNER_USER_IDS')),
    log: env('LOG_CHANNEL_ID'),
    chat: env('CHAT_CHANNEL_ID'),
    report: env('REPORT_CHANNEL_ID')
  },
  reconnect: {
    min: int('RECONNECT_MIN_MS', 15000),
    max: int('RECONNECT_MAX_MS', 90000),
    maxHour: int('MAX_RECONNECTS_PER_HOUR', 8),
    papyrusMin: int('PAPYRUS_RECONNECT_MIN_MS', 60000),
    authRetry: int('AUTH_RETRY_MS', 30000)
  },
  alertCooldown: int('CHAT_ALERT_COOLDOWN_MS', 1500),
  commandWait: int('COMMAND_OUTPUT_MS', 3500),
  reportHour: int('DAILY_REPORT_HOUR', 23),
  reportMinute: int('DAILY_REPORT_MINUTE', 59),
  maxChars: int('LOG_MAX_CHARS', 1500),
  smpPatterns: list('SMP_SUCCESS_PATTERNS'),
  hubPatterns: list('HUB_SUCCESS_PATTERNS')
};

if (!config.mc.host || !config.mc.email || !config.discord.token || !config.discord.log || !config.discord.chat || !config.discord.report || !config.discord.owners.size) {
  console.error('Missing required .env values.'); process.exit(1);
}

if (fs.existsSync(RUNTIME_FILE)) {
  try {
    const r = JSON.parse(fs.readFileSync(RUNTIME_FILE, 'utf8'));
    if (Number.isFinite(r.viewDistance)) config.mc.viewDistance = Math.min(3, Math.max(2, r.viewDistance));
    for (const k of ['hubWaitMs', 'smpReadyTimeoutMs', 'alertCooldown', 'commandWait', 'maxChars']) if (Number.isFinite(r[k])) config[k] = r[k];
  } catch {}
}

const stats = {
  started: Date.now(), connected: 0, reconnects: 0, kicks: 0, errors: 0,
  chats: 0, commands: 0, authRefreshes: 0, papyrusRateLimits: 0,
  lastKick: '', lastError: '', lastEvent: 'boot'
};

let bot = null;
let stopping = false;
let reconnectTimer = null;
let reconnectDelay = config.reconnect.min;
let reconnectWindow = Date.now();
let reconnectsHour = 0;
let hubTimer = null;
let smpTimer = null;
let smpRequested = false;
let smpConfirmed = false;
let lastAlert = 0;
let collector = null;
let lastAuthRefresh = 0;
let authRefreshInFlight = false;
let connectionGeneration = 0;
let intentionalEnd = false;
const channels = { log: null, chat: null, report: null };

const discord = new Client({
  intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent],
  makeCache: Options.cacheWithLimits({
    MessageManager: 0, PresenceManager: 0, ReactionManager: 0, GuildMemberManager: 0,
    UserManager: 25, ThreadManager: 0, ThreadMemberManager: 0, VoiceStateManager: 0, StageInstanceManager: 0
  }),
  sweepers: { messages: { interval: 600, lifetime: 30 } }
});

const clean = v => {
  try {
    if (typeof v === 'string') return v.replace(/§./g, '');
    if (v?.text) return String(v.text).replace(/§./g, '');
    return JSON.stringify(v ?? '');
  } catch { return ''; }
};
const trim = s => String(s ?? '').slice(0, config.maxChars);
const fmtUptime = ms => {
  let s = Math.floor(ms / 1000);
  const d = Math.floor(s / 86400); s %= 86400;
  const h = Math.floor(s / 3600); s %= 3600;
  const m = Math.floor(s / 60);
  return `${d}d ${h}h ${m}m ${s % 60}s`;
};

async function send(kind, content) {
  const ch = channels[kind];
  if (!ch?.isTextBased()) return false;
  try {
    await ch.send({ content, allowedMentions: { parse: [] } });
    return true;
  } catch (e) {
    console.error(`Discord ${kind}:`, e.message);
    return false;
  }
}

async function log(msg, level = 'INFO') {
  const line = `[${new Date().toISOString()}] [${level}] ${msg}`;
  console.log(line);
  try { fs.appendFileSync(path.join(LOG_DIR, 'bot.log'), line + '\n'); } catch {}
  return send('log', `**[${level}]** ${trim(msg)}`);
}

function presence(online) {
  if (!discord.user) return;
  discord.user.setPresence({
    status: online ? 'online' : 'idle',
    activities: [{ name: `${online ? '🟢' : '🔴'} ${config.mc.host}`, type: ActivityType.Playing }]
  });
}

function messageMatches(text, patterns) {
  const l = text.toLowerCase();
  return patterns.length > 0 && patterns.some(p => l.includes(p.toLowerCase()));
}

function privateMsg(text) {
  return /(?:^|\s)(?:\/?tell|\/?msg|\/?w|whisper)(?:\s|:)/i.test(text) || /(?:whispers to you|-> you|to you:)/i.test(text);
}

function isAuthKick(text) {
  const t = text.toLowerCase();
  return t.includes('not authenticated with minecraft.net') || t.includes('not authenticated') || t.includes('invalid session') || t.includes('invalid token') || t.includes('failed to verify username');
}

function isPapyrusRateLimit(text) {
  const t = text.toLowerCase();
  return t.includes('connecting too quickly') || t.includes('slow down');
}

function saveRuntime() {
  try {
    fs.writeFileSync(RUNTIME_FILE, JSON.stringify({
      viewDistance: config.mc.viewDistance,
      hubWaitMs: config.mc.hubWaitMs,
      smpReadyTimeoutMs: config.mc.smpReadyTimeoutMs,
      alertCooldown: config.alertCooldown,
      commandWait: config.commandWait,
      maxChars: config.maxChars
    }, null, 2), { mode: 0o600 });
  } catch (e) { console.error('Runtime config save:', e.message); }
}

function clearTimers() {
  if (hubTimer) clearTimeout(hubTimer);
  if (smpTimer) clearTimeout(smpTimer);
  hubTimer = smpTimer = null;
  if (collector) {
    clearTimeout(collector.timer);
    collector = null;
  }
}

function resetReconnectWindow() {
  if (Date.now() - reconnectWindow >= 3600000) {
    reconnectWindow = Date.now();
    reconnectsHour = 0;
  }
}

function scheduleReconnect(reason, customDelay = null) {
  if (stopping || reconnectTimer) return;
  resetReconnectWindow();
  if (reconnectsHour >= config.reconnect.maxHour) {
    log(`Reconnect limit reached for this hour. Reason: ${reason}`, 'WARN');
    return;
  }

  let delay;
  if (customDelay != null) {
    delay = customDelay;
  } else if (reason === 'papyrus-rate-limit') {
    delay = Math.max(config.reconnect.papyrusMin, reconnectDelay);
    stats.papyrusRateLimits++;
  } else {
    delay = Math.min(config.reconnect.max, reconnectDelay + Math.floor(Math.random() * 3000));
  }

  reconnectsHour++;
  stats.reconnects++;
  log(`Reconnect scheduled in ${Math.round(delay / 1000)}s: ${reason}`, 'WARN');
  reconnectTimer = setTimeout(() => {
    reconnectTimer = null;
    connectMinecraft();
  }, delay);

  if (reason !== 'papyrus-rate-limit') reconnectDelay = Math.min(config.reconnect.max, Math.floor(reconnectDelay * 1.6));
}

function destroyMinecraft(reason = 'controller stop') {
  clearTimers();
  const old = bot;
  bot = null;
  stats.connected = 0;
  presence(false);
  intentionalEnd = true;
  connectionGeneration++;
  if (old) {
    try { old.quit(reason); } catch {}
  }
}

async function validateMicrosoftSession(forceRefresh = false) {
  if (authRefreshInFlight) return authRefreshInFlight;
  authRefreshInFlight = (async () => {
    const started = Date.now();
    const auth = new Authflow(config.mc.email, AUTH_DIR, {
      flow: 'live',
      // Use a known Microsoft client title so prismarine-auth can perform the live/device flow.
      // This title is also used by established Mineflayer Microsoft-auth setups.
      authTitle: Titles.MinecraftNintendoSwitch,
      deviceType: 'Nintendo',
      forceRefresh
    }, data => {
      // Keep the device-code login visible in VPS terminal logs without leaking tokens.
      console.log(`[AUTH] Sign in at ${data.verification_uri} with code ${data.user_code}`);
      log(`Microsoft login required. Visit ${data.verification_uri} and enter code ${data.user_code}.`, 'AUTH');
    });
    try {
      const result = await auth.getMinecraftJavaToken({ fetchProfile: true, fetchEntitlements: true });
      if (!result?.token || !result?.profile?.name) throw new Error('Microsoft authentication returned no Minecraft Java profile.');
      const took = Date.now() - started;
      stats.lastEvent = `auth-ok:${result.profile.name}`;
      log(`Microsoft session valid for ${result.profile.name} (${took}ms).`);
      return result;
    } catch (e) {
      stats.lastError = e?.message || String(e);
      stats.errors++;
      log(`Microsoft authentication failed: ${trim(stats.lastError)}`, 'ERROR');
      throw e;
    } finally {
      authRefreshInFlight = false;
    }
  })();
  return authRefreshInFlight;
}

async function ensureAuthFresh(forceRefresh = false) {
  const now = Date.now();
  if (!forceRefresh && lastAuthRefresh && now - lastAuthRefresh < config.mc.authRefreshCooldownMs) return true;
  const result = await validateMicrosoftSession(forceRefresh);
  lastAuthRefresh = Date.now();
  return !!result;
}

function scheduleSmp(gen) {
  if (!bot || stopping || smpRequested || gen !== connectionGeneration) return;
  smpRequested = true;
  hubTimer = setTimeout(() => {
    if (!bot || stopping || gen !== connectionGeneration) return;
    try {
      const command = config.mc.hubCommand.startsWith('/') ? config.mc.hubCommand : `/${config.mc.hubCommand}`;
      bot.chat(command);
      stats.commands++;
      stats.lastEvent = 'smp-command-sent';
      log(`Sent ${command}`);
    } catch (e) {
      stats.errors++;
      stats.lastError = e.message;
      log(`SMP command failed: ${e.message}`, 'ERROR');
      return;
    }
    smpTimer = setTimeout(() => {
      if (!smpConfirmed && gen === connectionGeneration) log(`SMP not confirmed after ${config.mc.smpReadyTimeoutMs}ms.`, 'WARN');
    }, config.mc.smpReadyTimeoutMs);
  }, config.mc.hubWaitMs);
}

function confirmSmp(src) {
  if (smpRequested && !smpConfirmed) {
    smpConfirmed = true;
    if (smpTimer) clearTimeout(smpTimer);
    smpTimer = null;
    stats.lastEvent = 'smp-ready';
    log(`SMP ready (${src})`);
  }
}

function onMcMessage(msg) {
  const text = clean(msg);
  if (!text) return;
  if (collector) collector.lines.push(text);
  if (!smpRequested && messageMatches(text, config.hubPatterns)) scheduleSmp(connectionGeneration);
  if (smpRequested && messageMatches(text, config.smpPatterns)) confirmSmp('message');

  const name = bot?.username || '';
  if (name && (text.toLowerCase().includes(name.toLowerCase()) || privateMsg(text))) {
    const now = Date.now();
    if (now - lastAlert >= config.alertCooldown) {
      lastAlert = now;
      send('chat', `🚨 ${trim(text)}`);
    }
  }
}

async function handleDisconnect(reason, gen, oldBot) {
  if (gen !== connectionGeneration) return;
  stats.connected = 0;
  presence(false);
  if (bot === oldBot) {
    bot = null;
    connectionGeneration++;
  }

  if (stopping || intentionalEnd) {
    intentionalEnd = false;
    return;
  }

  const text = clean(reason);
  if (isAuthKick(stats.lastKick || text)) {
    if (Date.now() - lastAuthRefresh < config.mc.authRefreshCooldownMs) {
      log('Authentication kick detected again before refresh cooldown elapsed; waiting before retry.', 'WARN');
      scheduleReconnect('auth-kick', config.reconnect.authRetry);
      return;
    }
    try {
      log('Authentication kick detected. Refreshing Microsoft/Minecraft session before reconnecting.', 'WARN');
      await ensureAuthFresh(true);
      stats.authRefreshes++;
      reconnectDelay = config.reconnect.min;
      scheduleReconnect('auth-refresh', config.reconnect.authRetry);
    } catch {
      scheduleReconnect('auth-refresh-failed', 60000);
    }
    return;
  }

  if (isPapyrusRateLimit(stats.lastKick || text)) {
    scheduleReconnect('papyrus-rate-limit', config.reconnect.papyrusMin);
    return;
  }

  scheduleReconnect('end');
}

async function connectMinecraft() {
  if (stopping || bot) return;
  clearTimers();
  smpRequested = false;
  smpConfirmed = false;
  intentionalEnd = false;
  const gen = ++connectionGeneration;
  stats.lastEvent = 'authenticating';
  presence(false);

  try {
    await ensureAuthFresh(false);
  } catch (e) {
    log(`Will retry Minecraft login after authentication failure: ${trim(e.message || e)}`, 'ERROR');
    if (!stopping) scheduleReconnect('authentication-failed', 60000);
    return;
  }

  if (stopping || gen !== connectionGeneration) return;
  log(`Connecting ${config.mc.host}:${config.mc.port}`);

  try {
    const newBot = mineflayer.createBot({
      host: config.mc.host,
      port: config.mc.port,
      username: config.mc.email,
      auth: 'microsoft',
      profilesFolder: AUTH_DIR,
      authTitle: Titles.MinecraftNintendoSwitch,
      version: config.mc.version,
      viewDistance: config.mc.viewDistance,
      physicsEnabled: true,
      hideErrors: false,
      checkTimeoutInterval: 30000,
      clientSettings: { viewDistance: config.mc.viewDistance }
    });
    bot = newBot;

    newBot.once('login', () => {
      if (gen !== connectionGeneration) return;
      stats.lastEvent = `login:${newBot.username || 'unknown'}`;
      reconnectDelay = config.reconnect.min;
      log(`Minecraft login as ${newBot.username || 'unknown'}`);
    });

    newBot.once('spawn', () => {
      if (gen !== connectionGeneration) return;
      stats.connected = Date.now();
      stats.lastEvent = 'spawn';
      reconnectDelay = config.reconnect.min;
      presence(true);
      log(`Spawned as ${newBot.username || 'unknown'}. Physics enabled; view distance ${config.mc.viewDistance}.`);
      scheduleSmp(gen);
    });

    newBot.on('respawn', () => {
      if (gen !== connectionGeneration) return;
      stats.lastEvent = 'respawn';
      if (smpRequested) confirmSmp('respawn');
    });

    newBot.on('message', onMcMessage);
    newBot.on('chat', (username, message) => {
      if (username === newBot.username) return;
      stats.chats++;
      send('chat', `💬 <${username}> ${trim(message)}`);
      if (newBot.username && message.toLowerCase().includes(newBot.username.toLowerCase())) {
        const now = Date.now();
        if (now - lastAlert >= config.alertCooldown) {
          lastAlert = now;
          send('chat', `🔔 <${username}> mentioned ${newBot.username}: ${trim(message)}`);
        }
      }
    });

    newBot._client.on('set_entity_velocity', p => {
      if (gen !== connectionGeneration) return;
      if (newBot.entity && p?.entityId === newBot.entity.id) {
        stats.lastEvent = `velocity ${p.velocityX},${p.velocityY},${p.velocityZ}`;
      }
    });

    newBot.once('kicked', async reason => {
      if (gen !== connectionGeneration) return;
      stats.kicks++;
      stats.lastKick = clean(reason);
      stats.connected = 0;
      stats.lastEvent = 'kicked';
      presence(false);
      const authKick = isAuthKick(stats.lastKick);
      const rateKick = isPapyrusRateLimit(stats.lastKick);
      log(`Kicked: ${trim(stats.lastKick)}`, 'WARN');
      if (!stopping) {
        if (authKick) await handleDisconnect(stats.lastKick, gen, newBot);
        else if (rateKick) {
          await handleDisconnect(stats.lastKick, gen, newBot);
        } else {
          await handleDisconnect(stats.lastKick, gen, newBot);
        }
      }
    });

    newBot.once('error', e => {
      if (gen !== connectionGeneration) return;
      stats.errors++;
      stats.lastError = e?.message || String(e);
      stats.lastEvent = 'error';
      log(`Minecraft error: ${trim(stats.lastError)}`, 'ERROR');
    });

    newBot.once('end', reason => {
      if (gen !== connectionGeneration) return;
      const endReason = clean(reason || 'unknown');
      stats.connected = 0;
      stats.lastEvent = 'end';
      presence(false);
      log(`Connection ended: ${trim(endReason)}`, 'WARN');
      handleDisconnect(endReason, gen, newBot).catch(e => log(`Disconnect handler failed: ${e.message}`, 'ERROR'));
    });
  } catch (e) {
    stats.errors++;
    stats.lastError = e.message;
    bot = null;
    log(`createBot failed: ${trim(e.message)}`, 'ERROR');
    scheduleReconnect('createBot', config.reconnect.min);
  }
}

function statusText() {
  const online = !!bot && !!stats.connected;
  const mem = process.memoryUsage();
  const pos = bot?.entity?.position?.floored?.().toString() || 'n/a';
  return [
    `**Minecraft:** ${online ? '🟢 ONLINE' : '🔴 OFFLINE'}`,
    `**Account:** ${bot?.username || config.mc.email}`,
    `**Server:** \`${config.mc.host}:${config.mc.port}\``,
    `**View distance:** ${config.mc.viewDistance} (7x7 target)`,
    `**Uptime:** ${fmtUptime(Date.now() - stats.started)}`,
    `**MC session:** ${online ? fmtUptime(Date.now() - stats.connected) : 'offline'}`,
    `**Position:** ${pos}`,
    `**Reconnects:** ${stats.reconnects}`,
    `**Kicks:** ${stats.kicks}`,
    `**Auth refreshes:** ${stats.authRefreshes}`,
    `**Papyrus rate limits:** ${stats.papyrusRateLimits}`,
    `**Errors:** ${stats.errors}`,
    `**Chat:** ${stats.chats}`,
    `**Commands:** ${stats.commands}`,
    `**RSS:** ${(mem.rss / 1048576).toFixed(1)} MB`,
    `**Heap:** ${(mem.heapUsed / 1048576).toFixed(1)} MB`,
    `**Last:** ${stats.lastEvent}`,
    stats.lastKick ? `**Last kick:** ${trim(stats.lastKick)}` : '',
    stats.lastError ? `**Last error:** ${trim(stats.lastError)}` : ''
  ].filter(Boolean).join('\n');
}

async function dailyReport() {
  const mem = process.memoryUsage();
  await send('report', `📊 **Daily performance**\n${statusText()}\n**Node:** ${process.version} | **RSS:** ${(mem.rss / 1048576).toFixed(1)} MB | **Heap:** ${(mem.heapUsed / 1048576).toFixed(1)} MB`);
}

function scheduleReport() {
  const tick = () => {
    const now = new Date();
    const target = new Date(now);
    target.setHours(config.reportHour, config.reportMinute, 0, 0);
    if (target <= now) target.setDate(target.getDate() + 1);
    setTimeout(async () => { await dailyReport(); tick(); }, Math.max(1000, target - now));
  };
  tick();
}

const runtimeKeys = ['viewDistance', 'hubWaitMs', 'smpReadyTimeoutMs', 'alertCooldown', 'commandWait', 'maxChars'];
function setRuntime(k, v) {
  if (!runtimeKeys.includes(k)) return `Allowed: ${runtimeKeys.join(', ')}`;
  const n = Number(v);
  if (!Number.isFinite(n)) return 'Value must be numeric.';
  if (k === 'viewDistance') config.mc.viewDistance = Math.min(3, Math.max(2, n));
  else if (k === 'hubWaitMs') config.mc.hubWaitMs = Math.min(30000, Math.max(1000, n));
  else if (k === 'smpReadyTimeoutMs') config.mc.smpReadyTimeoutMs = Math.min(120000, Math.max(5000, n));
  else if (k === 'alertCooldown') config.alertCooldown = Math.min(30000, Math.max(250, n));
  else if (k === 'commandWait') config.commandWait = Math.min(15000, Math.max(1000, n));
  else config.maxChars = Math.min(1800, Math.max(500, n));
  saveRuntime();
  return `Set ${k}=${n}.`;
}

async function discordCommand(m) {
  if (m.author.bot || !m.content.startsWith('!')) return;
  if (!config.discord.owners.has(m.author.id)) return m.reply('❌ Not authorized.');
  const a = m.content.trim().split(/\s+/);
  const cmd = a.shift().slice(1).toLowerCase();
  const rest = a.join(' ');

  if (cmd === 'help') return m.reply('`!start` `!stop` `!status` `!chat <text>` `!cmd <command>` `!config [key value]`');
  if (cmd === 'start') {
    if (bot) return m.reply('🟡 Already connected/connecting.');
    stopping = false; intentionalEnd = false; reconnectDelay = config.reconnect.min; connectMinecraft();
    return m.reply('🟢 Start requested. Microsoft session will be validated before connection.');
  }
  if (cmd === 'stop') {
    stopping = true;
    if (reconnectTimer) { clearTimeout(reconnectTimer); reconnectTimer = null; }
    destroyMinecraft();
    return m.reply('🔴 Stopped. You can log in.');
  }
  if (cmd === 'status') return m.reply(statusText());
  if (cmd === 'chat') {
    if (!bot) return m.reply('❌ Minecraft is offline.');
    if (!rest) return m.reply('Usage: !chat <message>');
    if (rest.length > 256) return m.reply('❌ Max 256 chars.');
    try { bot.chat(rest); stats.commands++; return m.reply('💬 Sent.'); } catch (e) { return m.reply(`❌ ${e.message}`); }
  }
  if (cmd === 'cmd') {
    if (!bot) return m.reply('❌ Minecraft is offline.');
    if (!rest) return m.reply('Usage: !cmd <command>');
    if (rest.length > 240) return m.reply('❌ Command too long.');
    if (collector) return m.reply('⏳ Another command is collecting output.');
    const c = rest.startsWith('/') ? rest.slice(1) : rest;
    collector = { lines: [], timer: null };
    try {
      bot.chat('/' + c);
      stats.commands++;
      collector.timer = setTimeout(() => {
        const lines = collector?.lines || [];
        collector = null;
        send('log', `🧾 **/${c}**\n\`\`\`\n${trim(lines.join('\n') || '(no output captured)')}\n\`\`\``);
      }, config.commandWait);
      return m.reply('⚙️ Command sent; output is in logs.');
    } catch (e) { collector = null; return m.reply(`❌ ${e.message}`); }
  }
  if (cmd === 'config') {
    if (!a.length) return m.reply(`viewDistance=${config.mc.viewDistance}\nhubWaitMs=${config.mc.hubWaitMs}\nsmpReadyTimeoutMs=${config.mc.smpReadyTimeoutMs}\nalertCooldown=${config.alertCooldown}\ncommandWait=${config.commandWait}\nmaxChars=${config.maxChars}`);
    if (a.length < 2) return m.reply('Usage: !config <key> <number>');
    return m.reply(setRuntime(a[0], a[1]));
  }
}

discord.once('ready', async () => {
  console.log(`Discord ready as ${discord.user.tag}`);
  for (const [k, id] of Object.entries({ log: config.discord.log, chat: config.discord.chat, report: config.discord.report })) {
    try { channels[k] = await discord.channels.fetch(id); }
    catch (e) { console.error(`Channel ${k}:`, e.message); }
  }
  presence(false);
  scheduleReport();
  await log(`Controller online; MC=${config.mc.host}:${config.mc.port}; Microsoft auth preflight enabled.`);
  stopping = false;
  connectMinecraft();
});

discord.on('messageCreate', m => discordCommand(m).catch(e => console.error('Discord command:', e.message)));
discord.on('error', e => console.error('Discord:', e.message));
process.on('unhandledRejection', e => { stats.errors++; stats.lastError = e?.message || String(e); console.error('Unhandled rejection:', e); });
process.on('uncaughtException', e => { stats.errors++; stats.lastError = e?.message || String(e); console.error('Uncaught exception:', e); });

async function shutdown() {
  if (stopping) return;
  stopping = true;
  if (reconnectTimer) clearTimeout(reconnectTimer);
  destroyMinecraft('controller shutdown');
  try { await discord.destroy(); } catch {}
  process.exit(0);
}

process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);
discord.login(config.discord.token).catch(e => { console.error('Discord login failed:', e.message); process.exit(1); });
