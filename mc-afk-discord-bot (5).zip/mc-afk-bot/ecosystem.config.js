module.exports = {
  apps: [
    {
      name: 'mc-afk-bot',
      script: 'src/index.js',
      cwd: __dirname,
      instances: 1,
      exec_mode: 'fork',
      autorestart: true,
      // Low-end VPS: restart if the process somehow balloons past this
      // instead of letting it drag the whole box down.
      max_memory_restart: '350M',
      restart_delay: 5000,
      max_restarts: 20,
      env: {
        NODE_ENV: 'production',
      },
    },
  ],
};
