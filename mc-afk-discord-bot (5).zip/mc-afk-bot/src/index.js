'use strict';

require('dotenv').config();

const [nodeMajor] = process.versions.node.split('.').map(Number);
if (nodeMajor < 22) {
  console.error(
    `[fatal] Node.js ${process.versions.node} is too old - this bot needs Node 22 or newer.\n` +
      `An old Node version is the most common cause of confusing dependency errors ` +
      `(e.g. "windows.InventoryWindow is not a constructor") because npm silently ` +
      `resolves older, incompatible package versions to stay compatible with it.\n` +
      `See README section 2 for how to install a current Node.js version.`
  );
  process.exit(1);
}

const config = require('./config/configManager');
const { McController } = require('./minecraft/mcController');
const { createDiscordController } = require('./discord/discordController');

if (!process.env.DISCORD_TOKEN) {
  console.error('[fatal] DISCORD_TOKEN is not set. Copy .env.example to .env and fill it in.');
  process.exit(1);
}

const mc = new McController(config);
const client = createDiscordController(config, mc, process.env.DISCORD_TOKEN);

async function shutdown(signal) {
  console.log(`\n[index] Received ${signal}, shutting down...`);
  try {
    await mc.stop();
  } catch {
    /* ignore - we're exiting anyway */
  }
  client.destroy();
  process.exit(0);
}

process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));

process.on('uncaughtException', (err) => {
  console.error('[fatal] Uncaught exception:', err);
});
process.on('unhandledRejection', (err) => {
  console.error('[fatal] Unhandled rejection:', err);
});
