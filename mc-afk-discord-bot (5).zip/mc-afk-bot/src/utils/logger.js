'use strict';

const { EmbedBuilder } = require('discord.js');

const COLORS = {
  info: 0x5865f2,
  success: 0x57f287,
  warn: 0xfee75c,
  error: 0xed4245,
};

/**
 * Thin wrapper that writes to the console immediately (so `pm2 logs` always
 * has a full record) and, once the Discord client + logs channel are ready,
 * also mirrors the message into the logs channel as a small embed.
 */
class Logger {
  constructor() {
    this.channel = null; // set by discordController once the client is ready
  }

  bindChannel(channel) {
    this.channel = channel;
  }

  async _emit(level, title, description) {
    const consoleFn = level === 'error' ? console.error : console.log;
    consoleFn(`[${level.toUpperCase()}] ${title}${description ? ' - ' + description : ''}`);

    if (!this.channel) return;
    try {
      const embed = new EmbedBuilder()
        .setColor(COLORS[level] || COLORS.info)
        .setTitle(title)
        .setTimestamp();
      if (description) embed.setDescription(String(description).slice(0, 4000));
      await this.channel.send({ embeds: [embed] });
    } catch (err) {
      console.error('[logger] Failed to send log embed to Discord:', err.message);
    }
  }

  info(title, description) {
    return this._emit('info', title, description);
  }
  success(title, description) {
    return this._emit('success', title, description);
  }
  warn(title, description) {
    return this._emit('warn', title, description);
  }
  error(title, description) {
    return this._emit('error', title, description);
  }
}

module.exports = new Logger();
