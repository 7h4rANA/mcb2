'use strict';

function getRamUsage() {
  const mem = process.memoryUsage();
  const mb = (bytes) => (bytes / 1024 / 1024).toFixed(1);
  return {
    rssMb: mb(mem.rss), // total resident memory - the closest number to "what does this process cost the VPS"
    heapUsedMb: mb(mem.heapUsed),
    heapTotalMb: mb(mem.heapTotal),
  };
}

module.exports = { getRamUsage };
