'use strict';

const fs = require('fs');
const path = require('path');

const CONFIG_PATH = path.join(__dirname, '..', '..', 'config', 'config.json');
const EXAMPLE_PATH = path.join(__dirname, '..', '..', 'config', 'config.example.json');

// Fields that are arrays of IDs and get special add/remove helpers instead of
// being overwritten wholesale by `!config set`.
const ARRAY_ID_FIELDS = ['discord.ownerIds', 'discord.subOwnerIds'];

class ConfigManager {
  constructor() {
    this.data = this._load();
  }

  _load() {
    if (!fs.existsSync(CONFIG_PATH)) {
      if (!fs.existsSync(EXAMPLE_PATH)) {
        throw new Error(`Missing both config/config.json and config/config.example.json`);
      }
      fs.copyFileSync(EXAMPLE_PATH, CONFIG_PATH);
      console.log('[config] config/config.json did not exist - created it from config.example.json.');
      console.log('[config] Edit config/config.json (or use !config in Discord) before starting the bot.');
    }
    const raw = fs.readFileSync(CONFIG_PATH, 'utf8');
    return JSON.parse(raw);
  }

  _save() {
    fs.writeFileSync(CONFIG_PATH, JSON.stringify(this.data, null, 2) + '\n', 'utf8');
  }

  /** Read a dot-path, e.g. "minecraft.host" */
  get(keyPath) {
    return keyPath.split('.').reduce((obj, key) => (obj == null ? undefined : obj[key]), this.data);
  }

  /** Write a dot-path and persist to disk. Coerces "true"/"false"/numbers automatically. */
  set(keyPath, rawValue) {
    if (ARRAY_ID_FIELDS.includes(keyPath)) {
      throw new Error(`"${keyPath}" is a list - use the add/remove owner commands instead of !config set.`);
    }
    const keys = keyPath.split('.');
    let obj = this.data;
    for (let i = 0; i < keys.length - 1; i++) {
      if (typeof obj[keys[i]] !== 'object' || obj[keys[i]] === null) obj[keys[i]] = {};
      obj = obj[keys[i]];
    }
    obj[keys[keys.length - 1]] = this._coerce(rawValue);
    this._save();
    return obj[keys[keys.length - 1]];
  }

  _coerce(value) {
    if (value === 'true') return true;
    if (value === 'false') return false;
    if (value !== '' && !isNaN(Number(value))) return Number(value);
    return value;
  }

  addToList(keyPath, value) {
    const list = this.get(keyPath);
    if (!Array.isArray(list)) throw new Error(`"${keyPath}" is not a list.`);
    if (!list.includes(value)) list.push(value);
    this._save();
    return list;
  }

  removeFromList(keyPath, value) {
    const list = this.get(keyPath);
    if (!Array.isArray(list)) throw new Error(`"${keyPath}" is not a list.`);
    const idx = list.indexOf(value);
    if (idx !== -1) list.splice(idx, 1);
    this._save();
    return list;
  }

  isOwner(userId) {
    return (this.get('discord.ownerIds') || []).map(String).includes(String(userId));
  }

  isSubOwner(userId) {
    return (this.get('discord.subOwnerIds') || []).map(String).includes(String(userId));
  }

  isAuthorized(userId) {
    return this.isOwner(userId) || this.isSubOwner(userId);
  }
}

module.exports = new ConfigManager();
