'use strict';

/**
 * Small, harmless keep-alive actions: an occasional slight look/turn and,
 * sometimes, a short jump. This is only here to stop vanilla/plugin
 * inactivity-kick timers from firing on a bot that would otherwise never
 * send any input at all - it does not move the bot around the map, take
 * knockback into its own hands, or otherwise interfere with the normal
 * physics mineflayer already applies (gravity, knockback from hits, etc.
 * all still happen exactly as they would for a real client).
 */
class AntiAfk {
  constructor(config) {
    this.config = config;
    this._timer = null;
  }

  start(bot) {
    this.stop();
    const cfg = this.config.get('minecraft.antiAfk');
    if (!cfg || cfg.enabled === false) return;
    const schedule = () => {
      const delay = randInt(cfg.minIntervalMs || 20000, cfg.maxIntervalMs || 45000);
      this._timer = setTimeout(() => {
        this._tick(bot, cfg);
        schedule();
      }, delay);
    };
    schedule();
  }

  stop() {
    if (this._timer) clearTimeout(this._timer);
    this._timer = null;
  }

  _tick(bot, cfg) {
    if (!bot || !bot.entity) return;
    try {
      const yaw = bot.entity.yaw + (Math.random() - 0.5) * 0.6;
      const pitch = Math.max(-1.4, Math.min(1.4, bot.entity.pitch + (Math.random() - 0.5) * 0.3));
      bot.look(yaw, pitch, true);

      if (Math.random() < (cfg.jumpChance ?? 0.25)) {
        bot.setControlState('jump', true);
        setTimeout(() => bot.setControlState('jump', false), 250);
      }
    } catch {
      // Bot may have just disconnected mid-tick - safe to ignore, the next
      // reconnect cycle will call start() again.
    }
  }
}

function randInt(min, max) {
  return Math.floor(min + Math.random() * (max - min));
}

module.exports = { AntiAfk };
