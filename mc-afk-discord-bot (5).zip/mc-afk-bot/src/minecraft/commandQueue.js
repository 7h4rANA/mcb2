'use strict';

/**
 * Every chat line and slash-command we send to the server (/server smp,
 * /tell, /cmd output requests, !chat messages, etc.) goes through this
 * single queue instead of being sent immediately. Most networks - and
 * Flamecord's anti-bot layer in particular - will kick a connection that
 * sends messages too quickly, so we always wait `delayMs` between sends,
 * no matter which part of the bot triggered them.
 */
class CommandQueue {
  constructor(getBot, getDelayMs) {
    this._getBot = getBot;
    this._getDelayMs = getDelayMs;
    this._queue = [];
    this._running = false;
  }

  /** Queue a raw line to send via bot.chat(). Returns a promise that resolves once it's actually sent. */
  push(line) {
    return new Promise((resolve, reject) => {
      this._queue.push({ line, resolve, reject });
      this._pump();
    });
  }

  clear() {
    this._queue.length = 0;
  }

  async _pump() {
    if (this._running) return;
    this._running = true;
    while (this._queue.length > 0) {
      const { line, resolve, reject } = this._queue.shift();
      const bot = this._getBot();
      try {
        if (!bot) throw new Error('Bot is not connected.');
        bot.chat(line);
        resolve();
      } catch (err) {
        reject(err);
      }
      if (this._queue.length > 0) {
        await sleep(this._getDelayMs());
      }
    }
    this._running = false;
  }
}

function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

module.exports = { CommandQueue, sleep };
