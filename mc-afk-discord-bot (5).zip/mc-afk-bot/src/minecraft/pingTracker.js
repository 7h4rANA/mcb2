'use strict';

/**
 * WHY THIS EXISTS
 * ----------------
 * The Minecraft protocol has no "client pings server" packet - only the
 * server-initiated keep_alive, which the SERVER times to calculate the
 * ping number you see in the tab list. A bot has no built-in way to
 * measure a true independent round-trip, and on some proxies (including
 * anti-bot proxies like Flamecord) the displayed ping for non-standard
 * clients can be wrong or static.
 *
 * What we CAN measure honestly, client-side, is the timing between
 * successive keep_alive packets we receive. On a healthy connection this
 * arrives at a very stable interval set by the server. We track the
 * smallest interval we've seen as a "baseline" and report how far above
 * that baseline the most recent interval was - i.e. added latency/jitter.
 * This is not a lab-accurate RTT, but unlike a static/fake displayed
 * value it actually moves when your connection to the proxy degrades,
 * which is what you actually care about for an AFK bot.
 *
 * We report BOTH this estimate and the server-reported bot.player.ping in
 * !status, clearly labeled, so you can compare them yourself.
 */
class PingTracker {
  constructor() {
    this._lastKeepAliveAt = null;
    this._baselineIntervalMs = null;
    this._estimatedMs = null;
  }

  attach(bot) {
    // bot._client is the underlying node-minecraft-protocol connection.
    // Listening here does not stop mineflayer's own automatic keep-alive
    // reply - it just lets us also observe the timing.
    bot._client.on('keep_alive', () => {
      const now = Date.now();
      if (this._lastKeepAliveAt !== null) {
        const interval = now - this._lastKeepAliveAt;
        if (this._baselineIntervalMs === null || interval < this._baselineIntervalMs) {
          this._baselineIntervalMs = interval;
        }
        this._estimatedMs = Math.max(0, interval - this._baselineIntervalMs);
      }
      this._lastKeepAliveAt = now;
    });
  }

  reset() {
    this._lastKeepAliveAt = null;
    this._baselineIntervalMs = null;
    this._estimatedMs = null;
  }

  /** Our own jitter-based estimate, or null if we don't have two samples yet. */
  getEstimatedMs() {
    return this._estimatedMs;
  }
}

module.exports = { PingTracker };
