'use strict';

const { EmbedBuilder } = require('discord.js');
const embeds = require('./embeds');
const configPanel = require('./configPanel');

/**
 * Each command declares:
 *   allowedChannels - which of the three configured channels it may run in
 *   ownerOnly        - true if sub-owners are NOT allowed to run it
 *   run(ctx)          - ctx = { message, args, mc, config }
 */
const commands = {
  help: {
    allowedChannels: ['commands', 'chat'],
    ownerOnly: false,
    async run({ message }) {
      const embed = new EmbedBuilder()
        .setColor(0x5865f2)
        .setTitle('Bot commands')
        .setDescription(
          [
            '**!start** - connect, join the hub, then the SMP',
            '**!stop** - disconnect (no auto-reconnect) so you can log in yourself',
            '**!restart** - stop then start again',
            '**!status** - connection/health/ping/RAM info',
            '**!chat <message>** - speak in public chat',
            '**!tell <player> <message>** - send a /tell',
            '**!cmd <command>** - run any in-game command and get the output',
            '**!login / !logout** - manage the saved Microsoft session (owner only)',
            '**!config ...** - view/edit settings (owner only)',
          ].join('\n')
        );
      await message.reply({ embeds: [embed] });
    },
  },

  start: {
    allowedChannels: ['commands'],
    ownerOnly: false,
    async run({ message, mc }) {
      const ack = await message.reply('🔄 Starting the bot - this can take up to a minute for the first sign-in...');
      try {
        await mc.start();
        await ack.channel.send({ embeds: [embeds.statusEmbed(mc.getStatusData())] });
      } catch (err) {
        console.error('[mc] !start failed:', err);
        await ack.channel.send(`❌ Failed to start: ${err.message}\n(Full error is in the console/\`pm2 logs\`.)`);
      }
    },
  },

  stop: {
    allowedChannels: ['commands'],
    ownerOnly: false,
    async run({ message, mc }) {
      await mc.stop();
      await message.reply('🛑 Stopped. It will not auto-reconnect until you run `!start` again - safe to log in yourself now.');
    },
  },

  restart: {
    allowedChannels: ['commands'],
    ownerOnly: false,
    async run({ message, mc }) {
      const ack = await message.reply('🔁 Restarting...');
      try {
        await mc.restart();
        await ack.channel.send({ embeds: [embeds.statusEmbed(mc.getStatusData())] });
      } catch (err) {
        console.error('[mc] !restart failed:', err);
        await ack.channel.send(`❌ Failed to restart: ${err.message}\n(Full error is in the console/\`pm2 logs\`.)`);
      }
    },
  },

  status: {
    allowedChannels: ['commands', 'chat'],
    ownerOnly: false,
    async run({ message, mc }) {
      await message.reply({ embeds: [embeds.statusEmbed(mc.getStatusData())] });
    },
  },

  chat: {
    allowedChannels: ['commands', 'chat'],
    ownerOnly: false,
    async run({ message, args, mc }) {
      const text = args.join(' ').trim();
      if (!text) return void message.reply('Usage: `!chat <message>`');
      try {
        await mc.sendPublicChat(text);
        await message.react('✅').catch(() => {});
      } catch (err) {
        await message.reply(`❌ ${err.message}`);
      }
    },
  },

  tell: {
    allowedChannels: ['commands', 'chat'],
    ownerOnly: false,
    async run({ message, args, mc }) {
      const [target, ...rest] = args;
      const text = rest.join(' ').trim();
      if (!target || !text) return void message.reply('Usage: `!tell <player> <message>`');
      try {
        await mc.sendTell(target, text);
        await message.react('✅').catch(() => {});
      } catch (err) {
        await message.reply(`❌ ${err.message}`);
      }
    },
  },

  cmd: {
    allowedChannels: ['commands'],
    ownerOnly: false,
    async run({ message, args, mc }) {
      const command = args.join(' ').trim();
      if (!command) return void message.reply('Usage: `!cmd <command>` (no leading slash needed)');
      try {
        const lines = await mc.captureCommandOutput(command);
        await message.reply({ embeds: [embeds.cmdOutputEmbed(command, lines)] });
      } catch (err) {
        await message.reply(`❌ ${err.message}`);
      }
    },
  },

  login: {
    allowedChannels: ['commands'],
    ownerOnly: true,
    async run(ctx) {
      // Logging in IS connecting - if it's not already running, starting it
      // triggers Microsoft sign-in automatically and posts the code to #logs.
      if (ctx.mc.bot) return void ctx.message.reply('Already connected. Use `!logout` first if you need to switch accounts.');
      await commands.start.run(ctx);
    },
  },

  logout: {
    allowedChannels: ['commands'],
    ownerOnly: true,
    async run({ message, mc }) {
      await mc.logout();
      await message.reply('🔓 Logged out and cleared the saved Microsoft session. Next `!start` will ask you to sign in again.');
    },
  },

  config: {
    allowedChannels: ['commands'],
    ownerOnly: true,
    async run({ message, args, config }) {
      const [sub, ...rest] = args;
      try {
        switch (sub) {
          case undefined: {
            // Bare "!config" -> the interactive GUI panel (select a
            // setting -> popup with the current value -> Save/Cancel).
            await message.reply(configPanel.buildPanel(config, message.author.id));
            return;
          }
          case 'help': {
            const embed = new EmbedBuilder()
              .setColor(0x5865f2)
              .setTitle('!config usage')
              .setDescription(
                [
                  'Run `!config` with no arguments for the interactive GUI panel.',
                  '',
                  'Or use text commands directly:',
                  '`!config get <key>` - e.g. `!config get minecraft.host`',
                  '`!config set <key> <value>` - e.g. `!config set minecraft.port 25565`',
                  '`!config addowner <discordUserId>`',
                  '`!config removeowner <discordUserId>`',
                  '`!config addsubowner <discordUserId>`',
                  '`!config removesubowner <discordUserId>`',
                  '',
                  'Common keys: minecraft.host, minecraft.port, minecraft.version, ' +
                    'minecraft.smpCommand, minecraft.commandDelayMs, minecraft.rejoinDelayMs',
                ].join('\n')
              );
            await message.reply({ embeds: [embed] });
            return;
          }
          case 'get': {
            const [key] = rest;
            if (!key) return void message.reply('Usage: `!config get <key>`');
            const value = config.get(key);
            await message.reply(`\`${key}\` = \`${JSON.stringify(value)}\``);
            return;
          }
          case 'set': {
            const [key, ...valueParts] = rest;
            if (!key || valueParts.length === 0) return void message.reply('Usage: `!config set <key> <value>`');
            const value = config.set(key, valueParts.join(' '));
            await message.reply(`✅ \`${key}\` is now \`${JSON.stringify(value)}\``);
            return;
          }
          case 'addowner': {
            const [id] = rest;
            if (!id) return void message.reply('Usage: `!config addowner <discordUserId>`');
            config.addToList('discord.ownerIds', id);
            await message.reply(`✅ Added <@${id}> as an owner.`);
            return;
          }
          case 'removeowner': {
            const [id] = rest;
            if (!id) return void message.reply('Usage: `!config removeowner <discordUserId>`');
            config.removeFromList('discord.ownerIds', id);
            await message.reply(`✅ Removed <@${id}> from owners.`);
            return;
          }
          case 'addsubowner': {
            const [id] = rest;
            if (!id) return void message.reply('Usage: `!config addsubowner <discordUserId>`');
            config.addToList('discord.subOwnerIds', id);
            await message.reply(`✅ Added <@${id}> as a sub-owner.`);
            return;
          }
          case 'removesubowner': {
            const [id] = rest;
            if (!id) return void message.reply('Usage: `!config removesubowner <discordUserId>`');
            config.removeFromList('discord.subOwnerIds', id);
            await message.reply(`✅ Removed <@${id}> from sub-owners.`);
            return;
          }
          default:
            await message.reply(`Unknown \`!config\` subcommand \`${sub}\`. Try \`!config help\`.`);
        }
      } catch (err) {
        await message.reply(`❌ ${err.message}`);
      }
    },
  },
};

module.exports = commands;
