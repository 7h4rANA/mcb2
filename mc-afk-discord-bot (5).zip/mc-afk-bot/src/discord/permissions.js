'use strict';

/**
 * Owners can do everything. Sub-owners can do everything EXCEPT the
 * config editor and Microsoft login/logout - those touch account
 * credentials and the owner/sub-owner list itself, so they stay
 * owner-only by design. See README for how to change this if you want.
 */
function isOwner(config, userId) {
  return config.isOwner(userId);
}

function isAuthorized(config, userId) {
  return config.isAuthorized(userId);
}

function channelKeyFor(config, channelId) {
  const channels = config.get('discord.channels') || {};
  for (const [key, id] of Object.entries(channels)) {
    if (String(id) === String(channelId)) return key;
  }
  return null;
}

module.exports = { isOwner, isAuthorized, channelKeyFor };
