'use strict';

const { Client, GatewayIntentBits, ActivityType } = require('discord.js');

const logger = require('../utils/logger');
const embeds = require('./embeds');
const permissions = require('./permissions');
const commands = require('./commands');
const configPanel = require('./configPanel');

function createDiscordController(config, mc, token) {
  const client = new Client({
    intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent],
  });

  let chatsChannel = null;

  function updatePresence() {
    if (!client.user) return;
    const data = mc.getStatusData();
    const emoji = data.online ? '🟢' : '🔴';
    client.user.setPresence({
      activities: [{ name: `${emoji} ${data.host}:${data.port} | MC ${data.version}`, type: ActivityType.Playing }],
      status: data.online ? 'online' : 'idle',
    });
  }

  client.once('ready', async () => {
    console.log(`[discord] Logged in as ${client.user.tag}`);
    const channelIds = config.get('discord.channels') || {};

    try {
      const logsChannel = await client.channels.fetch(channelIds.logs);
      logger.bindChannel(logsChannel);
    } catch (err) {
      console.error('[discord] Could not fetch the configured logs channel - check discord.channels.logs in config.json.', err.message);
    }

    try {
      chatsChannel = await client.channels.fetch(channelIds.chat);
    } catch (err) {
      console.error('[discord] Could not fetch the configured chat channel - check discord.channels.chat in config.json.', err.message);
    }

    updatePresence();

    if (config.get('minecraft.autoStartOnBoot')) {
      mc.start().catch((err) => logger.error('Auto-start on boot failed', err.message));
    }
  });

  client.on('messageCreate', async (message) => {
    if (message.author.bot || !message.guild) return;
    const prefix = config.get('discord.prefix') || '!';
    if (!message.content.startsWith(prefix)) return;

    const channelKey = permissions.channelKeyFor(config, message.channel.id);
    if (!channelKey || channelKey === 'logs') return; // #logs is output-only

    const [cmdName, ...args] = message.content.slice(prefix.length).trim().split(/\s+/);
    const command = commands[(cmdName || '').toLowerCase()];
    if (!command) return;

    if (!command.allowedChannels.includes(channelKey)) return;

    if (!permissions.isAuthorized(config, message.author.id)) {
      await message.reply("🚫 You're not allowed to use this bot.").catch(() => {});
      return;
    }
    if (command.ownerOnly && !permissions.isOwner(config, message.author.id)) {
      await message.reply('🚫 Only the owner can use this command.').catch(() => {});
      return;
    }

    try {
      await command.run({ message, args, mc, config, client });
    } catch (err) {
      console.error(`[discord] Command "${cmdName}" threw:`, err);
      await message.reply(`❌ Unexpected error: ${err.message}`).catch(() => {});
    }
  });

  client.on('interactionCreate', async (interaction) => {
    try {
      if (interaction.isStringSelectMenu() && interaction.customId.startsWith('config_select:')) {
        await configPanel.handleSelect(interaction, config);
      } else if (interaction.isModalSubmit() && interaction.customId.startsWith('config_modal:')) {
        await configPanel.handleModalSubmit(interaction, config);
      } else if (interaction.isButton() && interaction.customId.startsWith('config_save:')) {
        await configPanel.handleSave(interaction, config);
      } else if (interaction.isButton() && interaction.customId.startsWith('config_cancel:')) {
        await configPanel.handleCancel(interaction);
      } else if (interaction.isButton() && interaction.customId.startsWith('config_close:')) {
        await configPanel.handleClose(interaction);
      }
    } catch (err) {
      console.error('[discord] Interaction handler error:', err);
      if (interaction.isRepliable() && !interaction.replied && !interaction.deferred) {
        await interaction.reply({ content: `❌ ${err.message}`, ephemeral: true }).catch(() => {});
      }
    }
  });

  mc.on('statusChange', updatePresence);

  mc.on('mention', (data) => {
    if (chatsChannel) chatsChannel.send({ embeds: [embeds.mentionEmbed(data)] }).catch(() => {});
  });

  mc.on('whisper', (data) => {
    if (chatsChannel) chatsChannel.send({ embeds: [embeds.whisperEmbed(data)] }).catch(() => {});
  });

  mc.on('crateKey', (data) => {
    if (chatsChannel) chatsChannel.send({ embeds: [embeds.crateKeyEmbed(data)] }).catch(() => {});
  });

  client.login(token);
  return client;
}

module.exports = { createDiscordController };
