'use strict';

const { EmbedBuilder } = require('discord.js');

function formatDuration(ms) {
  if (!ms || ms < 0) return '0s';
  let s = Math.floor(ms / 1000);
  const d = Math.floor(s / 86400);
  s %= 86400;
  const h = Math.floor(s / 3600);
  s %= 3600;
  const m = Math.floor(s / 60);
  s %= 60;
  const parts = [];
  if (d) parts.push(`${d}d`);
  if (h) parts.push(`${h}h`);
  if (m) parts.push(`${m}m`);
  parts.push(`${s}s`);
  return parts.join(' ');
}

const STATUS_LABELS = {
  offline: 'Offline',
  connecting: 'Connecting…',
  hub: 'In hub',
  joining_smp: 'Switching to SMP…',
  smp: 'On SMP',
};

function statusEmbed(data) {
  const emoji = data.online ? '🟢' : '🔴';
  const label = STATUS_LABELS[data.status] || data.status;

  const embed = new EmbedBuilder()
    .setColor(data.online ? 0x57f287 : 0xed4245)
    .setTitle(`${emoji} ${label}`)
    .setTimestamp();

  if (data.username) {
    embed.setThumbnail(`https://mc-heads.net/avatar/${encodeURIComponent(data.username)}/100`);
  }

  embed.addFields(
    { name: 'Username', value: data.username || '—', inline: true },
    { name: 'Uptime', value: data.online ? formatDuration(data.uptimeMs) : '—', inline: true },
    { name: 'Server', value: data.server ? data.server.toUpperCase() : '—', inline: true },
    { name: 'Health', value: data.health != null ? `${data.health.toFixed(1)} / 20` : '—', inline: true },
    { name: 'World', value: data.dimension || '—', inline: true },
    { name: 'RAM Usage', value: `${data.ramMb} MB`, inline: true },
    {
      name: 'Ping (real, estimated)',
      value: data.estimatedPingMs != null ? `${data.estimatedPingMs} ms` : 'measuring…',
      inline: true,
    },
    {
      name: 'Ping (server-reported)',
      value: data.serverReportedPing != null ? `${data.serverReportedPing} ms` : '—',
      inline: true,
    }
  );

  embed.setFooter({ text: `${data.host}:${data.port} · MC ${data.version}` });
  return embed;
}

function escapeMd(text) {
  return String(text).replace(/([*_`~|])/g, '\\$1');
}

function mentionEmbed({ username, message }) {
  return new EmbedBuilder()
    .setColor(0x3498db)
    .setAuthor({ name: '💬 Public chat mention' })
    .setDescription(`**${escapeMd(username)}**: ${escapeMd(message)}`)
    .setTimestamp();
}

function whisperEmbed({ username, message }) {
  return new EmbedBuilder()
    .setColor(0x9b59b6)
    .setAuthor({ name: '✉️ Private message (/tell)' })
    .setDescription(`**${escapeMd(username)}**: ${escapeMd(message)}`)
    .setTimestamp();
}

function crateKeyEmbed({ text }) {
  return new EmbedBuilder()
    .setColor(0xf1c40f)
    .setTitle('🔑 Crate key alert!')
    .setDescription(escapeMd(text))
    .setTimestamp();
}

function cmdOutputEmbed(command, lines) {
  const body = lines.length
    ? lines.join('\n')
    : 'No output received within the capture window (the server may not have responded, or the reply was missed).';
  return new EmbedBuilder()
    .setColor(0x5865f2)
    .setTitle(`Output: ${command}`)
    .setDescription('```\n' + body.slice(0, 3900) + '\n```')
    .setTimestamp();
}

module.exports = {
  formatDuration,
  statusEmbed,
  mentionEmbed,
  whisperEmbed,
  crateKeyEmbed,
  cmdOutputEmbed,
  escapeMd,
};
