// Optional: run the bot under PM2 for auto-restart on crash and a
// hard RSS-based safety net on top of the V8 heap cap in package.json.
//
//   npm install -g pm2
//   pm2 start ecosystem.config.js
//   pm2 save && pm2 startup   # survive VPS reboots
//
module.exports = {
  apps: [
    {
      name: 'mc-discord-bot',
      script: 'index.js',
      node_args: ['--max-old-space-size=384', '--max-semi-space-size=32'],
      // Belt-and-braces: if RSS still creeps past this, PM2 kills and
      // restarts the process rather than letting the VPS swap/OOM.
      max_memory_restart: '450M',
      autorestart: true,
      restart_delay: 5000,
      max_restarts: 20,
      env: {
        NODE_ENV: 'production',
      },
    },
  ],
};
