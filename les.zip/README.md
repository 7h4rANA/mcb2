# mc-discord-control-bot

A single-process Mineflayer + Discord.js bot: connect a Minecraft account,
control it from Discord, and keep the whole thing under 500MB RAM on a
760MB / 1 vCore VPS.

## Requirements

- Node.js **22+** (required by current `mineflayer`; check with `node -v`)
- A Discord application/bot token with the **Message Content Intent** enabled
  in the [Discord Developer Portal](https://discord.com/developers/applications)
  (Bot tab → Privileged Gateway Intents)
- A Microsoft account that owns Minecraft

## Setup

```bash
npm install
cp .env.example .env
# edit .env with your server, Discord token/channel, etc.
```

## First run (Microsoft device-code login)

The first time the bot connects (`!start`), Mineflayer needs to complete a
one-time Microsoft device-code login. When that happens, the bot posts the
code and URL into `DISCORD_CHANNEL_ID` (and always logs it to the console
too, in case Discord delivery fails):

```
Microsoft sign-in required.
Open https://www.microsoft.com/link and enter code: ABCD1234
(expires in ~15 min)
```

Open that link on any device, enter the code, and sign in. After that,
tokens are cached under `mc-auth-cache/` (configurable via `AUTH_CACHE_DIR`)
and future restarts need no further interaction — **back this folder up**
if you ever migrate VPS providers, or you'll have to re-auth.

## Running

```bash
npm start
```

`npm start` runs `node --max-old-space-size=384 --max-semi-space-size=32 index.js`
— use it instead of `node index.js` directly, or the V8 heap cap won't apply.

For a real deployment, run it under a process manager so it survives
reboots and crashes:

```bash
npm install -g pm2
pm2 start ecosystem.config.js
pm2 save && pm2 startup
```

`ecosystem.config.js` also sets `max_memory_restart: '450M'` as a second
line of defense — if RSS ever creeps past that, PM2 restarts the process
cleanly instead of letting the VPS start swapping.

## Discord commands

All commands are prefixed with `!` (configurable via `COMMAND_PREFIX`) and
gated by `DISCORD_CHANNEL_ID` / `DISCORD_ADMIN_IDS` in `.env` — set either
or both depending on how strict you want access control to be.

| Command | Description |
|---|---|
| `!start` | Connects the Minecraft bot to the server |
| `!stop` | Gracefully disconnects and frees the connection so you can play manually |
| `!status` | Embed with avatar, username/UUID, uptime, detected location, RAM usage |
| `!cmd <command>` | Runs an in-game command, e.g. `!cmd /pay Steve 100` |
| `!chat <message>` | Sends a public chat message as the bot |

## Tuning the routing/queue detection

The hub → `/smp` auto-routing and queue forwarding are driven by regexes in
`.env` (`HUB_REGEX`, `SMP_REGEX`, `QUEUE_REGEX`) because every network's
chat text is different. The defaults (`hub`, `smp`, `position in queue|queue:`)
are generic starting points — run the bot once, watch the console log (it
prints every chat line's detection state), and tighten the patterns to
match your specific network's actual messages.

## Memory notes

- Mineflayer has no renderer, so there's no "graphics" setting to disable.
  The two levers that actually matter are `MC_VIEW_DISTANCE` (chunk radius
  requested from the server — 3 = a 7×7 chunk area) and *not* loading extra
  plugins like `mineflayer-pathfinder` or `mineflayer-viewer`, which this
  bot deliberately avoids.
- Discord.js's default caches are trimmed hard in `index.js` via
  `makeCache`/`sweepers`, since this bot only ever watches one channel.
- The V8 heap is capped via `--max-old-space-size=384` and
  `--max-semi-space-size=32`. Combined with Node's own baseline (~40–60MB
  RSS) and Discord.js/Mineflayer's native overhead, total RSS should
  comfortably stay under 500MB. If you see it creeping close, lower
  `MC_VIEW_DISTANCE` first — it has the biggest single effect.

## Troubleshooting

- **Bot doesn't respond to any `!` command**: confirm Message Content
  Intent is enabled for the bot in the Developer Portal, and that
  `DISCORD_CHANNEL_ID`/`DISCORD_ADMIN_IDS` actually match your setup.
- **Stuck re-authenticating every restart**: check that `AUTH_CACHE_DIR`
  is writable and isn't being wiped between deploys.
- **Never routes to `/smp`**: your network's hub chat text probably
  doesn't contain the literal word "hub" — tune `HUB_REGEX`.
