'use strict';

/**
 * mc-discord-control-bot
 * ------------------------------------------------------------------
 * A single-process Mineflayer + Discord.js bot, built to run
 * comfortably under 500MB RSS on a 760MB / 1 vCore VPS.
 *
 * Memory notes (read this before tuning further):
 *  - Mineflayer has no renderer - there's nothing to "turn off" there.
 *    The real RAM levers are: (1) viewDistance, which controls how many
 *    chunks the server streams to the bot and is by far the biggest
 *    knob, and (2) not loading extra plugins (pathfinder, viewer, etc.)
 *    that this bot doesn't need.
 *  - Discord.js caches guild/member/message data by default. We cap
 *    those caches hard below, since this bot only ever needs to see
 *    messages in one channel.
 *  - The V8 heap itself is capped via --max-old-space-size and
 *    --max-semi-space-size in package.json's "start" script. Run the
 *    bot with `npm start`, not `node index.js`, to get those flags.
 * ------------------------------------------------------------------
 */

require('dotenv').config();
const path = require('path');
const mineflayer = require('mineflayer');
const {
  Client,
  GatewayIntentBits,
  Events,
  EmbedBuilder,
  Options,
} = require('discord.js');

// ---------------------------------------------------------------------
// Configuration
// ---------------------------------------------------------------------
const CONFIG = {
  mc: {
    host: process.env.MC_HOST || 'localhost',
    port: parseInt(process.env.MC_PORT || '25565', 10),
    username: process.env.MC_USERNAME || '',
    version: process.env.MC_VERSION || false,
    viewDistance: parseInt(process.env.MC_VIEW_DISTANCE || '3', 10),
  },
  smpCommand: process.env.SMP_COMMAND || '/smp',
  routeDelayMs: parseInt(process.env.ROUTE_DELAY_MS || '3000', 10),
  reconnectDelayMs: parseInt(process.env.RECONNECT_DELAY_MS || '15000', 10),
  hubRegex: safeRegex(process.env.HUB_REGEX || 'hub'),
  smpArrivedRegex: safeRegex(process.env.SMP_REGEX || 'smp'),
  queueRegex: safeRegex(process.env.QUEUE_REGEX || 'position in queue|queue:'),
  discord: {
    token: process.env.DISCORD_TOKEN || '',
    channelId: process.env.DISCORD_CHANNEL_ID || null,
    adminIds: (process.env.DISCORD_ADMIN_IDS || '')
      .split(',')
      .map((s) => s.trim())
      .filter(Boolean),
    prefix: process.env.COMMAND_PREFIX || '!',
  },
  authCacheDir: path.join(__dirname, process.env.AUTH_CACHE_DIR || 'mc-auth-cache'),
};

function safeRegex(pattern) {
  try {
    return new RegExp(pattern, 'i');
  } catch (err) {
    log(`Invalid regex "${pattern}", falling back to literal match:`, err.message);
    return new RegExp(pattern.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i');
  }
}

if (!CONFIG.discord.token) {
  console.error('FATAL: DISCORD_TOKEN is not set. Copy .env.example to .env and fill it in.');
  process.exit(1);
}

// ---------------------------------------------------------------------
// Runtime state (single Minecraft session at a time, by design)
// ---------------------------------------------------------------------
const state = {
  bot: null, // mineflayer Bot instance, or null when offline
  connecting: false,
  manualStop: false, // true after !stop - blocks auto-reconnect
  startTime: null,
  location: 'Offline', // Offline | Connecting | Hub | Hub (Queue) | Routing to SMP | SMP
  lastQueueMessage: null,
  routeTimer: null,
  reconnectTimer: null,
};

// ---------------------------------------------------------------------
// Small helpers
// ---------------------------------------------------------------------
function log(...args) {
  console.log(`[${new Date().toISOString()}]`, ...args);
}

function getMemoryUsageMB() {
  return (process.memoryUsage().rss / 1024 / 1024).toFixed(1);
}

function formatUptime(startTime) {
  if (!startTime) return 'N/A';
  let s = Math.floor((Date.now() - startTime.getTime()) / 1000);
  const days = Math.floor(s / 86400); s %= 86400;
  const hours = Math.floor(s / 3600); s %= 3600;
  const mins = Math.floor(s / 60); s %= 60;
  const parts = [];
  if (days) parts.push(`${days}d`);
  if (hours) parts.push(`${hours}h`);
  if (mins) parts.push(`${mins}m`);
  parts.push(`${s}s`);
  return parts.join(' ');
}

function stringifyKickReason(reason) {
  try {
    return (typeof reason === 'object' ? JSON.stringify(reason) : String(reason)).slice(0, 300);
  } catch {
    return 'unknown reason';
  }
}

// ---------------------------------------------------------------------
// Discord client - caches trimmed down hard since we only ever watch
// one channel and don't need guild-wide member/presence data.
// ---------------------------------------------------------------------
const discordClient = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent, // privileged - enable in the Dev Portal
  ],
  makeCache: Options.cacheWithLimits({
    MessageManager: 25,
    GuildMemberManager: 25,
    UserManager: 50,
    PresenceManager: 0,
    ReactionManager: 0,
    GuildStickerManager: 0,
    GuildEmojiManager: 0,
  }),
  sweepers: {
    messages: { interval: 300, lifetime: 600 },
  },
});

async function notify(content) {
  log('[notify]', content.replace(/\n/g, ' '));
  if (!CONFIG.discord.channelId) return;
  try {
    const channel = await discordClient.channels.fetch(CONFIG.discord.channelId);
    if (channel && channel.isTextBased()) {
      await channel.send(content.slice(0, 1990));
    }
  } catch (err) {
    log('Failed to post Discord notification:', err.message);
  }
}

function isAuthorized(message) {
  if (message.author.bot) return false;
  const channelOk = !CONFIG.discord.channelId || message.channel.id === CONFIG.discord.channelId;
  const userOk = CONFIG.discord.adminIds.length === 0 || CONFIG.discord.adminIds.includes(message.author.id);
  return channelOk && userOk;
}

// ---------------------------------------------------------------------
// Mineflayer bot lifecycle
// ---------------------------------------------------------------------
function createMineflayerBot() {
  if (state.bot || state.connecting) {
    log('Start requested but a bot is already running/connecting - ignoring.');
    return;
  }
  if (!CONFIG.mc.username) {
    notify('Cannot start: MC_USERNAME is not set in .env');
    return;
  }

  state.connecting = true;
  state.manualStop = false;
  state.location = 'Connecting';
  state.lastQueueMessage = null;

  log(`Connecting to ${CONFIG.mc.host}:${CONFIG.mc.port} as ${CONFIG.mc.username}...`);

  let bot;
  try {
    bot = mineflayer.createBot({
      host: CONFIG.mc.host,
      port: CONFIG.mc.port,
      username: CONFIG.mc.username,
      auth: 'microsoft',
      version: CONFIG.mc.version,

      // --- RAM-conscious settings ---
      viewDistance: CONFIG.mc.viewDistance, // 3 -> server streams a 7x7 chunk area
      physicsEnabled: true, // keep server-authoritative physics so knockback lands correctly
      checkTimeoutInterval: 60 * 1000,
      respawn: true, // don't sit as a corpse if the bot dies

      // --- Microsoft device-code auth ---
      // Tokens are cached under authCacheDir after the first login, so
      // restarts after that are silent and need no further interaction.
      profilesFolder: CONFIG.authCacheDir,
      onMsaCode: (data) => {
        const minutes = Math.round((data.expires_in || 900) / 60);
        const msg =
          `Microsoft sign-in required.\n` +
          `Open ${data.verification_uri} and enter code: ${data.user_code}\n` +
          `(expires in ~${minutes} min)`;
        log(msg.replace(/\n/g, ' | '));
        notify(msg);
      },
    });
  } catch (err) {
    // createBot itself throwing synchronously (bad options, etc.)
    state.connecting = false;
    log('Failed to create bot:', err.message);
    notify(`Failed to start bot: ${err.message}`);
    return;
  }

  state.bot = bot;
  attachBotListeners(bot);
}

function attachBotListeners(bot) {
  bot.once('spawn', () => {
    state.connecting = false;
    state.startTime = new Date();
    state.location = 'Hub';
    log(`Spawned as ${bot.username}.`);
    notify(`Connected to the server as **${bot.username}**.`);
    scheduleRouteToSmp('initial connect');
  });

  // Raw chat/system messages - used for hub/SMP/queue detection.
  bot.on('message', (jsonMsg) => {
    let text;
    try {
      text = jsonMsg.toString();
    } catch {
      return;
    }
    if (!text) return;

    if (CONFIG.queueRegex.test(text)) {
      if (text !== state.lastQueueMessage) {
        state.lastQueueMessage = text;
        state.location = 'Hub (Queue)';
        notify(`Queue update: ${text}`);
      }
      return;
    }

    if (CONFIG.hubRegex.test(text) && state.location !== 'Hub' && state.location !== 'Connecting') {
      log(`Hub chat pattern matched while location was "${state.location}" - treating as a bounce-back.`);
      state.location = 'Hub';
      scheduleRouteToSmp('kicked back to hub');
    } else if (CONFIG.smpArrivedRegex.test(text) && state.location !== 'SMP') {
      state.location = 'SMP';
      notify('Arrived on the SMP.');
    }
  });

  bot.on('kicked', (reason) => {
    const text = stringifyKickReason(reason);
    log('Kicked:', text);
    notify(`Kicked from the server: ${text}`);
  });

  // Never let a bare socket/protocol error take the process down.
  bot.on('error', (err) => {
    const msg = err && err.message ? err.message : String(err);
    log('Bot error:', msg);
    notify(`Bot error: ${msg}`);
  });

  bot.on('end', (reason) => {
    log('Connection ended:', reason);
    const wasManual = state.manualStop;
    cleanupBot();

    if (wasManual) {
      notify('Bot stopped.');
      return;
    }
    notify(`Disconnected (${reason || 'unknown reason'}). Reconnecting in ${CONFIG.reconnectDelayMs / 1000}s...`);
    scheduleReconnect();
  });
}

function scheduleRouteToSmp(reason) {
  if (state.manualStop || !state.bot) return;
  if (state.routeTimer) return; // already scheduled - avoid duplicate /smp sends
  log(`Will send "${CONFIG.smpCommand}" in ${CONFIG.routeDelayMs}ms (${reason}).`);
  state.routeTimer = setTimeout(() => {
    state.routeTimer = null;
    if (state.bot && !state.manualStop) {
      state.bot.chat(CONFIG.smpCommand);
      state.location = 'Routing to SMP';
      log(`Sent "${CONFIG.smpCommand}".`);
    }
  }, CONFIG.routeDelayMs);
}

function scheduleReconnect() {
  if (state.reconnectTimer || state.manualStop) return;
  state.reconnectTimer = setTimeout(() => {
    state.reconnectTimer = null;
    createMineflayerBot();
  }, CONFIG.reconnectDelayMs);
}

function cleanupBot() {
  state.bot = null;
  state.connecting = false;
  state.location = 'Offline';
  if (state.routeTimer) {
    clearTimeout(state.routeTimer);
    state.routeTimer = null;
  }
}

function stopBot() {
  state.manualStop = true;
  if (state.reconnectTimer) {
    clearTimeout(state.reconnectTimer);
    state.reconnectTimer = null;
  }
  if (state.routeTimer) {
    clearTimeout(state.routeTimer);
    state.routeTimer = null;
  }
  if (state.bot) {
    try {
      state.bot.quit();
    } catch (err) {
      log('Error while quitting bot (ignoring):', err.message);
      cleanupBot();
    }
  } else {
    state.connecting = false;
  }
}

// ---------------------------------------------------------------------
// Discord status embed
// ---------------------------------------------------------------------
function buildStatusEmbed() {
  const online = !!state.bot;
  const uuid = online && state.bot.player ? state.bot.player.uuid : null;

  const embed = new EmbedBuilder()
    .setTitle('Minecraft Bot Status')
    .setColor(online ? 0x57f287 : 0xed4245)
    .addFields(
      { name: 'Status', value: online ? 'Online' : 'Offline', inline: true },
      { name: 'Location', value: state.location, inline: true },
      { name: 'Uptime', value: formatUptime(state.startTime), inline: true },
      { name: 'RAM Usage', value: `${getMemoryUsageMB()} MB`, inline: true },
      { name: 'Server', value: `${CONFIG.mc.host}:${CONFIG.mc.port}`, inline: true },
    )
    .setTimestamp();

  if (online) {
    embed.addFields({ name: 'Username', value: state.bot.username || 'Unknown', inline: true });
  }
  if (uuid) {
    embed.addFields({ name: 'UUID', value: uuid, inline: true });
    embed.setThumbnail(`https://crafatar.com/avatars/${uuid}?overlay`);
  }
  return embed;
}

// ---------------------------------------------------------------------
// Discord command handling (prefix commands, restricted per isAuthorized)
// ---------------------------------------------------------------------
discordClient.once(Events.ClientReady, (c) => {
  log(`Discord logged in as ${c.user.tag}.`);
});

discordClient.on(Events.MessageCreate, async (message) => {
  try {
    if (!message.content.startsWith(CONFIG.discord.prefix)) return;
    if (!isAuthorized(message)) return;

    const [rawCmd, ...rest] = message.content.slice(CONFIG.discord.prefix.length).trim().split(/\s+/);
    const cmd = (rawCmd || '').toLowerCase();
    const argString = rest.join(' ');

    switch (cmd) {
      case 'start': {
        if (state.bot || state.connecting) {
          await message.reply('Already running.');
          break;
        }
        await message.reply('Starting bot...');
        createMineflayerBot();
        break;
      }

      case 'stop': {
        if (!state.bot && !state.connecting) {
          await message.reply('Bot is already offline.');
          break;
        }
        await message.reply('Stopping bot...');
        stopBot();
        break;
      }

      case 'status': {
        await message.reply({ embeds: [buildStatusEmbed()] });
        break;
      }

      case 'cmd': {
        if (!state.bot) {
          await message.reply('Bot is offline.');
          break;
        }
        if (!argString) {
          await message.reply(`Usage: \`${CONFIG.discord.prefix}cmd <command>\``);
          break;
        }
        state.bot.chat(argString);
        await message.reply(`Sent: \`${argString}\``);
        break;
      }

      case 'chat': {
        if (!state.bot) {
          await message.reply('Bot is offline.');
          break;
        }
        if (!argString) {
          await message.reply(`Usage: \`${CONFIG.discord.prefix}chat <message>\``);
          break;
        }
        state.bot.chat(argString);
        await message.reply('Sent.');
        break;
      }

      default:
        // Unknown command - stay quiet rather than spamming the channel.
        break;
    }
  } catch (err) {
    log('Error handling Discord command:', err.message);
    try {
      await message.reply(`Command failed: ${err.message}`);
    } catch {
      // Ignore secondary failure - already logged above.
    }
  }
});

// ---------------------------------------------------------------------
// Process-level safety net - log everything, never die silently.
// ---------------------------------------------------------------------
process.on('unhandledRejection', (reason) => {
  log('Unhandled promise rejection:', reason);
});
process.on('uncaughtException', (err) => {
  log('Uncaught exception:', err && err.stack ? err.stack : err);
});

async function shutdown(signal) {
  log(`Received ${signal}, shutting down...`);
  state.manualStop = true;
  if (state.bot) {
    try {
      state.bot.quit();
    } catch {
      // ignore - process is exiting anyway
    }
  }
  try {
    await discordClient.destroy();
  } catch {
    // ignore
  }
  process.exit(0);
}
process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));

// ---------------------------------------------------------------------
// Boot
// ---------------------------------------------------------------------
discordClient.login(CONFIG.discord.token).catch((err) => {
  console.error('FATAL: Failed to log into Discord:', err.message);
  process.exit(1);
});
