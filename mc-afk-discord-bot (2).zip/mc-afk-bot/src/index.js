'use strict';

require('dotenv').config();

const config = require('./config/configManager');
const { McController } = require('./minecraft/mcController');
const { createDiscordController } = require('./discord/discordController');

if (!process.env.DISCORD_TOKEN) {
  console.error('[fatal] DISCORD_TOKEN is not set. Copy .env.example to .env and fill it in.');
  process.exit(1);
}

const mc = new McController(config);
const client = createDiscordController(config, mc, process.env.DISCORD_TOKEN);

async function shutdown(signal) {
  console.log(`\n[index] Received ${signal}, shutting down...`);
  try {
    await mc.stop();
  } catch {
    /* ignore - we're exiting anyway */
  }
  client.destroy();
  process.exit(0);
}

process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));

process.on('uncaughtException', (err) => {
  console.error('[fatal] Uncaught exception:', err);
});
process.on('unhandledRejection', (err) => {
  console.error('[fatal] Unhandled rejection:', err);
});
