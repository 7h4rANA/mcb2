'use strict';

const config = require('./config');
const { loginBot } = require('./login');

let bot = null;
let reconnectTimer = null;
let hubTransitionTimer = null;
let lastDimension = null;
let shuttingDown = false;

function log(msg) {
  console.log(`[${new Date().toISOString()}] ${msg}`);
}

function createBot() {
  log(`Connecting to ${config.host}:${config.port} as ${config.username}...`);

  bot = loginBot(config);
  registerHandlers(bot);
}

/**
 * Queues the SMP transition command after config.hubWaitDelay.
 * Re-arms the timer if called again before it fires (e.g. duplicate signals).
 */
function scheduleSmpTransition(reason) {
  if (hubTransitionTimer) clearTimeout(hubTransitionTimer);

  log(`Hub detected (${reason}). Sending "${config.smpCommand}" in ${config.hubWaitDelay}ms.`);
  hubTransitionTimer = setTimeout(() => {
    hubTransitionTimer = null;
    if (bot && bot._client && bot._client.socket && !bot._client.socket.destroyed) {
      log(`Executing: ${config.smpCommand}`);
      bot.chat(config.smpCommand);
    } else {
      log('Skipped SMP command — connection is not currently active.');
    }
  }, config.hubWaitDelay);
}

function registerHandlers(botInstance) {
  botInstance.once('spawn', () => {
    log('Bot spawned.');

    // Request a larger view distance so surrounding chunk data stays loaded.
    try {
      botInstance.settings.viewDistance = config.viewDistance;
      log(`Requested view distance: ${config.viewDistance} chunks.`);
    } catch (err) {
      log(`Could not set view distance: ${err.message}`);
    }

    lastDimension = botInstance.game ? botInstance.game.dimension : null;

    // First spawn on a network is almost always the hub — queue the SMP transition.
    scheduleSmpTransition('initial spawn');
  });

  // Fires on world/dimension switches — a useful secondary signal that the
  // bot may have been bounced back to the hub.
  botInstance.on('respawn', () => {
    const dim = botInstance.game ? botInstance.game.dimension : null;
    log(`World/respawn event. Dimension: ${dim}`);

    if (lastDimension !== null && dim !== lastDimension) {
      scheduleSmpTransition(`dimension change (${lastDimension} -> ${dim})`);
    }
    lastDimension = dim;
  });

  // Chat/system message logging.
  botInstance.on('message', (jsonMsg) => {
    let text;
    try {
      text = jsonMsg.toString();
    } catch (err) {
      return;
    }
    const lower = text.toLowerCase();

    if (lower.includes('shard')) {
      log(`[SHARD MATCH] ${text}`);
    }

    for (const keyword of config.hubKeywords) {
      if (lower.includes(keyword)) {
        scheduleSmpTransition(`chat keyword "${keyword}"`);
        break;
      }
    }
  });

  botInstance.on('kicked', (reason) => {
    log(`Kicked from server: ${JSON.stringify(reason)}`);
  });

  botInstance.on('error', (err) => {
    log(`Bot error: ${err.message}`);
  });

  botInstance.on('end', (reason) => {
    log(`Connection ended (${reason}).`);
    if (hubTransitionTimer) {
      clearTimeout(hubTransitionTimer);
      hubTransitionTimer = null;
    }
    if (!shuttingDown) {
      scheduleReconnect();
    }
  });
}

function scheduleReconnect() {
  if (reconnectTimer) return;
  log(`Reconnecting in ${config.reconnectDelay}ms...`);
  reconnectTimer = setTimeout(() => {
    reconnectTimer = null;
    createBot();
  }, config.reconnectDelay);
}

function shutdown() {
  shuttingDown = true;
  log('Shutting down...');
  if (hubTransitionTimer) clearTimeout(hubTransitionTimer);
  if (reconnectTimer) clearTimeout(reconnectTimer);
  if (bot) {
    try { bot.quit(); } catch (err) { /* ignore */ }
  }
  process.exit(0);
}

process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);

createBot();
