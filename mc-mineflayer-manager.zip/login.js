'use strict';

const mineflayer = require('mineflayer');

/**
 * Handles Microsoft-account authentication for the Mineflayer bot.
 *
 * Kept separate from bot.js so the login/credential wiring (host, port,
 * username, auth mode, token cache location) is isolated from game logic
 * and event handling.
 *
 * First run: Mineflayer/prismarine-auth prints a microsoft.com/link URL and
 * a one-time code — open it in a browser and sign in with the Microsoft
 * account tied to config.username. After that, the token is cached in
 * config.authCacheDir and future logins are silent (no browser needed).
 *
 * @param {object} config - shared config object (see config.js)
 * @returns {import('mineflayer').Bot} an unspawned bot instance mid-login;
 *   attach event handlers to it before it connects.
 */
function loginBot(config) {
  return mineflayer.createBot({
    host: config.host,
    port: config.port,
    username: config.username,
    auth: 'microsoft',
    version: config.version,
    profilesFolder: config.authCacheDir,
  });
}

module.exports = { loginBot };
