# Minecraft Mineflayer Manager

Files:
- `config.js` — all settings (host, port, username, commands, delays)
- `login.js` — Microsoft-account authentication (used by `bot.js`)
- `bot.js` — the Mineflayer bot
- `package.json` — dependencies

## 1. Install Node.js on the VPS

```bash
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs
node -v   # confirm v18+
```

## 2. Get the project onto the server and install dependencies

```bash
mkdir -p ~/mc-manager && cd ~/mc-manager
# copy config.js, login.js, bot.js, package.json into this folder
npm install
```

## 3. Fill in `config.js`

Set `host`, `port`, `username` (your Microsoft account email), and `smpCommand` if different.

## 4. Run the initial Microsoft authentication once, interactively

The first login needs a real browser, so do this manually before handing control to PM2:

```bash
node bot.js
```

Mineflayer will print a `https://microsoft.com/link` URL and a one-time code in the console.
Open that URL on any device, enter the code, and sign in with the Microsoft account tied to `username`.
Once you see `Bot spawned.` in the logs, stop it with `Ctrl+C` — the auth token is now cached in
`./auth_cache` (as set by `authCacheDir` in `config.js`) and future runs won't need a browser.

## 5. Install PM2 and run the bot 24/7

```bash
sudo npm install -g pm2

# start it
pm2 start bot.js --name mc-bot

# make it survive reboots
pm2 startup
pm2 save
```

## 6. Day-to-day management

```bash
pm2 logs mc-bot      # tail logs
pm2 restart mc-bot   # restart the bot
pm2 stop mc-bot      # stop the bot
```

## Notes

- `hubKeywords` and the dimension-change check in `bot.js` are heuristics — tune them to match
  your specific network's actual kick/transfer messages and dimension IDs.
- Double-check your target server's rules on bots/automation before running this against it —
  some networks prohibit unattended clients even when using an official account.
