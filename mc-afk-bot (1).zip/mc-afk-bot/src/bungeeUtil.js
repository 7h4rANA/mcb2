'use strict'

// BungeeCord-family proxies (BungeeCord, Waterfall, FlameCord) use Java's
// DataOutputStream#writeUTF framing for plugin-message payloads: a 2-byte
// big-endian length prefix followed by the UTF-8 bytes. This is unrelated
// to Minecraft's normal varint-prefixed strings, so it needs its own codec.

function writeJavaUTF(str) {
  const strBuf = Buffer.from(str, 'utf8')
  const lenBuf = Buffer.alloc(2)
  lenBuf.writeUInt16BE(strBuf.length, 0)
  return Buffer.concat([lenBuf, strBuf])
}

function readJavaUTF(buf, offset = 0) {
  const len = buf.readUInt16BE(offset)
  const value = buf.toString('utf8', offset + 2, offset + 2 + len)
  return { value, next: offset + 2 + len }
}

module.exports = { writeJavaUTF, readJavaUTF }
