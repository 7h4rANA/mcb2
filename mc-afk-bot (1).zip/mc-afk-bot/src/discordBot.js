'use strict'
const { Client, GatewayIntentBits, Partials, EmbedBuilder } = require('discord.js')

const KNOWN_COMMANDS = new Set(['start', 'stop', 'status', 'cmd'])

function formatUptime(ms) {
  if (!ms) return '0s'
  const s = Math.floor(ms / 1000)
  const h = Math.floor(s / 3600)
  const m = Math.floor((s % 3600) / 60)
  const sec = s % 60
  return [h && `${h}h`, m && `${m}m`, `${sec}s`].filter(Boolean).join(' ')
}

function statusEmbed(status) {
  const embed = new EmbedBuilder()
    .setTitle('Minecraft AFK Bot')
    .setColor(status.online ? 0x43b581 : 0xed4245)
    .addFields(
      { name: 'State', value: status.online ? '🟢 Online' : (status.desiredOnline ? '🟡 Reconnecting…' : '🔴 Offline'), inline: true }
    )
    .setTimestamp()

  if (status.online) {
    const serverLabel = status.queriedServerName
      ? status.queriedServerName
      : (status.phase ? `${status.phase} (guessed, proxy didn't answer)` : 'unknown')

    embed.addFields(
      { name: 'Account', value: status.username || 'unknown', inline: true },
      { name: 'Server', value: serverLabel, inline: true },
      { name: 'Uptime', value: formatUptime(status.uptimeMs), inline: true },
      { name: 'Health / Food', value: `${status.health ?? '?'} / ${status.food ?? '?'}`, inline: true },
      { name: 'Position', value: status.position ? `${status.position.x}, ${status.position.y}, ${status.position.z}` : 'unknown', inline: true },
      { name: 'Ping', value: status.ping != null ? `${status.ping}ms` : 'unknown', inline: true }
    )
  }
  if (status.lastKickReason) {
    embed.addFields({ name: 'Last kick reason', value: String(status.lastKickReason).slice(0, 1000) })
  }
  if (!status.online && status.lastError) {
    embed.addFields({ name: 'Last error', value: String(status.lastError).slice(0, 1000) })
  }
  return embed
}

function parseCommand(content, prefix) {
  if (!content.startsWith(prefix)) return null
  const withoutPrefix = content.slice(prefix.length)
  const spaceIdx = withoutPrefix.indexOf(' ')
  const name = (spaceIdx === -1 ? withoutPrefix : withoutPrefix.slice(0, spaceIdx)).toLowerCase()
  const args = spaceIdx === -1 ? '' : withoutPrefix.slice(spaceIdx + 1).trim()
  return { name, args }
}

function createDiscordBot(config, mcBotManager, log) {
  // GuildMessages + MessageContent are both needed to receive and read
  // plain "!"-prefixed messages. MessageContent is a *privileged* intent -
  // it must also be switched on for this bot under Bot > Privileged Gateway
  // Intents in the Discord Developer Portal, or login() will fail with a
  // "disallowed intents" error. Guilds alone (what the old slash-command
  // version used) is not enough for this.
  const client = new Client({
    intents: [
      GatewayIntentBits.Guilds,
      GatewayIntentBits.GuildMessages,
      GatewayIntentBits.MessageContent
    ],
    partials: [Partials.Channel]
  })

  function isOwner(userId) {
    return config.ownerIds.length === 0 || config.ownerIds.includes(userId)
  }

  async function notifyChannel(text) {
    if (!config.statusChannelId) return
    try {
      const channel = await client.channels.fetch(config.statusChannelId)
      if (channel && channel.isTextBased()) await channel.send(text)
    } catch (err) {
      log.warn(`Could not post to status channel: ${err.message}`)
    }
  }

  client.once('clientReady', () => {
    log.info(`Discord bot logged in as ${client.user.tag}, prefix "${config.prefix}"`)
  })

  client.on('messageCreate', async (message) => {
    if (message.author.bot) return
    const parsed = parseCommand(message.content, config.prefix)
    if (!parsed) return
    // Not one of ours - leave it alone so this doesn't collide with other
    // bots that also happen to use "!" as a prefix in the same server.
    if (!KNOWN_COMMANDS.has(parsed.name)) return

    if (!isOwner(message.author.id)) {
      await message.reply("You're not allowed to control this bot.")
      return
    }

    if (parsed.name === 'start') {
      const started = mcBotManager.start()
      await message.reply(started
        ? '🟢 Starting the Minecraft bot…'
        : 'Already running (or already trying to connect).')
      return
    }

    if (parsed.name === 'stop') {
      const stopped = mcBotManager.stop()
      await message.reply(stopped ? '🔴 Stopped.' : 'It was already offline.')
      return
    }

    if (parsed.name === 'status') {
      await message.channel.sendTyping()
      const status = mcBotManager.getStatus()
      if (status.online) {
        status.queriedServerName = await mcBotManager.queryServerName()
      }
      await message.reply({ embeds: [statusEmbed(status)] })
      return
    }

    if (parsed.name === 'cmd') {
      if (!parsed.args) {
        await message.reply(`Usage: \`${config.prefix}cmd <command or chat text>\` (e.g. \`${config.prefix}cmd /list\`)`)
        return
      }
      if (!mcBotManager.isRunning()) {
        await message.reply('Bot is offline - nothing to send that to.')
        return
      }
      await message.channel.sendTyping()
      let lines
      try {
        lines = await mcBotManager.runCommand(parsed.args)
      } catch (err) {
        await message.reply(`Failed to send command: ${err.message}`)
        return
      }
      if (lines.length === 0) {
        await message.reply(`Sent \`${parsed.args}\` - no chat output within the capture window.`)
        return
      }
      let output = lines.join('\n')
      const MAX = 1900
      let truncated = false
      if (output.length > MAX) {
        output = output.slice(0, MAX)
        truncated = true
      }
      await message.reply(
        `Sent \`${parsed.args}\`:\n\`\`\`\n${output}\n\`\`\`${truncated ? '\n_(output truncated)_' : ''}`
      )
    }
  })

  return {
    client,
    login: () => client.login(config.token),
    notifyChannel
  }
}

module.exports = { createDiscordBot, statusEmbed }
