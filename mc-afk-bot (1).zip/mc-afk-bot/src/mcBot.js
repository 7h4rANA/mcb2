'use strict'
const mineflayer = require('mineflayer')
const path = require('path')
const { writeJavaUTF, readJavaUTF } = require('./bungeeUtil')

const MIN_RECONNECT_MS = 15_000
const MAX_RECONNECT_MS = 5 * 60_000
const BUNGEE_CHANNELS = ['bungeecord:main', 'BungeeCord'] // modern + legacy channel name

/**
 * Wraps a single mineflayer bot instance with start/stop control,
 * automatic (backed-off) reconnection, and a status snapshot -
 * everything the Discord side needs, nothing it doesn't.
 */
class McBotManager {
  constructor(config, log, hooks = {}) {
    this.config = config
    this.log = log
    this.hooks = hooks // { onMsaCode, onSpawn, onEnd, onLog }

    this.bot = null
    this.desiredOnline = false
    this.reconnectTimer = null
    this.reconnectDelay = MIN_RECONNECT_MS
    this.startedAt = null
    this.lastError = null
    this.lastKickReason = null
    this.joinCommandSent = false
    this.spawnCount = 0
    this.phase = null // 'hub' | 'smp', tracked from join sequence - see _connect()
  }

  isRunning() {
    return !!this.bot
  }

  getStatus() {
    const base = {
      desiredOnline: this.desiredOnline,
      lastError: this.lastError,
      lastKickReason: this.lastKickReason
    }
    if (!this.bot || !this.bot.entity) {
      return { online: false, ...base }
    }
    const b = this.bot
    return {
      online: true,
      ...base,
      username: b.username,
      health: b.health,
      food: b.food,
      position: b.entity.position ? {
        x: Math.round(b.entity.position.x),
        y: Math.round(b.entity.position.y),
        z: Math.round(b.entity.position.z)
      } : null,
      dimension: b.game ? b.game.dimension : null,
      ping: (b.player && b.player.ping) || null,
      uptimeMs: this.startedAt ? Date.now() - this.startedAt : 0,
      // Best-guess label from the join sequence (spawn on hub, then /smp).
      // queryServerName() below gets the real name straight from the proxy
      // when that's available and should be preferred if present.
      phase: this.phase
    }
  }

  /**
   * Asks the BungeeCord-family proxy (BungeeCord/Waterfall/FlameCord all
   * speak this) which backend server this connection is currently on, via
   * the standard "GetServer" plugin-message channel. Resolves with the
   * real server name (e.g. "smp-1"), or null if the bot is offline or the
   * proxy doesn't answer in time (some anti-bot layers can drop unknown
   * plugin channels, so a timeout here isn't necessarily an error).
   */
  queryServerName(timeoutMs = 2000) {
    const bot = this.bot
    if (!bot || !bot._client) return Promise.resolve(null)
    const client = bot._client

    return new Promise((resolve) => {
      let done = false
      const finish = (value) => {
        if (done) return
        done = true
        client.removeListener('custom_payload', onPayload)
        resolve(value)
      }

      function onPayload(packet) {
        if (!BUNGEE_CHANNELS.includes(packet.channel)) return
        try {
          const sub = readJavaUTF(packet.data, 0)
          if (sub.value !== 'GetServer') return
          const name = readJavaUTF(packet.data, sub.next)
          finish(name.value)
        } catch (_) {
          // malformed/unrelated payload on the same channel - ignore
        }
      }

      client.on('custom_payload', onPayload)

      try {
        // Registering the channel is the protocol-correct thing to do for a
        // client-side plugin channel; harmless to send even if the proxy
        // doesn't require it.
        client.write('custom_payload', {
          channel: 'minecraft:register',
          data: Buffer.from('bungeecord:main', 'utf8')
        })
        client.write('custom_payload', {
          channel: 'bungeecord:main',
          data: writeJavaUTF('GetServer')
        })
      } catch (err) {
        finish(null)
        return
      }

      setTimeout(() => finish(null), timeoutMs)
    })
  }

  /**
   * Sends a raw chat/command line (e.g. "/list") as the bot and collects
   * whatever the server prints to chat in the following window. This is a
   * best-effort capture, not a guaranteed request/response match - if
   * other players are also chatting at the same moment, their lines get
   * swept up too.
   */
  runCommand(cmdText, windowMs = 2500) {
    const bot = this.bot
    if (!bot) return Promise.reject(new Error('Bot is offline'))

    return new Promise((resolve, reject) => {
      const lines = []
      const onMessage = (jsonMsg) => {
        try {
          const text = jsonMsg.toString()
          if (text && text.trim()) lines.push(text)
        } catch (_) { /* ignore unparsable message */ }
      }

      bot.on('message', onMessage)
      try {
        bot.chat(cmdText)
      } catch (err) {
        bot.removeListener('message', onMessage)
        reject(err)
        return
      }

      setTimeout(() => {
        bot.removeListener('message', onMessage)
        resolve(lines)
      }, windowMs)
    })
  }

  start() {
    if (this.bot) return false
    this.desiredOnline = true
    this.reconnectDelay = MIN_RECONNECT_MS
    this._connect()
    return true
  }

  stop() {
    const wasRunning = !!this.bot
    this.desiredOnline = false
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer)
      this.reconnectTimer = null
    }
    if (this.bot) {
      try { this.bot.quit('stopped from discord') } catch (_) { /* already gone */ }
      this.bot = null
      this.startedAt = null
      this.phase = null
    }
    return wasRunning
  }

  _log(msg) {
    this.log.info(msg)
    if (this.hooks.onLog) this.hooks.onLog(msg)
  }

  _connect() {
    const cfg = this.config
    let bot
    try {
      bot = mineflayer.createBot({
        host: cfg.host,
        port: cfg.port,
        username: cfg.email,
        auth: 'microsoft',
        version: cfg.version,
        viewDistance: cfg.viewDistance,
        profilesFolder: path.join(__dirname, '..', 'auth_cache'),
        checkTimeoutInterval: 60_000,
        hideErrors: false,
        onMsaCode: (data) => {
          this._log(`Microsoft login needed: ${data.message}`)
          if (this.hooks.onMsaCode) this.hooks.onMsaCode(data)
        }
      })
    } catch (err) {
      this.lastError = err.message
      this._log(`Failed to create bot: ${err.message}`)
      this._scheduleReconnect()
      return
    }

    this.bot = bot
    this.joinCommandSent = false
    this.spawnCount = 0
    this.phase = null

    // Note: bot.on (not .once) - switching backend server behind the proxy
    // (hub -> smp) re-triggers Minecraft's join sequence, so mineflayer
    // fires 'spawn' again. That's what we use to tell hub and smp apart
    // without needing anything from the proxy itself.
    bot.on('spawn', () => {
      this.spawnCount += 1
      this.phase = this.spawnCount <= 1 ? 'hub' : 'smp'

      if (this.spawnCount === 1) {
        this.startedAt = Date.now()
        this.lastError = null
        this.reconnectDelay = MIN_RECONNECT_MS // reset backoff on a good connection
      }
      this._log(`Spawned as ${bot.username} on ${cfg.host} (phase: ${this.phase})`)

      if (!this.joinCommandSent && cfg.joinCommand) {
        this.joinCommandSent = true
        setTimeout(() => {
          if (this.bot === bot) {
            bot.chat(cfg.joinCommand)
            this._log(`Sent join command: ${cfg.joinCommand}`)
          }
        }, cfg.joinCommandDelayMs)
      }

      if (this.hooks.onSpawn) this.hooks.onSpawn(this.getStatus())
    })

    bot.on('kicked', (reason) => {
      this.lastKickReason = typeof reason === 'string' ? reason : JSON.stringify(reason)
      this._log(`Kicked: ${this.lastKickReason}`)
    })

    bot.on('error', (err) => {
      this.lastError = err && err.message ? err.message : String(err)
      this._log(`Bot error: ${this.lastError}`)
    })

    bot.on('end', (reason) => {
      const wasThisBot = this.bot === bot
      if (!wasThisBot) return // a newer bot instance already replaced this one
      this.bot = null
      this.startedAt = null
      this.phase = null
      this._log(`Disconnected${reason ? ` (${reason})` : ''}`)
      if (this.hooks.onEnd) this.hooks.onEnd(this.getStatus())
      if (this.desiredOnline) this._scheduleReconnect()
    })
  }

  _scheduleReconnect() {
    if (this.reconnectTimer) clearTimeout(this.reconnectTimer)
    const delay = this.reconnectDelay
    this._log(`Reconnecting in ${Math.round(delay / 1000)}s`)
    this.reconnectTimer = setTimeout(() => {
      if (this.desiredOnline) this._connect()
    }, delay)
    // exponential backoff with a cap, so a hard-down server doesn't turn into
    // a rapid reconnect loop that looks like a bot flood to anti-bot systems
    this.reconnectDelay = Math.min(this.reconnectDelay * 2, MAX_RECONNECT_MS)
  }
}

module.exports = McBotManager
