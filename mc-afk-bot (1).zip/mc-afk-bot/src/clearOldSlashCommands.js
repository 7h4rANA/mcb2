'use strict'
// One-off cleanup: if you previously ran the slash-command version of this
// bot, Discord still has /mc and /cmd registered even though the bot no
// longer answers them (you'd see "This interaction failed"). Run this once
// to remove them. Needs DISCORD_TOKEN and DISCORD_CLIENT_ID in your .env
// (and DISCORD_GUILD_ID too, if you registered guild-scoped commands).
require('dotenv').config()
const { REST, Routes } = require('discord.js')

async function main() {
  const token = process.env.DISCORD_TOKEN
  const clientId = process.env.DISCORD_CLIENT_ID
  const guildId = process.env.DISCORD_GUILD_ID
  if (!token || !clientId) {
    console.error('Need DISCORD_TOKEN and DISCORD_CLIENT_ID in .env to clear old commands.')
    process.exit(1)
  }

  const rest = new REST({ version: '10' }).setToken(token)

  if (guildId) {
    await rest.put(Routes.applicationGuildCommands(clientId, guildId), { body: [] })
    console.log('Cleared guild-scoped slash commands.')
  }
  await rest.put(Routes.applicationCommands(clientId), { body: [] })
  console.log('Cleared global slash commands.')
}

main().catch(err => {
  console.error('Failed to clear old commands:', err)
  process.exit(1)
})
