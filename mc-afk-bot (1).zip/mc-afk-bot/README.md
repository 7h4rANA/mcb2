# mc-afk-bot

A Minecraft AFK bot (mineflayer) controlled from Discord (discord.js) with plain
`!`-prefixed text commands, built to run comfortably on a 512MB VPS. It's one Node.js
process — not two — because running Discord and Minecraft as separate processes would
mean paying for two V8 runtimes, which is real memory you don't have to spare.

What it does:
- Logs into the server with your **premium Microsoft account** (device-code flow, no password stored).
- Joins the hub, waits a few seconds, sends `/smp`, then just sits there.
- Requests a **view distance of 3** chunks from the server (less chunk data sent to the bot = less RAM/bandwidth).
- Reconnects automatically with backoff if disconnected, unless you told it to stop.
- Discord commands: `!start`, `!stop`, `!status` (health/position/uptime/server), and
  `!cmd <text>` to send any raw command (or chat line) through the bot and get back
  whatever the server prints to chat in the next ~2.5 seconds.

## 1. Create the Discord application

1. Go to the Discord Developer Portal → **New Application**.
2. **Bot** tab → Add Bot → copy the **token** (this is `DISCORD_TOKEN`).
3. **Bot** tab → scroll to **Privileged Gateway Intents** → turn on **Message Content Intent**.
   This step is not optional: without it the bot can log in, but every message arrives with
   empty content, so it can never see your `!start` etc. and will look like it's "not responding."
4. **OAuth2 → URL Generator**: scope `bot` only (no `applications.commands` needed this time),
   permissions `Send Messages`, `Read Message History`, `View Channels`. Open the generated URL
   to invite it to your server.
5. Turn on Developer Mode in Discord (User Settings → Advanced), right-click yourself → **Copy User ID**
   → that's your `OWNER_IDS` value.

## 2. Configure

```bash
cp .env.example .env
nano .env
```

Fill in `DISCORD_TOKEN`, `OWNER_IDS`, `MC_HOST`, `MC_EMAIL`. Leave `MC_VERSION` blank unless
the server needs a specific one. `VIEW_DISTANCE=3`, `JOIN_COMMAND=/smp`, and `DISCORD_PREFIX=!`
are already set to what you asked for.

```bash
npm install --omit=dev
```

If other bots in your server also use `!` as a prefix, change `DISCORD_PREFIX` to something more
specific (e.g. `mc!`) to avoid both bots trying to answer the same message.

## 3. First run — Microsoft login

The first time the bot connects, Microsoft's device-code flow kicks in: a message like
*"open https://microsoft.com/link and enter code ABCD-EFGH"* appears in your console **and**,
if you set `STATUS_CHANNEL_ID`, is posted to that Discord channel too. Open the link on any
device, sign in with the Microsoft account that owns the license, enter the code. After that,
the token is cached under `auth_cache/` and you won't need to do this again unless you delete it
or it expires.

```bash
npm start
```

Once you see `Discord bot logged in as ...` in the logs, use `!start` in any channel the bot can
read in your server.

## Commands

| Command | What it does |
|---|---|
| `!start` | Connects the Minecraft bot |
| `!stop` | Disconnects it cleanly |
| `!status` | Health, position, ping, uptime, and which server (hub/smp) it's on |
| `!cmd <text>` | Sends `<text>` through the bot's chat and replies with whatever the server prints back |

All four are restricted to the Discord user IDs listed in `OWNER_IDS` — anyone else's `!start` etc.
just gets a "not allowed" reply. If you leave `OWNER_IDS` empty, anyone in the server can control it.

### `!status` and knowing hub vs. smp

Two signals feed the "Server" field:

1. **Guessed from the join sequence** (always available): the bot counts spawns. The first spawn
   after connecting is labelled `hub`; switching backend servers behind a Bungee-family proxy
   re-triggers Minecraft's join sequence, so the *next* spawn (after `/smp` is sent) is labelled `smp`.
2. **Queried from the proxy** (used when it answers): BungeeCord, Waterfall, and FlameCord (it's a
   BungeeCord fork) all implement a `GetServer` plugin-message channel that returns the real backend
   server name straight from the proxy. `!status` asks this every time it's run and uses the real
   name when it gets one, falling back to the guessed label if the proxy doesn't respond within 2s
   (an anti-bot layer dropping an unrecognized plugin channel is a plausible reason it might not).

### `!cmd` - sending arbitrary commands

`!cmd /list` sends `/list` as the bot and replies with whatever chat lines show up in the following
~2.5 seconds. Works the same for chat messages without a leading `/`. It's a capture window, not a
matched request/response — if another player's chat lands in that same window, it'll show up in the
output too.

## Coming from the old slash-command version?

If you'd already invited the bot and run `deploy-commands` before, Discord still remembers `/mc`
and `/cmd` as registered slash commands even though this version doesn't answer them anymore
(they'd show "This interaction failed" if used). To remove the leftovers:

```bash
# needs DISCORD_CLIENT_ID (and DISCORD_GUILD_ID if you registered guild-scoped) in .env,
# see the commented-out lines at the bottom of .env.example
npm run clear-old-commands
```

This is optional — the ghost commands are harmless clutter, not a functional problem.

## Running it 24/7 on the VPS (512MB RAM)

Skip pm2 for a box this small — the pm2 daemon itself is another Node process and eats
50-100MB you don't have. A plain systemd unit does the same job (auto-restart, start on boot)
for near-zero overhead.

`/etc/systemd/system/mc-afk-bot.service`:

```ini
[Unit]
Description=Minecraft AFK bot + Discord control
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=youruser
WorkingDirectory=/home/youruser/mc-afk-bot
ExecStart=/usr/bin/node --max-old-space-size=384 index.js
Restart=on-failure
RestartSec=10
Environment=NODE_ENV=production

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl daemon-reload
sudo systemctl enable --now mc-afk-bot
sudo journalctl -u mc-afk-bot -f     # logs
```

### If the VPS doesn't have swap yet

On a 512MB box, add 512MB-1GB of swap so a transient spike (npm install, a big chunk burst)
doesn't get the process OOM-killed:

```bash
sudo fallocate -l 1G /swapfile && sudo chmod 600 /swapfile
sudo mkswap /swapfile && sudo swapon /swapfile
echo '/swapfile none swap sw 0 0' | sudo tee -a /etc/fstab
```

### What actually costs RAM here, and what I did about it

- Two Node processes (Discord + Minecraft separately) → merged into one process, one V8 heap.
- discord.js only requests `Guilds` + `GuildMessages` + `MessageContent` — no presence tracking,
  no member caching, since the bot only needs to see messages and reply to them.
- No `pathfinder`, `prismarine-viewer`, or other mineflayer plugins are loaded — nothing here
  needs to move or render, so nothing extra is in memory.
- `viewDistance: 3` caps how many chunks the server sends, which is the single biggest lever
  on a bot that just stands still.
- `--max-old-space-size=384` caps the V8 heap so Node fails a GC before the OS OOM-kills the
  whole process (an OOM-kill loses the reconnect state; a capped heap can at least let it recover).

## About Papyrus / FlameCord

FlameCord is a BungeeCord/Waterfall fork sold as an anti-bot/anti-VPN layer; I don't have
public documentation on "Papyrus" specifically, so I can't promise byte-for-byte compatibility.
What I can say: anti-bot systems like this are built to catch unauthenticated connection floods,
fake/offline accounts, and packet-level exploits — not a real, Microsoft-authenticated client that
completes a normal handshake, which is what this bot is. mineflayer implements the full protocol
(encryption, compression, keep-alives) so it looks like a normal client at the connection level.

Two things I deliberately did **not** try to build in:
- Anything that fakes human-like movement to dodge behavioural bot-detection — that crosses into
  actively evading anti-abuse systems, which isn't something I'll help engineer.
- Any kind of CAPTCHA/verification solver, if the network's anti-bot ever presents one. If that
  happens, the practical fix is asking the server's staff to allowlist the bot's account/IP — a
  normal, common request for utility/AFK bots, and one only they can grant.

If FlameCord's bot-check does block the first join, the most likely cause is connecting too fast
after a previous disconnect — the exponential backoff in `mcBot.js` (15s → up to 5min) already
guards against that, since a tight reconnect loop is exactly the pattern anti-bot systems flag as
a flood.

## Troubleshooting

- **Bot doesn't come online at all / crashes on start** — almost always either a bad `DISCORD_TOKEN`,
  or `Message Content Intent` not switched on in the Developer Portal (step 3 above). Both show a
  clear error in the console right after `npm start` — check there first.
- **Commands don't respond** — confirm the bot has permission to read/send messages in the channel
  you're typing in, and that your Discord user ID is in `OWNER_IDS` (comma-separated, no spaces
  needed but harmless if present).
- **`!start` works but the bot never spawns in-game** — check the console/`journalctl` output;
  mineflayer logs connection errors (wrong `MC_HOST`/`MC_PORT`, version mismatch, auth failures) there.

## Files

```
mc-afk-bot/
├── index.js                    entry point, wires Discord + Minecraft together
├── src/
│   ├── config.js                loads/validates .env
│   ├── logger.js                 tiny timestamped logger
│   ├── mcBot.js                  mineflayer connection, reconnect/backoff, status, /cmd + server-name query
│   ├── bungeeUtil.js             Java modified-UTF8 codec for the proxy's GetServer plugin-message protocol
│   ├── discordBot.js            discord.js client, ! prefix command handling
│   └── clearOldSlashCommands.js  optional one-off cleanup if you used the old slash-command version
├── .env.example
└── package.json
```
