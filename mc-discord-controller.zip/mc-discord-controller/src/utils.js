function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function formatDuration(ms) {
  if (!ms || ms < 0) ms = 0;
  const totalSeconds = Math.floor(ms / 1000);
  const days = Math.floor(totalSeconds / 86400);
  const hours = Math.floor((totalSeconds % 86400) / 3600);
  const mins = Math.floor((totalSeconds % 3600) / 60);
  const secs = totalSeconds % 60;

  const parts = [];
  if (days) parts.push(`${days}d`);
  if (hours) parts.push(`${hours}h`);
  if (mins) parts.push(`${mins}m`);
  if (!days && !hours) parts.push(`${secs}s`);
  return parts.join(' ') || '0s';
}

// Turns "smp", "/smp", " smp " into "/smp". Used by !cmd.
function normalizeCommand(raw) {
  const trimmed = (raw || '').trim();
  if (!trimmed) return null;
  return trimmed.startsWith('/') ? trimmed : `/${trimmed}`;
}

function testPatterns(patterns, text) {
  if (!patterns || !text) return false;
  return patterns.some((p) => {
    try {
      return new RegExp(p, 'i').test(text);
    } catch {
      return false;
    }
  });
}

function isAuthorized(userId, ownerId, allowedIds) {
  if (userId === ownerId) return true;
  return Array.isArray(allowedIds) && allowedIds.includes(userId);
}

module.exports = { sleep, formatDuration, normalizeCommand, testPatterns, isAuthorized };
