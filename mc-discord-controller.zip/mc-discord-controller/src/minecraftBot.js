const mineflayer = require('mineflayer');
const EventEmitter = require('events');
const fs = require('fs');
const path = require('path');
const logger = require('./logger');
const state = require('./state');
const { sleep, testPatterns } = require('./utils');

class MinecraftController extends EventEmitter {
  constructor(env, config) {
    super();
    this.env = env;
    this.config = config;
    this.bot = null;
    this.cmdCaptures = []; // active !cmd output listeners: { lines: [] }
    this.antiAfkTimer = null;
    this.reconnecting = false;
  }

  isRunning() {
    return this.bot !== null;
  }

  async start() {
    if (this.bot) {
      this.emit('log', 'Minecraft bot is already running.');
      return;
    }
    state.set({ status: 'connecting', intentionalStop: false, reconnectAttempts: 0 });
    this.emit('log', `Connecting to ${this.env.MC_HOST}:${this.env.MC_PORT} ...`);
    this._createBot();
  }

  async stop() {
    state.set({ intentionalStop: true });
    if (this.bot) {
      this.emit('log', 'Disconnecting from Minecraft...');
      try {
        this.bot.quit('Stopped via Discord');
      } catch {
        // ignore - we're tearing it down anyway
      }
    }
    this._cleanupBot();
    state.set({ status: 'offline', currentServer: 'unknown', username: null, connectedAt: null });
    this.emit('log', 'Minecraft bot stopped.');
  }

  sendChat(msg) {
    if (!this.bot) throw new Error('Minecraft bot is not connected. Use !start first.');
    this.bot.chat(msg);
  }

  // Sends a command and returns whatever server messages arrive within the
  // configured capture window, so the caller can relay the output.
  async sendCommand(cmd) {
    if (!this.bot) throw new Error('Minecraft bot is not connected. Use !start first.');
    const capture = { lines: [] };
    this.cmdCaptures.push(capture);
    this.bot.chat(cmd);
    await sleep(this.config.cmdOutputCaptureMs || 5000);
    this.cmdCaptures = this.cmdCaptures.filter((c) => c !== capture);
    return capture.lines;
  }

  getStatusData() {
    const bot = this.bot;
    if (!bot || !bot.entity || !bot.username) {
      return { online: false };
    }
    const player = bot.players[bot.username];
    const pos = bot.entity.position;
    const dim = (bot.game && bot.game.dimension ? bot.game.dimension : '').replace('minecraft:', '');
    let zoneLabel = dim ? dim.charAt(0).toUpperCase() + dim.slice(1) : 'Unknown';

    for (const zone of this.config.zones || []) {
      const b = zone.bounds;
      if (pos.x >= b.x1 && pos.x <= b.x2 && pos.z >= b.z1 && pos.z <= b.z2) {
        zoneLabel = zone.name;
        break;
      }
    }

    return {
      online: true,
      username: bot.username,
      ping: player && typeof player.ping === 'number' ? player.ping : -1,
      uptimeMs: state.connectedAt ? Date.now() - state.connectedAt : 0,
      server: state.currentServer,
      zone: zoneLabel,
      health: bot.health,
    };
  }

  // Summary of the current effective connection settings, for the !settings
  // command. loginCommandSet is a boolean only - the actual LOGIN_COMMAND
  // value (which may contain a password) is never exposed here.
  getEffectiveSettings() {
    return {
      host: this.env.MC_HOST,
      port: Number(this.env.MC_PORT) || 25565,
      version: this.env.MC_VERSION || 'auto-detect',
      joinCommand: this._getJoinCommand(),
      smpEnabled: this._isSmpEnabled(),
      loginCommandSet: Boolean(this.env.LOGIN_COMMAND),
    };
  }

  // ---------------------------------------------------------------------

  // SMP_JOIN_COMMAND in .env is the easy way to change this; config.js's
  // server.joinCommand is just the fallback default if that's unset.
  _getJoinCommand() {
    return this.env.SMP_JOIN_COMMAND || this.config.server.joinCommand || '/joinqueue smp';
  }

  // SMP_ENABLED=false in .env turns off the whole hub->smp join flow - the
  // bot just stays in hub. Defaults on (any value other than the literal
  // string "false" is treated as enabled).
  _isSmpEnabled() {
    return this.env.SMP_ENABLED !== 'false';
  }

  _createBot() {
    // Per-connection state for the spawn-based server-switch detection and
    // the join-command throttle below - reset fresh for every new connection.
    this._spawnCount = 0;
    this._awaitingSmpJoin = false;
    this._lastCmdSentAt = 0;
    this._transferring = false;
    this._offlineRetryScheduled = false;
    clearTimeout(this._transferTimeout);

    const authCacheDir = path.join(process.cwd(), 'mc-auth-cache');
    if (!fs.existsSync(authCacheDir)) fs.mkdirSync(authCacheDir, { recursive: true });

    const options = {
      host: this.env.MC_HOST,
      port: Number(this.env.MC_PORT) || 25565,
      username: this.env.MC_EMAIL,
      auth: 'microsoft',
      version: this.env.MC_VERSION || false,
      viewDistance: this.config.viewDistance || 3,
      profilesFolder: authCacheDir,
      checkTimeoutInterval: 60000,
      onMsaCode: (data) => {
        const text =
          data && data.message
            ? data.message
            : `Open ${data.verification_uri} and enter code ${data.user_code} to sign in.`;
        this.emit('log', `MICROSOFT LOGIN REQUIRED: ${text}`);
      },
    };

    this.bot = mineflayer.createBot(options);
    this._registerKnockbackFix(this.bot);
    this._registerCustomPayloadGuard(this.bot);
    this._registerEvents(this.bot);
  }

  // mineflayer's built-in handling of the server's velocity packet (used for
  // knockback, explosions, elytra launches, etc) for the bot's OWN entity is
  // inconsistent across protocol versions - on some servers/versions it never
  // gets applied at all, which is why the bot could stand still and take no
  // knockback. This listens to the raw packet directly and applies it to the
  // bot's entity every time, independent of mineflayer's internal handling.
  // The /8000 divisor converts the protocol's fixed-point units into
  // blocks-per-tick, matching how prismarine-physics expects velocity.
  _registerKnockbackFix(bot) {
    bot._client.on('entity_velocity', (packet) => {
      if (!bot.entity || packet.entityId !== bot.entity.id) return;
      bot.entity.velocity.x = packet.velocityX / 8000;
      bot.entity.velocity.y = packet.velocityY / 8000;
      bot.entity.velocity.z = packet.velocityZ / 8000;
    });
  }

  // Proxies (BungeeCord/Velocity/Flamecord) and server plugins send custom
  // plugin-channel messages (e.g. for forwarding player info) that this bot
  // has no reason to act on. A no-op listener here just makes sure they're
  // acknowledged as handled rather than left to bubble up as an unhandled
  // packet error somewhere else in the stack.
  _registerCustomPayloadGuard(bot) {
    bot._client.on('custom_payload', () => {
      // intentionally empty - see comment above
    });
  }

  _cleanupBot() {
    if (this.antiAfkTimer) {
      clearInterval(this.antiAfkTimer);
      this.antiAfkTimer = null;
    }
    this.cmdCaptures = [];
    this.bot = null;
  }

  _registerEvents(bot) {
    bot.on('spawn', () => {
      this._spawnCount = (this._spawnCount || 0) + 1;

      if (this._spawnCount === 1) {
        // First spawn after connecting = the hub/lobby.
        this.emit('log', 'Spawned into the network (hub).');
        state.set({
          status: 'online',
          currentServer: 'hub',
          username: bot.username,
          connectedAt: Date.now(),
          reconnectAttempts: 0,
        });
        this._startAntiAfk();

        // Optional login-plugin command (e.g. "/login mypassword"). Sent a
        // couple seconds after spawn so the connection has settled. The
        // actual command text is NEVER logged/emitted anywhere, since it
        // likely contains a plaintext password - only that it was sent.
        if (this.env.LOGIN_COMMAND) {
          setTimeout(() => {
            if (!this.bot) return;
            this.emit('log', 'Sending login command...');
            this.bot.chat(this.env.LOGIN_COMMAND);
          }, 2000);
        }

        if (this._isSmpEnabled()) {
          setTimeout(() => this._joinTargetServer(), this.config.server.hubWaitMs || 10000);
        } else {
          this.emit('log', 'SMP_ENABLED is off - staying in hub.');
        }
        return;
      }

      // Any LATER spawn means the proxy swapped our backend server under us -
      // this is the protocol-level signal ("you got a whole new world") that
      // reliably tells us a server switch happened, regardless of what text
      // the network's plugins put in chat. This is what actually fixes
      // !status getting stuck on "hub": it no longer depends on guessing
      // chat wording at all for this part.
      if (this._awaitingSmpJoin) {
        this._awaitingSmpJoin = false;
        this._transferring = false;
        clearTimeout(this._transferTimeout);
        state.set({ currentServer: 'smp' });
        this.emit('log', 'Joined SMP.');
        this.emit('joinedSmp');
      } else if (state.currentServer === 'smp') {
        // We didn't ask to move and we were on smp -> proxy bounced us to hub.
        state.set({ currentServer: 'hub' });
        this.emit('log', 'Got sent back to hub.');
        if (!state.intentionalStop && this._isSmpEnabled()) {
          const delay = this.config.server.kickToHubRetryDelayMs || 10000;
          this.emit('log', `Retrying ${this._getJoinCommand()} in ${delay / 1000}s.`);
          setTimeout(() => this._joinTargetServer(), delay);
        }
      } else {
        this.emit('log', 'Server changed (proxy switch detected).');
      }
    });

    // System / server messages (join confirmations, queue, offline notices,
    // private messages, command output). Use this instead of 'chat' for
    // classification since it also covers non-player system lines.
    bot.on('message', (jsonMsg) => {
      try {
        // Legacy formatting codes (§c, §l, etc) and inconsistent spacing can
        // be present in a styled alert message even though it displays fine
        // to a human - left in, they can silently break an exact-text
        // regex match. Every detection function below runs on this cleaned
        // text, not the raw one.
        const text = this._stripFormatting(jsonMsg.toString());
        if (this.env.DEBUG_RAW_CHAT === 'true') this.emit('log', `[RAW] ${text}`);
        this._classifyServerMessage(text);
        this._checkTellMessage(text);
        this._checkCrateKey(text);
        for (const cap of this.cmdCaptures) cap.lines.push(text);
      } catch (err) {
        this.emit('log', `Error handling server message: ${err.message}`);
      }
    });

    // Player chat only - used for the "someone mentioned me" bonus feature.
    bot.on('chat', (username, message) => {
      try {
        if (!bot.username || username === bot.username) return;
        if (message.toLowerCase().includes(bot.username.toLowerCase())) {
          this.emit('mention', `<${username}> ${message}`);
        }
      } catch (err) {
        this.emit('log', `Error handling chat message: ${err.message}`);
      }
    });

    bot.on('death', () => {
      this.emit('log', 'Bot died in-game, respawning...');
      try {
        bot.respawn();
      } catch {
        // ignore
      }
    });

    bot.on('error', (err) => {
      this.emit('log', `Bot error: ${err.message}`);
    });

    let disconnectHandled = false;
    const onDisconnected = (reason) => {
      if (disconnectHandled) return;
      disconnectHandled = true;
      const readable = this._flattenReason(reason);
      state.set({ lastKickReason: readable });
      this.emit('log', `Disconnected: ${readable}`);
      this._cleanupBot();
      if (state.intentionalStop) {
        state.set({ status: 'offline', currentServer: 'unknown' });
        return;
      }
      const isRestart = testPatterns(this.config.detection.restarting, readable);
      if (isRestart) {
        this.emit('log', 'Server appears to be restarting - waiting longer before the first retry.');
      }
      this._scheduleReconnect(isRestart ? this.config.server.restartGraceMs : undefined);
    };

    bot.on('kicked', (reason) => onDisconnected(reason));
    bot.on('end', (reason) => onDisconnected(reason || 'connection ended'));
  }

  // Strips legacy Minecraft formatting codes (§ followed by a color/format
  // character) and collapses repeated whitespace down to single spaces. A
  // styled/colored alert message can otherwise contain these control
  // characters right in the middle of the text our detection regexes need
  // to match literally, which silently breaks the match even though the
  // message looks completely normal when displayed.
  _stripFormatting(text) {
    return text
      .replace(/§[0-9a-fk-or]/gi, '')
      .replace(/\s+/g, ' ')
      .trim();
  }

  _classifyServerMessage(text) {
    const d = this.config.detection;

    if (testPatterns(d.offline, text)) {
      this.emit('log', `Target server appears offline: "${text}"`);
      this.emit('offline', text);

      // Keep retrying indefinitely while smp is confirmed offline, instead
      // of sending one join attempt and then just sitting in hub forever.
      // Guarded by _offlineRetryScheduled so repeated offline messages for
      // the same attempt don't stack up multiple pending retries - only
      // one retry is ever in flight, each one scheduling the next if it's
      // still offline.
      if (state.currentServer !== 'smp' && !state.intentionalStop && !this._offlineRetryScheduled && this._isSmpEnabled()) {
        this._offlineRetryScheduled = true;
        const delay = this.config.server.offlineRetryDelayMs || 15000;
        this.emit('log', `smp is offline - will keep retrying every ${delay / 1000}s until it's up.`);
        setTimeout(() => {
          this._offlineRetryScheduled = false;
          if (!state.intentionalStop && state.currentServer !== 'smp') this._joinTargetServer();
        }, delay);
      }
      return;
    }
    if (testPatterns(d.queue, text)) {
      this.emit('log', `Queue update: "${text}"`);
      this.emit('queue', text);
      return;
    }
    // joinedHub/joinedSmp text is logged only, for reference - actual
    // currentServer state is driven by the spawn-count logic above, which
    // works regardless of a network's exact wording.
    if (testPatterns(d.joinedSmp, text)) this.emit('log', `(chat confirms) ${text}`);
  }

  // Detects an in-game /tell or /msg sent to you and emits { from, message }
  // for Discord to relay. Wording varies a lot by server - see config.js.
  _checkTellMessage(text) {
    for (const pattern of this.config.detection.tell || []) {
      try {
        const match = text.match(new RegExp(pattern, 'i'));
        if (match && match[1] && match[2]) {
          this.emit('tell', { from: match[1].trim(), message: match[2].trim(), raw: text });
          return;
        }
      } catch {
        // bad user-supplied regex - skip it rather than crash
      }
    }
  }

  // Detects a crate key you received in-game and emits { keyType, raw } for
  // Discord to relay. Wording is very plugin-dependent - see config.js ->
  // detection.crateKey. keyType is optional - the alert still sends without
  // it if the message doesn't match that specific pattern.
  _checkCrateKey(text) {
    const c = this.config.detection.crateKey;
    if (!c || !testPatterns(c.trigger, text)) return;

    let keyType = null;
    for (const pattern of c.keyType || []) {
      try {
        const match = text.match(new RegExp(pattern, 'i'));
        if (match && match[1]) {
          keyType = match[1].trim();
          break;
        }
      } catch {
        // bad user-supplied regex - skip it
      }
    }

    this.emit('crateKey', { keyType, raw: text });
  }

  _joinTargetServer() {
    if (!this.bot || !this._isSmpEnabled()) return;
    const now = Date.now();
    const minGap = 3000;
    if (this._lastCmdSentAt && now - this._lastCmdSentAt < minGap) {
      this.emit('log', 'Skipping join command - too soon since the last one (avoiding chat rate limit).');
      return;
    }
    this._lastCmdSentAt = now;
    this._awaitingSmpJoin = true;

    // Pause the anti-afk jiggle for a few seconds around the handoff. This
    // won't stop mineflayer's own physics tick packets (needed for real
    // physics/knockback), but it removes the one extra packet source we
    // control, reducing the chance of landing a packet in the split-second
    // window where the proxy is switching us between backend servers - a
    // window where a proxy-side decode desync (e.g. Bungee/Velocity
    // "BadPacketException") is more likely to get triggered. Safety timeout
    // clears this even if the expected respawn never arrives.
    this._transferring = true;
    clearTimeout(this._transferTimeout);
    this._transferTimeout = setTimeout(() => {
      this._transferring = false;
    }, 15000);

    const cmd = this._getJoinCommand();
    this.emit('log', `Sending ${cmd} ...`);
    this.bot.chat(cmd);
  }

  _scheduleReconnect(overrideDelayMs) {
    if (this.reconnecting) return;
    this.reconnecting = true;

    const attempts = (state.reconnectAttempts || 0) + 1;
    state.set({ reconnectAttempts: attempts });

    const maxAttempts = this.config.server.maxReconnectAttempts || 15;
    if (attempts > maxAttempts) {
      this.emit('log', `Giving up after ${attempts - 1} reconnect attempts. Use !start to try again manually.`);
      state.set({ status: 'offline' });
      this.reconnecting = false;
      return;
    }

    state.set({ status: 'connecting' });

    // Exponential backoff with jitter: attempt 1 waits ~base, each further
    // attempt waits longer (up to maxReconnectDelayMs), with +/-15% random
    // jitter. This survives long server restarts far better than a fixed
    // interval, and - as importantly - reconnecting on an irregular,
    // lengthening schedule is much less likely to get flagged by an anti-bot
    // "limbo" check than hammering the same fixed 10s interval repeatedly.
    // overrideDelayMs (used right after a detected restart/limbo kick) skips
    // straight to a longer wait instead of starting the backoff from scratch,
    // since we already know an immediate retry would just fail again.
    const base = this.config.server.fullDisconnectRetryDelayMs || 10000;
    const factor = this.config.server.reconnectBackoffFactor || 1.5;
    const cap = this.config.server.maxReconnectDelayMs || 60000;
    const raw = overrideDelayMs != null ? overrideDelayMs : Math.min(base * Math.pow(factor, attempts - 1), cap);
    const delay = Math.round(raw * (0.85 + Math.random() * 0.3));

    this.emit('log', `Reconnecting in ${Math.round(delay / 1000)}s (attempt ${attempts}/${maxAttempts})...`);
    setTimeout(() => {
      this.reconnecting = false;
      if (!state.intentionalStop) this._createBot();
    }, delay);
  }

  _startAntiAfk() {
    if (!this.config.antiAfk || !this.config.antiAfk.enabled) return;
    this.antiAfkTimer = setInterval(() => {
      if (!this.bot || !this.bot.entity || this._transferring) return;
      const yaw = this.bot.entity.yaw + (Math.random() - 0.5) * 0.3;
      try {
        this.bot.look(yaw, this.bot.entity.pitch, true);
      } catch {
        // ignore
      }
    }, this.config.antiAfk.intervalMs || 60000);
  }

  // Kick/disconnect reasons can arrive as plain chat-component JSON
  // ({text, extra: [...]}) or, on some servers/protocol versions, as an
  // NBT-typed-wrapper shape ({type: 'compound', value: {...}}) - which is
  // what was showing up as an unreadable wall of JSON in the logs. This
  // handles both and returns the actual human-readable message.
  _flattenReason(reason) {
    try {
      let obj = reason;
      if (typeof obj === 'string') {
        try {
          obj = JSON.parse(obj);
        } catch {
          return obj; // plain string, not JSON - use as-is
        }
      }

      const unwrapNbt = (node) => {
        if (Array.isArray(node)) return node.map(unwrapNbt);
        if (node && typeof node === 'object') {
          if ('type' in node && 'value' in node && typeof node.type === 'string') {
            const { type, value } = node;
            if (type === 'compound') {
              const out = {};
              for (const key of Object.keys(value)) out[key] = unwrapNbt(value[key]);
              return out;
            }
            if (type === 'list') {
              const inner = value && typeof value === 'object' && 'value' in value ? value.value : value;
              return unwrapNbt(inner);
            }
            return value; // leaf: string/byte/int/short/long/double/etc
          }
          // Plain object whose own fields are individually type/value-tagged
          // (this is the actual shape of each chat-component in the list) -
          // recurse into its properties instead of returning it untouched.
          const out = {};
          for (const key of Object.keys(node)) out[key] = unwrapNbt(node[key]);
          return out;
        }
        return node;
      };

      const collect = (node) => {
        if (node == null) return '';
        if (typeof node === 'string') return node;
        if (Array.isArray(node)) return node.map(collect).join('');
        if (typeof node === 'object') {
          let out = typeof node.text === 'string' ? node.text : '';
          if (Array.isArray(node.extra)) out += node.extra.map(collect).join('');
          return out;
        }
        return String(node);
      };

      const text = collect(unwrapNbt(obj)).trim();
      return text || JSON.stringify(obj);
    } catch {
      return typeof reason === 'string' ? reason : 'unknown reason';
    }
  }
}

module.exports = MinecraftController;
