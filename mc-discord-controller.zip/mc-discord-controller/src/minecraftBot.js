const mineflayer = require('mineflayer');
const EventEmitter = require('events');
const fs = require('fs');
const path = require('path');
const logger = require('./logger');
const state = require('./state');
const { sleep, testPatterns } = require('./utils');

class MinecraftController extends EventEmitter {
  constructor(env, config) {
    super();
    this.env = env;
    this.config = config;
    this.bot = null;
    this.cmdCaptures = []; // active !cmd output listeners: { lines: [] }
    this.antiAfkTimer = null;
    this.reconnecting = false;
  }

  isRunning() {
    return this.bot !== null;
  }

  async start() {
    if (this.bot) {
      this.emit('log', 'Minecraft bot is already running.');
      return;
    }
    state.set({ status: 'connecting', intentionalStop: false, reconnectAttempts: 0 });
    this.emit('log', `Connecting to ${this.env.MC_HOST}:${this.env.MC_PORT} ...`);
    this._createBot();
  }

  async stop() {
    state.set({ intentionalStop: true });
    if (this.bot) {
      this.emit('log', 'Disconnecting from Minecraft...');
      try {
        this.bot.quit('Stopped via Discord');
      } catch {
        // ignore - we're tearing it down anyway
      }
    }
    this._cleanupBot();
    state.set({ status: 'offline', currentServer: 'unknown', username: null, connectedAt: null });
    this.emit('log', 'Minecraft bot stopped.');
  }

  sendChat(msg) {
    if (!this.bot) throw new Error('Minecraft bot is not connected. Use !start first.');
    this.bot.chat(msg);
  }

  // Sends a command and returns whatever server messages arrive within the
  // configured capture window, so the caller can relay the output.
  async sendCommand(cmd) {
    if (!this.bot) throw new Error('Minecraft bot is not connected. Use !start first.');
    const capture = { lines: [] };
    this.cmdCaptures.push(capture);
    this.bot.chat(cmd);
    await sleep(this.config.cmdOutputCaptureMs || 5000);
    this.cmdCaptures = this.cmdCaptures.filter((c) => c !== capture);
    return capture.lines;
  }

  getStatusData() {
    const bot = this.bot;
    if (!bot || !bot.entity || !bot.username) {
      return { online: false };
    }
    const player = bot.players[bot.username];
    const pos = bot.entity.position;
    const dim = (bot.game && bot.game.dimension ? bot.game.dimension : '').replace('minecraft:', '');
    let zoneLabel = dim ? dim.charAt(0).toUpperCase() + dim.slice(1) : 'Unknown';

    for (const zone of this.config.zones || []) {
      const b = zone.bounds;
      if (pos.x >= b.x1 && pos.x <= b.x2 && pos.z >= b.z1 && pos.z <= b.z2) {
        zoneLabel = zone.name;
        break;
      }
    }

    return {
      online: true,
      username: bot.username,
      ping: player && typeof player.ping === 'number' ? player.ping : -1,
      uptimeMs: state.connectedAt ? Date.now() - state.connectedAt : 0,
      server: state.currentServer,
      zone: zoneLabel,
      health: bot.health,
    };
  }

  // ---------------------------------------------------------------------

  _createBot() {
    const authCacheDir = path.join(process.cwd(), 'mc-auth-cache');
    if (!fs.existsSync(authCacheDir)) fs.mkdirSync(authCacheDir, { recursive: true });

    const options = {
      host: this.env.MC_HOST,
      port: Number(this.env.MC_PORT) || 25565,
      username: this.env.MC_EMAIL,
      auth: 'microsoft',
      version: this.env.MC_VERSION || false,
      viewDistance: this.config.viewDistance || 3,
      profilesFolder: authCacheDir,
      checkTimeoutInterval: 60000,
      onMsaCode: (data) => {
        const text =
          data && data.message
            ? data.message
            : `Open ${data.verification_uri} and enter code ${data.user_code} to sign in.`;
        this.emit('log', `MICROSOFT LOGIN REQUIRED: ${text}`);
      },
    };

    this.bot = mineflayer.createBot(options);
    this._registerEvents(this.bot);
  }

  _cleanupBot() {
    if (this.antiAfkTimer) {
      clearInterval(this.antiAfkTimer);
      this.antiAfkTimer = null;
    }
    this.cmdCaptures = [];
    this.bot = null;
  }

  _registerEvents(bot) {
    bot.once('spawn', () => {
      this.emit('log', 'Spawned into the network (hub).');
      state.set({
        status: 'online',
        currentServer: 'hub',
        username: bot.username,
        connectedAt: Date.now(),
        reconnectAttempts: 0,
      });
      this._startAntiAfk();
      setTimeout(() => this._joinTargetServer(), this.config.server.hubWaitMs || 3000);
    });

    // System / server messages (join confirmations, queue, offline notices,
    // command output). Use this instead of 'chat' for classification since
    // it also covers non-player system lines.
    bot.on('message', (jsonMsg) => {
      const text = jsonMsg.toString();
      if (this.env.DEBUG_RAW_CHAT === 'true') this.emit('log', `[RAW] ${text}`);
      this._classifyServerMessage(text);
      for (const cap of this.cmdCaptures) cap.lines.push(text);
    });

    // Player chat only - used for the "someone mentioned me" bonus feature.
    bot.on('chat', (username, message) => {
      if (!bot.username || username === bot.username) return;
      if (message.toLowerCase().includes(bot.username.toLowerCase())) {
        this.emit('mention', `<${username}> ${message}`);
      }
    });

    bot.on('death', () => {
      this.emit('log', 'Bot died in-game, respawning...');
      try {
        bot.respawn();
      } catch {
        // ignore
      }
    });

    bot.on('error', (err) => {
      this.emit('log', `Bot error: ${err.message}`);
    });

    let disconnectHandled = false;
    const onDisconnected = (reason) => {
      if (disconnectHandled) return;
      disconnectHandled = true;
      state.set({ lastKickReason: reason });
      this.emit('log', `Disconnected: ${reason}`);
      this._cleanupBot();
      if (state.intentionalStop) {
        state.set({ status: 'offline', currentServer: 'unknown' });
      } else {
        this._scheduleReconnect(this.config.server.fullDisconnectRetryDelayMs);
      }
    };

    bot.on('kicked', (reason) => onDisconnected(this._reasonToString(reason)));
    bot.on('end', (reason) => onDisconnected(reason || 'connection ended'));
  }

  _classifyServerMessage(text) {
    const d = this.config.detection;

    if (testPatterns(d.offline, text)) {
      this.emit('log', `Target server appears offline: "${text}"`);
      this.emit('offline', text);
      return;
    }
    if (testPatterns(d.queue, text)) {
      this.emit('log', `Queue update: "${text}"`);
      this.emit('queue', text);
      return;
    }
    if (testPatterns(d.joinedSmp, text)) {
      const wasHub = state.currentServer !== 'smp';
      state.set({ currentServer: 'smp' });
      this.emit('log', 'Joined SMP.');
      if (wasHub) this.emit('joinedSmp');
      return;
    }
    if (testPatterns(d.joinedHub, text)) {
      const wasSmp = state.currentServer === 'smp';
      state.set({ currentServer: 'hub' });
      this.emit('log', 'Joined hub.');
      if (wasSmp && !state.intentionalStop) {
        const delay = this.config.server.kickToHubRetryDelayMs || 8000;
        this.emit('log', `Got sent back to hub - retrying ${this.config.server.joinCommand} in ${delay / 1000}s.`);
        setTimeout(() => this._joinTargetServer(), delay);
      }
    }
  }

  _joinTargetServer() {
    if (!this.bot) return;
    this.emit('log', `Sending ${this.config.server.joinCommand} ...`);
    this.bot.chat(this.config.server.joinCommand);
  }

  _scheduleReconnect(delay) {
    if (this.reconnecting) return;
    this.reconnecting = true;

    const attempts = (state.reconnectAttempts || 0) + 1;
    state.set({ reconnectAttempts: attempts });

    if (attempts > this.config.server.maxReconnectAttempts) {
      this.emit('log', `Giving up after ${attempts - 1} reconnect attempts. Use !start to try again manually.`);
      state.set({ status: 'offline' });
      this.reconnecting = false;
      return;
    }

    state.set({ status: 'connecting' });
    this.emit('log', `Reconnecting in ${delay / 1000}s (attempt ${attempts}/${this.config.server.maxReconnectAttempts})...`);
    setTimeout(() => {
      this.reconnecting = false;
      if (!state.intentionalStop) this._createBot();
    }, delay);
  }

  _startAntiAfk() {
    if (!this.config.antiAfk || !this.config.antiAfk.enabled) return;
    this.antiAfkTimer = setInterval(() => {
      if (!this.bot || !this.bot.entity) return;
      const yaw = this.bot.entity.yaw + (Math.random() - 0.5) * 0.3;
      try {
        this.bot.look(yaw, this.bot.entity.pitch, true);
      } catch {
        // ignore
      }
    }, this.config.antiAfk.intervalMs || 60000);
  }

  _reasonToString(reason) {
    try {
      return typeof reason === 'string' ? reason : JSON.stringify(reason);
    } catch {
      return 'unknown reason';
    }
  }
}

module.exports = MinecraftController;
