const { Client, GatewayIntentBits, EmbedBuilder, Options, ActivityType } = require('discord.js');
const logger = require('./logger');
const state = require('./state');
const { formatDuration, normalizeCommand, isAuthorized, getRamUsage } = require('./utils');

// Commands that only make sense from the main command channel (bot control).
const COMMAND_ONLY = new Set(['start', 'stop', 'restart', 'status', 'settings']);
// Commands that talk to the game and are also allowed from the mentions/chat
// channel, so you can reply right where you saw a mention or /tell. help is
// grouped here too since it's harmless to run from either channel.
const CHAT_COMMANDS = new Set(['cmd', 'chat', 'tell', 'r', 'help']);

function createDiscordClient(env, config, mc) {
  const client = new Client({
    intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent],
    // Cap caches so a long-running process on a small VPS doesn't slowly
    // grow its memory footprint over days/weeks.
    makeCache: Options.cacheWithLimits({
      MessageManager: 25,
      PresenceManager: 0,
      GuildMemberManager: 50,
      GuildStickerManager: 0,
      GuildEmojiManager: 0,
    }),
    sweepers: {
      messages: { interval: 300, lifetime: 600 },
    },
  });

  const prefix = env.PREFIX || '!';
  const ownerId = env.OWNER_ID;
  const allowedIds = (env.ALLOWED_USER_IDS || '')
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean);

  let cmdChannel = null;
  let logChannel = null;
  let mentionsChannel = null; // mentions + /tell,/msg,/w + crate keys - falls back to cmdChannel if unset

  // ---- batched log relay: avoids hitting Discord rate limits by sending
  // at most one message every 2s instead of one per log line. ----
  let logBuffer = [];
  async function flushLogs() {
    if (!logBuffer.length || !logChannel) return;
    let text = logBuffer.join('\n');
    logBuffer = [];
    if (text.length > 1900) text = text.slice(text.length - 1900);
    try {
      await logChannel.send('```\n' + text + '\n```');
    } catch (err) {
      console.error('Failed to send log batch to Discord:', err.message);
    }
  }
  setInterval(flushLogs, 2000);

  logger.setRelay((line) => logBuffer.push(line));
  mc.on('log', (line) => logBuffer.push(line));

  // Presence: "🟢/🔴 host:port" instead of a static "Playing ...", refreshed
  // every time the Minecraft connection state changes.
  function updatePresence() {
    if (!client.user) return;
    const emoji = state.status === 'online' ? '🟢' : '🔴';
    const port = Number(env.MC_PORT) || 25565;
    const address = port !== 25565 ? `${env.MC_HOST}:${port}` : env.MC_HOST;
    client.user.setPresence({
      status: 'online', // the Discord bot itself always shows online
      activities: [{ name: `${emoji} ${address}`, type: ActivityType.Playing }],
    });
  }
  state.on('change', updatePresence);

  client.once('ready', async () => {
    console.log(`Discord bot logged in as ${client.user.tag}`);
    cmdChannel = await client.channels.fetch(env.COMMAND_CHANNEL_ID).catch(() => null);
    if (!cmdChannel) {
      console.error(
        `Could not fetch COMMAND_CHANNEL_ID (${env.COMMAND_CHANNEL_ID}). Check the ID and that the bot has access to that channel.`
      );
    }
    logChannel = env.LOG_CHANNEL_ID
      ? await client.channels.fetch(env.LOG_CHANNEL_ID).catch(() => cmdChannel)
      : cmdChannel;
    mentionsChannel = env.MENTIONS_CHANNEL_ID
      ? await client.channels.fetch(env.MENTIONS_CHANNEL_ID).catch(() => cmdChannel)
      : cmdChannel;

    if (!env.MENTIONS_CHANNEL_ID) {
      console.log('MENTIONS_CHANNEL_ID not set - mentions, /tell, and crate key alerts will use the command channel instead.');
    }

    updatePresence();
  });

  async function buildStatusEmbed() {
    const data = mc.getStatusData();
    const ram = getRamUsage();
    const ramField = {
      name: 'RAM',
      value: `Process: ${ram.processRssMb} MB\nVPS: ${ram.usedMb} MB / ${ram.totalMb} MB`,
      inline: true,
    };
    const embed = new EmbedBuilder().setColor(data.online ? 0x57f287 : 0xed4245);

    if (!data.online) {
      embed.setTitle('Minecraft Bot Status').setDescription('Offline').addFields(ramField).setTimestamp();
      return embed;
    }

    embed
      .setTitle(data.username)
      .setThumbnail(`https://mc-heads.net/avatar/${encodeURIComponent(data.username)}/100`)
      .addFields(
        { name: 'Status', value: 'Online', inline: true },
        { name: 'Ping', value: `${data.ping} ms`, inline: true },
        { name: 'Uptime', value: formatDuration(data.uptimeMs), inline: true },
        { name: 'Server', value: data.server, inline: true },
        { name: 'World / Zone', value: data.zone, inline: true },
        { name: 'Health', value: `${Math.round(data.health ?? 0)} / 20`, inline: true },
        ramField
      )
      .setTimestamp();
    return embed;
  }

  function buildSettingsEmbed() {
    const s = mc.getEffectiveSettings();
    return new EmbedBuilder()
      .setColor(0x5865f2)
      .setTitle('Current Settings')
      .addFields(
        { name: 'Server', value: `${s.host}:${s.port}`, inline: true },
        { name: 'MC Version', value: s.version, inline: true },
        { name: 'Join Command', value: `\`${s.joinCommand}\``, inline: true },
        { name: 'SMP Joining', value: s.smpEnabled ? 'ON' : 'OFF', inline: true },
        { name: 'Login Command', value: s.loginCommandSet ? 'Set (hidden)' : 'Not set', inline: true }
      )
      .setTimestamp();
  }

  function buildHelpEmbed() {
    return new EmbedBuilder()
      .setColor(0x5865f2)
      .setTitle('Commands')
      .addFields(
        { name: `${prefix}start`, value: 'Connect the Minecraft bot.' },
        { name: `${prefix}stop`, value: 'Disconnect the Minecraft bot.' },
        { name: `${prefix}restart`, value: 'Restart everything (needs the systemd service).' },
        { name: `${prefix}status`, value: 'Show connection status, ping, uptime, RAM, etc.' },
        { name: `${prefix}settings`, value: 'Show current connection settings.' },
        { name: `${prefix}cmd <command>`, value: 'Run a raw in-game command and show the output.' },
        { name: `${prefix}chat <message>`, value: 'Send a public chat message in-game.' },
        { name: `${prefix}tell <player> <message>`, value: 'Send a private message to a player in-game.' },
        { name: `${prefix}r <message>`, value: 'Reply to the last private message in-game.' },
        { name: `${prefix}help`, value: 'Show this list.' }
      );
  }

  client.on('messageCreate', async (message) => {
    if (message.author.bot) return;
    if (!message.content.startsWith(prefix)) return;

    const withoutPrefix = message.content.slice(prefix.length).trim();
    const firstSpace = withoutPrefix.indexOf(' ');
    const cmd = (firstSpace === -1 ? withoutPrefix : withoutPrefix.slice(0, firstSpace)).toLowerCase();
    const argStr = firstSpace === -1 ? '' : withoutPrefix.slice(firstSpace + 1).trim();

    if (COMMAND_ONLY.has(cmd) && env.COMMAND_CHANNEL_ID && message.channel.id !== env.COMMAND_CHANNEL_ID) return;
    if (CHAT_COMMANDS.has(cmd)) {
      const allowedChatChannelIds = [env.COMMAND_CHANNEL_ID, env.MENTIONS_CHANNEL_ID].filter(Boolean);
      if (allowedChatChannelIds.length && !allowedChatChannelIds.includes(message.channel.id)) return;
    }
    if (!COMMAND_ONLY.has(cmd) && !CHAT_COMMANDS.has(cmd)) return; // unknown command - ignore silently

    if (!isAuthorized(message.author.id, ownerId, allowedIds)) {
      message.reply('You are not authorized to use this bot.').catch(() => {});
      return;
    }

    try {
      switch (cmd) {
        case 'start': {
          if (mc.isRunning()) {
            await message.reply('Already running.');
            break;
          }
          await message.reply('Starting Minecraft bot...');
          await mc.start();
          break;
        }

        case 'stop': {
          await message.reply('Stopping Minecraft bot...');
          await mc.stop();
          break;
        }

        case 'restart': {
          await message.reply(
            'Restarting everything. This requires the systemd service (Restart=always) to bring it back up - see README.'
          );
          await mc.stop();
          setTimeout(() => process.exit(0), 1000);
          break;
        }

        case 'status': {
          const embed = await buildStatusEmbed();
          await message.reply({ embeds: [embed] });
          break;
        }

        case 'settings': {
          await message.reply({ embeds: [buildSettingsEmbed()] });
          break;
        }

        case 'cmd': {
          if (!argStr) {
            await message.reply('Usage: `!cmd <command>` e.g. `!cmd smp`');
            break;
          }
          const normalized = normalizeCommand(argStr);
          const sentMsg = await message.reply(`Sending \`${normalized}\` in-game...`);
          const lines = await mc.sendCommand(normalized);
          const out = lines.length ? lines.slice(0, 15).join('\n') : '(no output captured)';
          await sentMsg.edit(`Sent \`${normalized}\`. Output:\n\`\`\`\n${out.slice(0, 1800)}\n\`\`\``);
          break;
        }

        case 'chat': {
          if (!argStr) {
            await message.reply('Usage: `!chat <message>`');
            break;
          }
          mc.sendChat(argStr);
          await message.react('✅').catch(() => {});
          break;
        }

        case 'tell': {
          const firstArgSpace = argStr.indexOf(' ');
          if (!argStr || firstArgSpace === -1) {
            await message.reply('Usage: `!tell <player> <message>`');
            break;
          }
          const player = argStr.slice(0, firstArgSpace);
          const tellMessage = argStr.slice(firstArgSpace + 1).trim();
          mc.sendChat(`/tell ${player} ${tellMessage}`);
          await message.react('✅').catch(() => {});
          break;
        }

        case 'r': {
          if (!argStr) {
            await message.reply('Usage: `!r <message>`');
            break;
          }
          // Forwarded as the server's own /r command rather than tracked
          // client-side, so "last person who messaged you" always matches
          // whatever the server itself considers the last conversation.
          mc.sendChat(`/r ${argStr}`);
          await message.react('✅').catch(() => {});
          break;
        }

        case 'help': {
          await message.reply({ embeds: [buildHelpEmbed()] });
          break;
        }

        default:
          return;
      }
    } catch (err) {
      message.reply(`Error: ${err.message}`).catch(() => {});
    }
  });

  // ---- events pushed from the Minecraft bot into Discord ----

  mc.on('joinedSmp', async () => {
    if (!cmdChannel) return;
    await cmdChannel.send('Successfully joined the SMP!').catch(() => {});
    const embed = await buildStatusEmbed();
    cmdChannel.send({ embeds: [embed] }).catch(() => {});
  });

  mc.on('offline', (text) => {
    if (!cmdChannel) return;
    const embed = new EmbedBuilder().setColor(0xed4245).setTitle('SMP appears offline').setDescription(text).setTimestamp();
    cmdChannel.send({ embeds: [embed] }).catch(() => {});
  });

  mc.on('queue', (text) => {
    if (!cmdChannel) return;
    const embed = new EmbedBuilder().setColor(0x5865f2).setTitle('Queue update').setDescription(text).setTimestamp();
    cmdChannel.send({ embeds: [embed] }).catch(() => {});
  });

  // In-game mentions - plain text only, no embed. Kept visibly different
  // from /tell (titled embed below) and crate keys (embed below) on purpose:
  // a bare "💬" line vs a colored, titled card should never be confusable
  // even scrolling quickly.
  mc.on('mention', (text) => {
    if (!mentionsChannel) return;
    mentionsChannel.send(`💬 Mentioned in game: ${text}`).catch(() => {});
  });

  // /tell, /msg, /w (private message) sent to you in-game - Rich Embed,
  // clearly titled, with Sender/Receiver fields, alongside the compact
  // "[sender]->me : message" description line.
  mc.on('tell', ({ from, message }) => {
    if (!mentionsChannel) return;
    const embed = new EmbedBuilder()
      .setColor(0x9b59b6)
      .setTitle('📩 Private Message')
      .setDescription(`[${from}]->me : ${message}`)
      .addFields(
        { name: 'Sender', value: from, inline: true },
        { name: 'Receiver', value: mc.getStatusData().username || 'You', inline: true }
      )
      .setTimestamp();
    mentionsChannel.send({ embeds: [embed] }).catch(() => {});
  });

  // Crate key received in-game.
  mc.on('crateKey', ({ keyType, raw }) => {
    if (!mentionsChannel) return;
    const embed = new EmbedBuilder()
      .setColor(0xf1c40f)
      .setTitle('🔑 Crate Key Received')
      .setDescription(keyType ? `**${keyType}** crate key` : raw)
      .setTimestamp();
    mentionsChannel.send({ embeds: [embed] }).catch(() => {});
  });

  return client;
}

module.exports = { createDiscordClient };
