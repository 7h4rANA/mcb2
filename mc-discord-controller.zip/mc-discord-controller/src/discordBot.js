const { Client, GatewayIntentBits, EmbedBuilder, Options } = require('discord.js');
const logger = require('./logger');
const { formatDuration, normalizeCommand, isAuthorized } = require('./utils');

function createDiscordClient(env, config, mc) {
  const client = new Client({
    intents: [
      GatewayIntentBits.Guilds,
      GatewayIntentBits.GuildMessages,
      GatewayIntentBits.MessageContent,
    ],
    // Cap caches so a long-running process on a small VPS doesn't slowly
    // grow its memory footprint over days/weeks.
    makeCache: Options.cacheWithLimits({
      MessageManager: 25,
      PresenceManager: 0,
      GuildMemberManager: 50,
      GuildStickerManager: 0,
      GuildEmojiManager: 0,
    }),
    sweepers: {
      messages: { interval: 300, lifetime: 600 },
    },
  });

  const prefix = env.PREFIX || '!';
  const ownerId = env.OWNER_ID;
  const allowedIds = (env.ALLOWED_USER_IDS || '')
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean);

  let cmdChannel = null;
  let logChannel = null;

  // ---- batched log relay: avoids hitting Discord rate limits by sending
  // at most one message every 2s instead of one per log line. ----
  let logBuffer = [];
  async function flushLogs() {
    if (!logBuffer.length || !logChannel) return;
    let text = logBuffer.join('\n');
    logBuffer = [];
    if (text.length > 1900) text = text.slice(text.length - 1900);
    try {
      await logChannel.send('```\n' + text + '\n```');
    } catch (err) {
      console.error('Failed to send log batch to Discord:', err.message);
    }
  }
  setInterval(flushLogs, 2000);

  logger.setRelay((line) => logBuffer.push(line));
  mc.on('log', (line) => logBuffer.push(line));

  client.once('ready', async () => {
    console.log(`Discord bot logged in as ${client.user.tag}`);
    cmdChannel = await client.channels.fetch(env.COMMAND_CHANNEL_ID).catch(() => null);
    if (!cmdChannel) {
      console.error(
        `Could not fetch COMMAND_CHANNEL_ID (${env.COMMAND_CHANNEL_ID}). Check the ID and that the bot has access to that channel.`
      );
    }
    logChannel = env.LOG_CHANNEL_ID
      ? await client.channels.fetch(env.LOG_CHANNEL_ID).catch(() => cmdChannel)
      : cmdChannel;

    client.user.setPresence({ status: 'online', activities: [{ name: `${prefix}status` }] });
  });

  async function buildStatusEmbed() {
    const data = mc.getStatusData();
    const embed = new EmbedBuilder().setColor(data.online ? 0x57f287 : 0xed4245);

    if (!data.online) {
      embed.setTitle('Minecraft Bot Status').setDescription('Offline');
      return embed;
    }

    embed
      .setTitle(data.username)
      .setThumbnail(`https://mc-heads.net/avatar/${encodeURIComponent(data.username)}/100`)
      .addFields(
        { name: 'Status', value: 'Online', inline: true },
        { name: 'Ping', value: `${data.ping} ms`, inline: true },
        { name: 'Uptime', value: formatDuration(data.uptimeMs), inline: true },
        { name: 'Server', value: data.server, inline: true },
        { name: 'World / Zone', value: data.zone, inline: true },
        { name: 'Health', value: `${Math.round(data.health ?? 0)} / 20`, inline: true }
      );
    return embed;
  }

  client.on('messageCreate', async (message) => {
    if (message.author.bot) return;
    if (!message.content.startsWith(prefix)) return;
    if (env.COMMAND_CHANNEL_ID && message.channel.id !== env.COMMAND_CHANNEL_ID) return;

    if (!isAuthorized(message.author.id, ownerId, allowedIds)) {
      message.reply('You are not authorized to use this bot.').catch(() => {});
      return;
    }

    const withoutPrefix = message.content.slice(prefix.length).trim();
    const firstSpace = withoutPrefix.indexOf(' ');
    const cmd = (firstSpace === -1 ? withoutPrefix : withoutPrefix.slice(0, firstSpace)).toLowerCase();
    const argStr = firstSpace === -1 ? '' : withoutPrefix.slice(firstSpace + 1).trim();

    try {
      switch (cmd) {
        case 'start': {
          if (mc.isRunning()) {
            await message.reply('Already running.');
            break;
          }
          await message.reply('Starting Minecraft bot...');
          await mc.start();
          break;
        }

        case 'stop': {
          await message.reply('Stopping Minecraft bot...');
          await mc.stop();
          break;
        }

        case 'restart': {
          await message.reply(
            'Restarting everything. This requires the systemd service (Restart=always) to bring it back up - see README.'
          );
          await mc.stop();
          setTimeout(() => process.exit(0), 1000);
          break;
        }

        case 'status': {
          const embed = await buildStatusEmbed();
          await message.reply({ embeds: [embed] });
          break;
        }

        case 'cmd': {
          if (!argStr) {
            await message.reply('Usage: `!cmd <command>` e.g. `!cmd smp`');
            break;
          }
          const normalized = normalizeCommand(argStr);
          const sentMsg = await message.reply(`Sending \`${normalized}\` in-game...`);
          const lines = await mc.sendCommand(normalized);
          const out = lines.length ? lines.slice(0, 15).join('\n') : '(no output captured)';
          await sentMsg.edit(`Sent \`${normalized}\`. Output:\n\`\`\`\n${out.slice(0, 1800)}\n\`\`\``);
          break;
        }

        case 'chat': {
          if (!argStr) {
            await message.reply('Usage: `!chat <message>`');
            break;
          }
          mc.sendChat(argStr);
          await message.react('✅').catch(() => {});
          break;
        }

        default:
          return; // unknown command - ignore silently
      }
    } catch (err) {
      message.reply(`Error: ${err.message}`).catch(() => {});
    }
  });

  // ---- events pushed from the Minecraft bot into Discord ----

  mc.on('joinedSmp', async () => {
    if (!cmdChannel) return;
    await cmdChannel.send('Successfully joined the SMP!').catch(() => {});
    const embed = await buildStatusEmbed();
    cmdChannel.send({ embeds: [embed] }).catch(() => {});
  });

  mc.on('offline', (text) => {
    if (cmdChannel) cmdChannel.send(`SMP looks offline: ${text}`).catch(() => {});
  });

  mc.on('queue', (text) => {
    if (cmdChannel) cmdChannel.send(`Queue: ${text}`).catch(() => {});
  });

  mc.on('mention', (text) => {
    if (cmdChannel) cmdChannel.send(`Mentioned in game: ${text}`).catch(() => {});
  });

  return client;
}

module.exports = { createDiscordClient };
