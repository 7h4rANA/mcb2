# Minecraft AFK Bot + Discord Controller

A single Node.js process that runs a Minecraft bot (Microsoft account login, real
player physics) and a Discord bot side by side in the same process, so they stay
perfectly in sync with no IPC/sockets/extra RAM overhead. Built to run comfortably
on a 750MB Ubuntu VPS.

## Architecture (why it's built this way)

- **One process, not two.** Running the Discord bot and the Minecraft bot as
  separate processes would mean setting up IPC (a socket, a file, a queue) just so
  they can talk to each other, and paying for two Node runtimes in RAM. Instead,
  `src/index.js` starts both in the same process and they talk directly through
  function calls and a shared `state.js` + event emitter. This is the "sync"
  between them: Discord commands call straight into the Minecraft controller, and
  the Minecraft controller emits events (`log`, `joinedSmp`, `queue`, `offline`,
  `mention`) that the Discord side listens to and relays.
- **The Discord bot never goes down when the Minecraft bot does.** Minecraft
  connection errors are caught and turned into log lines / reconnect logic, not
  thrown - so a server restart or a bad kick on the MC side never kills your
  Discord connection. `!status` will happily tell you the MC bot is offline.
- **No pathfinding library.** Server-to-server travel on your network happens via
  proxy commands (`/smp`, `/hub-01`, ...), not by physically walking, so
  `mineflayer-pathfinder` isn't included - one less (fairly heavy) dependency.
- **No native modules.** `.npmrc` skips optional native add-ons (`bufferutil`,
  `utf-8-validate`, `zlib-sync`) that `discord.js`/`ws` can use for a small speed
  boost. Skipping them means you don't need `build-essential`/`gcc` on the VPS at
  all, and there's nothing to fail to compile. The pure-JS fallbacks are plenty
  fast for a single-bot controller.

## What you get

```
mc-discord-controller/
├── config.js                  # tunable behavior (view distance, zones, regex, delays)
├── .env.example                # copy to .env - secrets & IDs
├── package.json
├── .npmrc
├── deploy/
│   └── mc-controller.service  # systemd unit for always-on deployment
└── src/
    ├── index.js                # entry point / wiring / shutdown
    ├── discordBot.js           # commands, status embed, log relay
    ├── minecraftBot.js         # mineflayer connection, join/queue/kick logic
    ├── state.js                 # shared state both bots read/write
    ├── logger.js
    └── utils.js
```

## 1. Server prerequisites (do this once)

SSH into your VPS as a sudo-capable user.

```bash
sudo apt update && sudo apt upgrade -y
```

**Add swap.** A 750MB box has very little headroom - a 1GB swapfile is cheap
insurance against the OOM killer taking down the process during a GC spike or a
temporary memory blip, at the cost of some disk I/O if it's ever actually used:

```bash
sudo fallocate -l 1G /swapfile
sudo chmod 600 /swapfile
sudo mkswap /swapfile
sudo swapon /swapfile
echo '/swapfile none swap sw 0 0' | sudo tee -a /etc/fstab
```

**Install Node.js 20 LTS** (via NodeSource - avoids compiling anything):

```bash
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs
node -v   # should print v20.x
```

**Create a dedicated user** to run the bot (good practice, keeps it isolated):

```bash
sudo adduser --disabled-password --gecos "" mcbot
sudo su - mcbot
```

## 2. Get the files onto the VPS

Upload this whole folder to `/home/mcbot/mc-discord-controller` (via `scp`,
`rsync`, or `git clone` if you've pushed it to your own repo), then:

```bash
cd /home/mcbot/mc-discord-controller
npm install --omit=dev
```

This pulls in `discord.js`, `mineflayer`, and `dotenv` only (plus their required
sub-dependencies like `prismarine-auth` for Microsoft login). No `pathfinder`, no
viewer, no build tools required.

## 3. Create your Discord application

1. Go to https://discord.com/developers/applications → **New Application**.
2. **Bot** tab → **Add Bot**. Copy the token → this is your `DISCORD_TOKEN`.
3. Still on the **Bot** tab, scroll to **Privileged Gateway Intents** and enable
   **MESSAGE CONTENT INTENT**. This is required or the bot will receive empty
   message content and every command will silently fail to parse - it's the
   single most common "why isn't my bot responding" bug, so don't skip it.
4. **OAuth2 → URL Generator**: scope `bot`, permissions `Send Messages`,
   `Embed Links`, `Read Message History`, `Add Reactions`. Open the generated
   URL and invite the bot to your server.
5. In Discord, enable Developer Mode (User Settings → Advanced), then right
   click your target text channel → **Copy Channel ID** (`COMMAND_CHANNEL_ID`),
   and right click your own name → **Copy User ID** (`OWNER_ID`).

## 4. Configure

```bash
cp .env.example .env
nano .env
```

Fill in `DISCORD_TOKEN`, `OWNER_ID`, `COMMAND_CHANNEL_ID`, `MC_HOST`, `MC_PORT`,
`MC_EMAIL`. Leave `MC_VERSION` blank (auto-detect).

Open `config.js` and, at minimum, set `server.joinCommand` if your SMP isn't
literally `/smp`, and fill in `zones` with your farm/spawn coordinates if you
want `!status` to show a friendly zone name instead of just "Overworld".

## 5. First run (interactive - do this before installing the service)

The very first time you connect, Microsoft's device-code login flow needs to
happen, so run it in the foreground first where you can see the output:

```bash
npm start
```

Watch the console for a line like:

```
MICROSOFT LOGIN REQUIRED: To sign in, use a web browser to open the page
https://microsoft.com/link and enter the code ABCD-EFGH to authenticate.
```

(The same message is also relayed to your Discord log channel once the Discord
side is connected, in case you're not watching the terminal.) Open that URL on
**any** device, enter the code, and log in with the Microsoft account tied to
the Minecraft profile you want the bot to use. This only needs to happen once -
after a successful login, tokens are cached in `./mc-auth-cache/` and reused on
future starts (until they eventually expire, at which point you'll be asked to
repeat this step).

**`mc-auth-cache/` is sensitive** - treat it like a password file. It's already
excluded via `.gitignore`; don't upload it anywhere public.

Once you see `Discord bot logged in as ...` in the console, go to your
`COMMAND_CHANNEL_ID` channel in Discord and try `!status`. Press `Ctrl+C` to
stop the foreground run once you've confirmed it works.

## 6. Install as a systemd service (always-on)

`!restart` and automatic crash-recovery both depend on the process being
managed by systemd with `Restart=always` - this isn't optional if you want
those to work.

```bash
exit   # back to your sudo user, out of the mcbot shell
sudo cp /home/mcbot/mc-discord-controller/deploy/mc-controller.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now mc-controller
sudo systemctl status mc-controller
```

View logs any time with:

```bash
journalctl -u mc-controller -f
```

## Commands

| Command | What it does |
|---|---|
| `!start` | Connects the Minecraft bot. Streams connect/join/queue logs to Discord. On success, posts a confirmation and automatically shows `!status`. |
| `!status` | Embed with in-game username, online/offline, ping, uptime, current backend server (hub/smp), world/zone, health, and skin face. |
| `!stop` | Disconnects the Minecraft bot cleanly so you can log in normally. |
| `!restart` | Stops everything and exits the process; systemd brings it back up. |
| `!cmd <command>` | Sends `/<command>` in-game (adds the leading `/` for you if you omit it) and replies with whatever the server sent back. E.g. `!cmd smp`, `!cmd hub-01`, `!cmd shards`, `!cmd balance`. |
| `!chat <message>` | Sends `<message>` as regular in-game chat, as you. |

Bonus behavior (no command needed):
- If someone's message in-game contains your username, it's relayed to Discord.
- If the bot gets bounced from smp back to the hub, it waits
  `kickToHubRetryDelayMs` and automatically resends the join command.
- If the bot gets fully disconnected from the network, it waits
  `fullDisconnectRetryDelayMs` and reconnects from scratch, then repeats the
  hub→smp join sequence - up to `maxReconnectAttempts` before giving up and
  waiting for a manual `!start`.

## Tuning the join/queue/offline detection (important)

Every network words its queue/offline/welcome messages differently, and there's
no way to know your specific SMP's exact wording in advance. `config.js`'s
`detection` block ships with generic patterns as a starting point - you should
verify (and likely tweak) them:

1. Set `DEBUG_RAW_CHAT=true` in `.env`.
2. Restart the bot and run `!start`, watching the Discord log channel.
3. Note the exact text your server sends for: successfully joining hub,
   successfully joining smp, being queued, and smp being offline.
4. Update the four arrays in `config.js` → `detection` to match, using simple
   substrings or regex.
5. Set `DEBUG_RAW_CHAT=false` again once you're happy (it's noisy).

## Real physics, knockback, and the farm

The bot uses mineflayer's default physics simulation (gravity, collision, and
server-authoritative velocity packets), so it takes knockback and falls/collides
like a real client - nothing extra to configure there. The bot also never digs,
places, or interacts with blocks anywhere in this codebase; it only moves its
camera slightly for the anti-idle jiggle (position unchanged) and responds to
chat/commands. That's deliberate - it's the surest way to avoid ever disturbing
a bonemeal farm or triggering a "bugged" state, since the bot simply never
issues a block-interaction packet in the first place.

## Memory tuning notes

- `npm start` runs with `--max-old-space-size=256`, capping the V8 heap so a
  leak or a big GC spike can't eat the whole box; the systemd unit sets a hard
  `MemoryMax=400M` as a second line of defense.
- `viewDistance: 3` in `config.js` keeps mineflayer's chunk cache small
  (~7x7 chunks, the closest fit to "6x6" - view distance in Minecraft is a
  radius, so it's always an odd-numbered square). Raise it if you need the bot
  to see further; lower it for even less RAM.
- Discord.js caches are capped (`makeCache` limits + a message sweeper) so
  memory doesn't creep up over days of uptime.
- Logs to Discord are batched (max one message per 2 seconds) instead of one
  API call per line, which also happens to keep CPU/network usage low.

## Ping

Since both the VPS and the SMP are in Singapore, you shouldn't need to do
anything special - the connection is already about as short as it can be. No
extra tuning was added here; if you ever move the VPS or the server, latency is
mostly a function of that distance, not this code.

## Troubleshooting

| Symptom | Likely cause |
|---|---|
| Bot doesn't respond to any command | `MESSAGE CONTENT INTENT` not enabled in the Developer Portal (step 3.3), or `COMMAND_CHANNEL_ID` is wrong. |
| `Missing required .env value(s)` on start | One of `DISCORD_TOKEN`, `OWNER_ID`, `COMMAND_CHANNEL_ID`, `MC_HOST`, `MC_EMAIL` is empty in `.env`. |
| Stuck asking for Microsoft login every restart | The `mc-auth-cache/` folder got deleted or isn't writable by the `mcbot` user - check `ls -la mc-auth-cache`. |
| `!start` connects but never detects smp/queue/offline | The detection patterns in `config.js` don't match your server's actual wording - see the tuning section above. |
| `!restart` stops the bot and it never comes back | You're not running it via the systemd service (`Restart=always`) - see step 6. |
| Process gets killed under memory pressure | Confirm the swapfile is active (`swapon --show`), and that `MemoryMax` in the service file isn't set below `--max-old-space-size`. |

## A quick note on server rules

AFK/macro bots are against the rules on some servers and fine on others - it's
worth double-checking your SMP's rules before running this long-term, since
that's between you and the server, not something this code can know for you.

## Security

- `.env` and `mc-auth-cache/` contain real credentials/tokens - never commit or
  share them.
- Only `OWNER_ID` (plus anyone listed in `ALLOWED_USER_IDS`) can run commands;
  everyone else gets an "unauthorized" reply.
- Consider restricting the command channel to a private channel only you can
  see, as a second layer on top of the ID check.
