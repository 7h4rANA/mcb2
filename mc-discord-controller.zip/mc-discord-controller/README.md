# Minecraft AFK Bot + Discord Controller

A single Node.js process that runs a Minecraft bot (Microsoft account login, real
player physics) and a Discord bot side by side in the same process, so they stay
perfectly in sync with no IPC/sockets/extra RAM overhead. Built to run comfortably
on a 750MB Ubuntu VPS.

## Changelog

### v1.4.0 - simplification + crate keys

- **Back to `!` prefix commands, not slash commands.** Slash commands add a
  registration round-trip to Discord's API and can feel slow to show up/load
  compared to a plain message the bot just replies to instantly - not worth
  the tradeoff for a personal control bot. This does mean **MESSAGE CONTENT
  INTENT** needs to be enabled again in the Developer Portal (see setup below)
  - the opposite of the slash-command version, which needed no privileged
  intents at all.
- **Removed ghost-block/anti-cheat alerts and scoreboard ping extraction.**
  Both were unreliable against this server's actual output and added
  complexity for a feature that wasn't working - simpler to cut them than
  keep chasing a regex that won't match. Ping now comes from the tab list
  only.
- **Removed `/tpa`/`/tpahere` teleport-request alerts** - not useful enough
  to keep.
- **New: crate key alerts.** When the server tells you you've received a
  crate key, it's relayed to `MENTIONS_CHANNEL_ID` as a titled embed showing
  the key type where it can be extracted (e.g. "Legendary", "Vote"). Wording
  is plugin-dependent - see the tuning section below.
- **New: `!help` command** listing every command with a one-line description
  - added specifically to make up for the discoverability a slash-command `/`
  menu would normally give you, now that we're back to plain-text commands.
- **Strengthened the mention vs. `/tell` distinction**: mentions are a plain
  `💬` line, `/tell`/`/msg`/`/w` alerts are a titled `📩 Private Message`
  embed with Sender/Receiver fields - unmistakable from each other even
  scrolling quickly.
- Real player physics/knockback (direct `entity_velocity` packet handling)
  and `viewDistance: 3` (~7x7 chunks around the bot, enough to keep a nearby
  farm loaded) are both unchanged from earlier versions - see below.
- Playtime and passive rewards (shards, etc): there's no separate feature
  needed for this - it's a direct result of the bot staying connected
  reliably. Every reconnect/retry mechanism in this codebase (exponential
  backoff, the indefinite "smp is offline" retry loop, the restart-grace
  delay, the anti-idle jiggle) exists specifically to maximize actual
  connected time, which is what playtime and per-minute rewards are based on
  server-side.

### Earlier versions

- Real ping via the sidebar scoreboard was tried and then removed in v1.4.0
  (see above) after it proved unreliable on this server.
- Exponential backoff with jitter for reconnects, plus a longer grace period
  after a "restarting"/"limbo" kick, since retrying immediately during a
  server restart just fails again anyway.
- **smp being offline is not a dead end**: if smp responds "currently
  offline" while the bot is connected and sitting in hub, it keeps resending
  the join command every `offlineRetryDelayMs` (15s default) - indefinitely,
  no cap - until it actually gets in.
- A minimum gap between join commands (avoids a "chatting too fast" kick),
  and pausing the anti-idle jiggle for a few seconds around a server-switch
  handoff (reduces the chance of racing the proxy's backend transfer, which
  can otherwise trigger a `BadPacketException` decoder error on some
  proxies).
- Knockback fixed via a direct raw-packet listener, since mineflayer's
  built-in handling of the server's own velocity packet for the bot's own
  entity is inconsistent across protocol versions.
- A no-op guard for unrecognized proxy `custom_payload` plugin messages, and
  try/catch guards around the `message`/`chat` packet listener bodies, so
  one bad/unexpected message can't take down the whole process.
- All server chat is stripped of legacy formatting codes (`§c`, `§l`, etc)
  and has repeated whitespace collapsed before any detection pattern runs -
  a colored/styled message can otherwise contain invisible control
  characters that break an exact-text match even though it looks fine to a
  human.
- Discord presence shows a live 🟢/🔴 + the server address, updating
  automatically on connection changes.
- `SMP_JOIN_COMMAND`, `SMP_ENABLED`, and `LOGIN_COMMAND` env vars let you
  override the join command, turn off hub→smp joining entirely, or send an
  in-game login-plugin command shortly after spawn - see `.env.example`.
  `!settings` shows the current effective values (never the login command's
  actual text, which may contain a password - only whether it's set).
- Dedicated `MENTIONS_CHANNEL_ID` for mentions/`/tell`/crate-key alerts,
  optional and falling back to `COMMAND_CHANNEL_ID`.
- All alert embeds carry a timestamp for an audit trail.

## Architecture (why it's built this way)

- **One process, not two.** Running the Discord bot and the Minecraft bot as
  separate processes would mean setting up IPC (a socket, a file, a queue) just so
  they can talk to each other, and paying for two Node runtimes in RAM. Instead,
  `src/index.js` starts both in the same process and they talk directly through
  function calls and a shared `state.js` + event emitter. This is the "sync"
  between them: Discord commands call straight into the Minecraft controller, and
  the Minecraft controller emits events (`log`, `joinedSmp`, `queue`, `offline`,
  `mention`, `tell`, `crateKey`) that the Discord side listens to and relays.
- **The Discord bot never goes down when the Minecraft bot does.** Minecraft
  connection errors are caught and turned into log lines / reconnect logic, not
  thrown - so a server restart or a bad kick on the MC side never kills your
  Discord connection. `!status` will happily tell you the MC bot is offline.
- **No pathfinding library.** Server-to-server travel on your network happens via
  proxy commands (`/joinqueue smp`, etc), not by physically walking, so
  `mineflayer-pathfinder` isn't included - one less (fairly heavy) dependency.
- **No native modules.** `.npmrc` skips optional native add-ons (`bufferutil`,
  `utf-8-validate`, `zlib-sync`) that `discord.js`/`ws` can use for a small speed
  boost. Skipping them means you don't need `build-essential`/`gcc` on the VPS at
  all, and there's nothing to fail to compile. The pure-JS fallbacks are plenty
  fast for a single-bot controller.

## What you get

```
mc-discord-controller/
├── config.js                  # tunable behavior (view distance, zones, regex, delays)
├── .env.example                # copy to .env - secrets, IDs, per-deployment overrides
├── package.json
├── .npmrc
├── deploy/
│   └── mc-controller.service  # systemd unit for always-on deployment
└── src/
    ├── index.js                # entry point / wiring / shutdown
    ├── discordBot.js           # commands, embeds, log relay
    ├── minecraftBot.js         # mineflayer connection, join/queue/kick logic
    ├── state.js                 # shared state both bots read/write
    ├── logger.js
    └── utils.js
```

## 1. Server prerequisites (do this once)

SSH into your VPS as a sudo-capable user.

```bash
sudo apt update && sudo apt upgrade -y
```

**Add swap.** A 750MB box has very little headroom - a 1GB swapfile is cheap
insurance against the OOM killer taking down the process during a GC spike or a
temporary memory blip, at the cost of some disk I/O if it's ever actually used:

```bash
sudo fallocate -l 1G /swapfile
sudo chmod 600 /swapfile
sudo mkswap /swapfile
sudo swapon /swapfile
echo '/swapfile none swap sw 0 0' | sudo tee -a /etc/fstab
```

**Install Node.js 20 LTS** (via NodeSource - avoids compiling anything):

```bash
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs
node -v   # should print v20.x
```

**Create a dedicated user** to run the bot (good practice, keeps it isolated):

```bash
sudo adduser --disabled-password --gecos "" mcbot
sudo su - mcbot
```

## 2. Get the files onto the VPS

Upload this whole folder to `/home/mcbot/mc-discord-controller` (via `scp`,
`rsync`, or `git clone` if you've pushed it to your own repo), then:

```bash
cd /home/mcbot/mc-discord-controller
npm install --omit=dev
```

This pulls in `discord.js`, `mineflayer`, and `dotenv` only (plus their required
sub-dependencies like `prismarine-auth` for Microsoft login). No `pathfinder`, no
viewer, no build tools required.

## 3. Create your Discord application

1. Go to https://discord.com/developers/applications → **New Application**.
2. **Bot** tab → **Add Bot**. Copy the token → this is your `DISCORD_TOKEN`.
3. Still on the **Bot** tab, scroll to **Privileged Gateway Intents** and enable
   **MESSAGE CONTENT INTENT**. This is required or the bot receives empty
   message content and every command silently fails to parse - it's the
   single most common "why isn't my bot responding" bug, so don't skip it.
4. **OAuth2 → URL Generator**: scope `bot`, permissions `Send Messages`,
   `Embed Links`, `Read Message History`, `Add Reactions`. Open the generated
   URL and invite the bot to your server.
5. In Discord, enable Developer Mode (User Settings → Advanced), then right
   click your target text channel → **Copy Channel ID** (`COMMAND_CHANNEL_ID`),
   and right click your own name → **Copy User ID** (`OWNER_ID`).

## 4. Configure

```bash
cp .env.example .env
nano .env
```

Fill in `DISCORD_TOKEN`, `OWNER_ID`, `COMMAND_CHANNEL_ID`, `MC_HOST`, `MC_PORT`,
`MC_EMAIL`. Leave `MC_VERSION` blank (auto-detect). `SMP_JOIN_COMMAND`,
`SMP_ENABLED`, and `LOGIN_COMMAND` are optional overrides - leave them blank
unless you need them (see the comments in `.env.example`).

Open `config.js` and, at minimum, fill in `zones` with your farm/spawn
coordinates if you want `!status` to show a friendly zone name instead of
just "Overworld".

## 5. First run (interactive - do this before installing the service)

The very first time you connect, Microsoft's device-code login flow needs to
happen, so run it in the foreground first where you can see the output:

```bash
npm start
```

Watch the console for a line like:

```
MICROSOFT LOGIN REQUIRED: To sign in, use a web browser to open the page
https://microsoft.com/link and enter the code ABCD-EFGH to authenticate.
```

(The same message is also relayed to your Discord log channel once the Discord
side is connected, in case you're not watching the terminal.) Open that URL on
**any** device, enter the code, and log in with the Microsoft account tied to
the Minecraft profile you want the bot to use. This only needs to happen once -
after a successful login, tokens are cached in `./mc-auth-cache/` and reused on
future starts (until they eventually expire, at which point you'll be asked to
repeat this step).

**`mc-auth-cache/` is sensitive** - treat it like a password file. It's already
excluded via `.gitignore`; don't upload it anywhere public.

Once you see `Discord bot logged in as ...` in the console, go to your
`COMMAND_CHANNEL_ID` channel in Discord and try `!status`. Press `Ctrl+C` to
stop the foreground run once you've confirmed it works.

## 6. Install as a systemd service (always-on)

`!restart` and automatic crash-recovery both depend on the process being
managed by systemd with `Restart=always` - this isn't optional if you want
those to work.

```bash
exit   # back to your sudo user, out of the mcbot shell
sudo cp /home/mcbot/mc-discord-controller/deploy/mc-controller.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now mc-controller
sudo systemctl status mc-controller
```

View logs any time with:

```bash
journalctl -u mc-controller -f
```

## Commands

`!start`, `!stop`, `!restart`, `!status`, and `!settings` only work in
`COMMAND_CHANNEL_ID`. `!cmd`, `!chat`, `!tell`, `!r`, and `!help` also work in
`MENTIONS_CHANNEL_ID` if set, so you can reply right from the channel where
you saw a mention or private message.

| Command | What it does |
|---|---|
| `!start` | Connects the Minecraft bot. Streams connect/join/queue logs to Discord. On success, posts a confirmation and automatically shows `!status`. |
| `!status` | Embed with in-game username, online/offline, ping, uptime, current backend server (hub/smp), world/zone, health, skin face, and RAM usage. |
| `!settings` | Shows the current effective connection settings (host/port, version, join command, whether smp-joining and the login command are set). |
| `!stop` | Disconnects the Minecraft bot cleanly so you can log in normally. |
| `!restart` | Stops everything and exits the process; systemd brings it back up. |
| `!cmd <command>` | Sends `/<command>` in-game (adds the leading `/` for you if you omit it) and replies with whatever the server sent back. E.g. `!cmd smp`, `!cmd balance`. |
| `!chat <message>` | Sends `<message>` as regular public in-game chat, as you. |
| `!tell <player> <message>` | Sends a private message to `player` in-game. |
| `!r <message>` | Replies to the last private message in-game, via the server's own `/r` command. |
| `!help` | Lists every command with a short description. |

## Channels

Besides `COMMAND_CHANNEL_ID`, two more channels are optional - each falls
back to `COMMAND_CHANNEL_ID` if left blank in `.env`:

- `LOG_CHANNEL_ID` - the batched technical log stream.
- `MENTIONS_CHANNEL_ID` - in-game mentions, `/tell`/`/msg`/`/w` alerts, and
  crate key alerts. Chat-facing commands also work here.

Bonus behavior (no command needed):
- If someone's message in-game contains your username, it's relayed as a
  plain `💬` message to `MENTIONS_CHANNEL_ID`.
- A `/tell`, `/msg`, or `/w` sent to you in-game is relayed as a titled
  `📩 Private Message` embed to `MENTIONS_CHANNEL_ID` - the compact
  `[player]->me : message` line plus separate Sender/Receiver fields. Kept
  visibly distinct from a plain mention on purpose, so the two are never
  confusable even scrolling quickly.
- A crate key you receive in-game is relayed as a `🔑 Crate Key Received`
  embed to `MENTIONS_CHANNEL_ID`, showing the key type where it can be
  extracted. Wording is plugin-dependent - see the tuning section below.
- If the bot gets bounced from smp back to the hub, it waits
  `kickToHubRetryDelayMs` and automatically resends the join command.
- If the bot gets fully disconnected from the network, it waits and
  reconnects with exponential backoff (see the changelog above), then
  repeats the hub→smp join sequence - up to `maxReconnectAttempts` before
  giving up and waiting for a manual `!start`.
- If smp itself comes back "currently offline" while the bot is still
  connected in hub, it keeps resending the join command every
  `offlineRetryDelayMs` (15s default) - **indefinitely, no cap** - until it
  actually gets in.

## Tuning the join/queue/offline/tell/crate-key detection (important)

Every network words its queue/offline/tell/reward messages differently, and
there's no way to know your specific SMP's exact wording in advance.
`config.js`'s `detection` block ships with generic patterns as a starting
point - you should verify (and likely tweak) them:

1. Set `DEBUG_RAW_CHAT=true` in `.env`.
2. Restart the bot and run `!start`, watching the Discord log channel.
3. Note the exact text your server sends for: being queued, smp being
   offline, what a private message looks like (have someone send you
   `/tell YourName hi` or `/msg`), and what a crate key message looks like.
4. Update `config.js` → `detection.queue` / `detection.offline` /
   `detection.tell` / `detection.crateKey` to match. `detection.tell`
   patterns need exactly two capture groups - `(sender name)` and
   `(message text)`. `detection.crateKey.keyType` needs exactly one capture
   group (the key's name/tier) and is optional - the alert still sends
   without it if nothing matches.
5. Set `DEBUG_RAW_CHAT=false` again once you're happy (it's noisy).

Note: `detection.joinedHub` / `detection.joinedSmp` do **not** need tuning -
they're only used for an extra confirmation line in the logs. Which server
you're actually on (shown in `!status`) is detected reliably via the game's
respawn event, not by guessing chat text.

## Real physics, knockback, and the farm

The bot uses mineflayer's default physics simulation (gravity, collision), plus
a direct fix for the server's velocity packet so it takes knockback like a real
client - nothing to configure there. The bot also never digs, places, or
interacts with blocks anywhere in this codebase; it only moves its camera
slightly for the anti-idle jiggle (position unchanged) and responds to
chat/commands. That's deliberate - it's the surest way to avoid ever disturbing
a farm or triggering a "bugged" state, since the bot simply never issues a
block-interaction packet in the first place.

`viewDistance: 3` in `config.js` keeps roughly a 7x7 chunk area loaded around
the bot - wide enough to keep a nearby farm loaded without asking the server
for more than necessary. Raise it if your farm is further out; lower it for
even less RAM.

## Memory tuning notes

- `npm start` runs with `--max-old-space-size=256`, capping the V8 heap so a
  leak or a big GC spike can't eat the whole box; the systemd unit sets a hard
  `MemoryMax=400M` as a second line of defense.
- Discord.js caches are capped (`makeCache` limits + a message sweeper) so
  memory doesn't creep up over days of uptime.
- Logs to Discord are batched (max one message per 2 seconds) instead of one
  API call per line, which also happens to keep CPU/network usage low.

## Ping

Since both the VPS and the SMP are in Singapore, you shouldn't need to do
anything special - the connection is already about as short as it can be. No
extra tuning was added here; if you ever move the VPS or the server, latency is
mostly a function of that distance, not this code.

## Troubleshooting

| Symptom | Likely cause |
|---|---|
| Bot doesn't respond to any command | `MESSAGE CONTENT INTENT` not enabled in the Developer Portal (step 3.3), or `COMMAND_CHANNEL_ID` is wrong. |
| `Missing required .env value(s)` on start | One of `DISCORD_TOKEN`, `OWNER_ID`, `COMMAND_CHANNEL_ID`, `MC_HOST`, `MC_EMAIL` is empty in `.env`. |
| Stuck asking for Microsoft login every restart | The `mc-auth-cache/` folder got deleted or isn't writable by the `mcbot` user - check `ls -la mc-auth-cache`. |
| `!start` connects but never detects smp/queue/offline | The detection patterns in `config.js` don't match your server's actual wording - see the tuning section above. |
| `!restart` stops the bot and it never comes back | You're not running it via the systemd service (`Restart=always`) - see step 6. |
| Process gets killed under memory pressure | Confirm the swapfile is active (`swapon --show`), and that `MemoryMax` in the service file isn't set below `--max-old-space-size`. |

## A quick note on server rules

AFK/macro bots are against the rules on some servers and fine on others - it's
worth double-checking your SMP's rules before running this long-term, since
that's between you and the server, not something this code can know for you.

## Security

- `.env` and `mc-auth-cache/` contain real credentials/tokens (including your
  in-game login command's password, if you set `LOGIN_COMMAND`) - never
  commit or share them.
- Only `OWNER_ID` (plus anyone listed in `ALLOWED_USER_IDS`) can run
  commands; everyone else gets an "unauthorized" reply.
- Consider restricting the command channel to a private channel only you can
  see, as a second layer on top of the ID check.
