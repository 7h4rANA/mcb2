// Non-secret behavior configuration. Secrets/IDs go in .env instead.
// This file is loaded with require(), so plain JS + comments are fine.

module.exports = {
  // Chunk view distance requested from the server, as a RADIUS (not diameter).
  // 3 => roughly a 7x7 chunk area around the bot, the closest standard value
  // to a "6x6" request (Minecraft view distance is always an odd-sized square
  // centered on the player: radius 2 = 5x5, radius 3 = 7x7, etc).
  // Lower = less RAM used to store loaded chunks. Raise only if you actually
  // need the bot to "see" further (e.g. for future pathfinding).
  viewDistance: 3,

  server: {
    // Command sent once the bot lands in the hub, to join your target server.
    joinCommand: '/smp',

    // How long to wait after spawning in the hub before sending joinCommand.
    hubWaitMs: 3000,

    // If the bot gets bounced from smp back to the hub, wait this long before
    // automatically retrying joinCommand.
    kickToHubRetryDelayMs: 8000,

    // If the bot gets fully disconnected from the whole network (not just
    // bounced to hub), wait this long before reconnecting from scratch.
    fullDisconnectRetryDelayMs: 10000,

    // Stop auto-reconnecting after this many consecutive failed attempts.
    // Use !start in Discord to try again manually after that.
    maxReconnectAttempts: 10,
  },

  // How long (ms) to collect the server's response lines after a !cmd before
  // replying in Discord with what was captured.
  cmdOutputCaptureMs: 5000,

  antiAfk: {
    enabled: true,
    // Small look-direction jiggle on this interval. Does NOT move the bot's
    // position, so it will not disturb a bonemeal/AFK farm - it only exists
    // to look "active" to anti-idle checks some servers run. Set
    // enabled: false if your farm spot doesn't need this.
    intervalMs: 60000,
  },

  // Optional named zones for the "World / Zone" field in !status, matched
  // against the bot's X/Z coordinates. First match wins; falls back to the
  // dimension name (Overworld/Nether/End) if nothing matches.
  // Fill these in with your own farm/spawn coordinates.
  zones: [
    // { name: 'AFK Farm', bounds: { x1: 100, z1: 200, x2: 120, z2: 220 } },
    // { name: 'Spawn',    bounds: { x1: -50,  z1: -50,  x2: 50,  z2: 50  } },
  ],

  // Regex patterns (case-insensitive) used to classify incoming server
  // messages while connecting/joining/handling kicks. Every network's
  // plugins word these differently, so these WILL need tuning to match
  // yours. Set DEBUG_RAW_CHAT=true in .env, watch the log channel/console
  // for the exact wording your server uses, then update the patterns below.
  detection: {
    queue: ['position\\s*\\d+', '\\bqueue\\b'],
    offline: ['currently offline', 'server.*offline', 'unable to connect'],
    joinedHub: ['joined.*hub', 'welcome.*hub'],
    joinedSmp: ['joined.*smp', 'welcome.*smp', 'teleport(ed|ing)?.*smp'],
  },
};
