const EventEmitter = require('events');

class State extends EventEmitter {
  constructor() {
    super();
    this.processStartedAt = Date.now();
    this.reset();
  }

  reset() {
    this.status = 'offline'; // offline | connecting | online
    this.currentServer = 'unknown'; // hub | smp | unknown
    this.username = null;
    this.connectedAt = null;
    this.reconnectAttempts = 0;
    this.lastKickReason = null;
    this.intentionalStop = false;
    this.alertsEnabled = true; // ghost-block alerts, toggled via /alerts
  }

  set(patch) {
    Object.assign(this, patch);
    this.emit('change', this);
  }
}

// Singleton - shared by minecraftBot.js and discordBot.js.
module.exports = new State();
