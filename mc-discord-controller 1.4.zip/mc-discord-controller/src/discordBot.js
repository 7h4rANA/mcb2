const {
  Client,
  GatewayIntentBits,
  EmbedBuilder,
  Options,
  ActivityType,
  SlashCommandBuilder,
  REST,
  Routes,
} = require('discord.js');
const logger = require('./logger');
const state = require('./state');
const { formatDuration, normalizeCommand, isAuthorized, getRamUsage } = require('./utils');

// Commands that only make sense from the main command channel (bot control).
const COMMAND_ONLY = new Set(['start', 'stop', 'restart', 'status', 'alerts']);
// Commands that talk to the game and are also allowed from the mentions/chat
// channel, so you can reply right where you saw a mention or /tell.
const CHAT_COMMANDS = new Set(['cmd', 'chat', 'tell', 'r']);

const SLASH_COMMANDS = [
  new SlashCommandBuilder().setName('start').setDescription('Connect the Minecraft bot'),
  new SlashCommandBuilder().setName('stop').setDescription('Disconnect the Minecraft bot'),
  new SlashCommandBuilder().setName('restart').setDescription('Restart everything (requires the systemd service)'),
  new SlashCommandBuilder().setName('status').setDescription('Show bot connection status'),
  new SlashCommandBuilder().setName('alerts').setDescription('Toggle ghost-block alerts on/off'),
  new SlashCommandBuilder()
    .setName('cmd')
    .setDescription('Run a raw in-game command')
    .addStringOption((o) => o.setName('command').setDescription("Command, e.g. 'smp' or '/home farm'").setRequired(true)),
  new SlashCommandBuilder()
    .setName('chat')
    .setDescription('Send a public chat message in-game')
    .addStringOption((o) => o.setName('message').setDescription('Message to send').setRequired(true)),
  new SlashCommandBuilder()
    .setName('tell')
    .setDescription('Send a private message to a player in-game')
    .addStringOption((o) => o.setName('player').setDescription('Player to message').setRequired(true))
    .addStringOption((o) => o.setName('message').setDescription('Message to send').setRequired(true)),
  new SlashCommandBuilder()
    .setName('r')
    .setDescription('Reply to the last private message in-game')
    .addStringOption((o) => o.setName('message').setDescription('Reply message').setRequired(true)),
].map((c) => c.toJSON());

function createDiscordClient(env, config, mc) {
  const client = new Client({
    // Slash commands need no privileged intents at all - unlike the old
    // prefix-command setup, there's no MESSAGE CONTENT INTENT toggle to
    // remember to enable in the Developer Portal.
    intents: [GatewayIntentBits.Guilds],
    // Cap caches so a long-running process on a small VPS doesn't slowly
    // grow its memory footprint over days/weeks.
    makeCache: Options.cacheWithLimits({
      MessageManager: 25,
      PresenceManager: 0,
      GuildMemberManager: 50,
      GuildStickerManager: 0,
      GuildEmojiManager: 0,
    }),
    sweepers: {
      messages: { interval: 300, lifetime: 600 },
    },
  });

  const ownerId = env.OWNER_ID;
  const allowedIds = (env.ALLOWED_USER_IDS || '')
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean);

  let cmdChannel = null;
  let logChannel = null;
  let mentionsChannel = null; // mentions + /tell,/msg,/w - falls back to cmdChannel if unset
  let alertsChannel = null; // ghost-block alerts only - falls back to cmdChannel if unset

  // ---- batched log relay: avoids hitting Discord rate limits by sending
  // at most one message every 2s instead of one per log line. ----
  let logBuffer = [];
  async function flushLogs() {
    if (!logBuffer.length || !logChannel) return;
    let text = logBuffer.join('\n');
    logBuffer = [];
    if (text.length > 1900) text = text.slice(text.length - 1900);
    try {
      await logChannel.send('```\n' + text + '\n```');
    } catch (err) {
      console.error('Failed to send log batch to Discord:', err.message);
    }
  }
  setInterval(flushLogs, 2000);

  logger.setRelay((line) => logBuffer.push(line));
  mc.on('log', (line) => logBuffer.push(line));

  // Presence: "🟢/🔴 host:port" instead of a static "Playing ...", refreshed
  // every time the Minecraft connection state changes.
  function updatePresence() {
    if (!client.user) return;
    const emoji = state.status === 'online' ? '🟢' : '🔴';
    const port = Number(env.MC_PORT) || 25565;
    const address = port !== 25565 ? `${env.MC_HOST}:${port}` : env.MC_HOST;
    client.user.setPresence({
      status: 'online', // the Discord bot itself always shows online
      activities: [{ name: `${emoji} ${address}`, type: ActivityType.Playing }],
    });
  }
  state.on('change', updatePresence);

  async function registerSlashCommands() {
    const rest = new REST({ version: '10' }).setToken(env.DISCORD_TOKEN);
    const appId = client.user.id;
    try {
      if (env.GUILD_ID) {
        await rest.put(Routes.applicationGuildCommands(appId, env.GUILD_ID), { body: SLASH_COMMANDS });
        console.log('Slash commands registered (guild scope - available immediately).');
      } else {
        await rest.put(Routes.applicationCommands(appId), { body: SLASH_COMMANDS });
        console.log('Slash commands registered (global scope - can take up to an hour to appear everywhere).');
      }
    } catch (err) {
      console.error('Failed to register slash commands:', err.message);
    }
  }

  client.once('ready', async () => {
    console.log(`Discord bot logged in as ${client.user.tag}`);
    cmdChannel = await client.channels.fetch(env.COMMAND_CHANNEL_ID).catch(() => null);
    if (!cmdChannel) {
      console.error(
        `Could not fetch COMMAND_CHANNEL_ID (${env.COMMAND_CHANNEL_ID}). Check the ID and that the bot has access to that channel.`
      );
    }
    logChannel = env.LOG_CHANNEL_ID
      ? await client.channels.fetch(env.LOG_CHANNEL_ID).catch(() => cmdChannel)
      : cmdChannel;
    mentionsChannel = env.MENTIONS_CHANNEL_ID
      ? await client.channels.fetch(env.MENTIONS_CHANNEL_ID).catch(() => cmdChannel)
      : cmdChannel;
    alertsChannel = env.ALERTS_CHANNEL_ID
      ? await client.channels.fetch(env.ALERTS_CHANNEL_ID).catch(() => cmdChannel)
      : cmdChannel;

    if (!env.MENTIONS_CHANNEL_ID) {
      console.log('MENTIONS_CHANNEL_ID not set - mentions and /tell alerts will use the command channel instead.');
    }
    if (!env.ALERTS_CHANNEL_ID) {
      console.log('ALERTS_CHANNEL_ID not set - ghost block alerts will use the command channel instead.');
    }

    await registerSlashCommands();
    updatePresence();
  });

  function alertsEmbed() {
    return new EmbedBuilder()
      .setColor(state.alertsEnabled ? 0x57f287 : 0xed4245)
      .setTitle('Ghost Block Alerts')
      .setDescription(`Status: ${state.alertsEnabled ? '🟢 ENABLED' : '🔴 DISABLED'}`);
  }

  async function buildStatusEmbed() {
    const data = mc.getStatusData();
    const ram = getRamUsage();
    const ramField = {
      name: 'RAM',
      value: `Process: ${ram.processRssMb} MB\nVPS: ${ram.usedMb} MB / ${ram.totalMb} MB`,
      inline: true,
    };
    const embed = new EmbedBuilder().setColor(data.online ? 0x57f287 : 0xed4245);

    if (!data.online) {
      embed.setTitle('Minecraft Bot Status').setDescription('Offline').addFields(ramField).setTimestamp();
      return embed;
    }

    embed
      .setTitle(data.username)
      .setThumbnail(`https://mc-heads.net/avatar/${encodeURIComponent(data.username)}/100`)
      .addFields(
        { name: 'Status', value: 'Online', inline: true },
        { name: 'Ping', value: `${data.ping} ms`, inline: true },
        { name: 'Uptime', value: formatDuration(data.uptimeMs), inline: true },
        { name: 'Server', value: data.server, inline: true },
        { name: 'World / Zone', value: data.zone, inline: true },
        { name: 'Health', value: `${Math.round(data.health ?? 0)} / 20`, inline: true },
        ramField
      )
      .setTimestamp();
    return embed;
  }

  client.on('interactionCreate', async (interaction) => {
    if (!interaction.isChatInputCommand()) return;
    const name = interaction.commandName;

    const inCommandChannel = !env.COMMAND_CHANNEL_ID || interaction.channelId === env.COMMAND_CHANNEL_ID;
    const allowedChatChannelIds = [env.COMMAND_CHANNEL_ID, env.MENTIONS_CHANNEL_ID].filter(Boolean);
    const inChatChannel = !allowedChatChannelIds.length || allowedChatChannelIds.includes(interaction.channelId);

    if (COMMAND_ONLY.has(name) && !inCommandChannel) {
      await interaction.reply({ content: 'This command can only be used in the command channel.', ephemeral: true });
      return;
    }
    if (CHAT_COMMANDS.has(name) && !inChatChannel) {
      await interaction.reply({
        content: 'This command can only be used in the command or chat channel.',
        ephemeral: true,
      });
      return;
    }

    if (!isAuthorized(interaction.user.id, ownerId, allowedIds)) {
      await interaction.reply({ content: 'You are not authorized to use this bot.', ephemeral: true });
      return;
    }

    try {
      switch (name) {
        case 'start': {
          if (mc.isRunning()) {
            await interaction.reply('Already running.');
            break;
          }
          await interaction.reply('Starting Minecraft bot...');
          await mc.start();
          break;
        }

        case 'stop': {
          await interaction.reply('Stopping Minecraft bot...');
          await mc.stop();
          break;
        }

        case 'restart': {
          await interaction.reply(
            'Restarting everything. This requires the systemd service (Restart=always) to bring it back up - see README.'
          );
          await mc.stop();
          setTimeout(() => process.exit(0), 1000);
          break;
        }

        case 'status': {
          const embed = await buildStatusEmbed();
          await interaction.reply({ embeds: [embed] });
          break;
        }

        case 'alerts': {
          state.set({ alertsEnabled: !state.alertsEnabled });
          await interaction.reply({ embeds: [alertsEmbed()] });
          break;
        }

        case 'cmd': {
          const raw = interaction.options.getString('command', true);
          const normalized = normalizeCommand(raw);
          // sendCommand waits up to cmdOutputCaptureMs (~5s default) to
          // collect the server's response, which exceeds Discord's 3s
          // interaction window - defer first, then edit once it resolves.
          await interaction.deferReply();
          const lines = await mc.sendCommand(normalized);
          const out = lines.length ? lines.slice(0, 15).join('\n') : '(no output captured)';
          await interaction.editReply(`Sent \`${normalized}\`. Output:\n\`\`\`\n${out.slice(0, 1800)}\n\`\`\``);
          break;
        }

        case 'chat': {
          const message = interaction.options.getString('message', true);
          mc.sendChat(message);
          await interaction.reply(`Sent: ${message}`);
          break;
        }

        case 'tell': {
          const player = interaction.options.getString('player', true);
          const message = interaction.options.getString('message', true);
          mc.sendChat(`/tell ${player} ${message}`);
          await interaction.reply(`Told ${player}: ${message}`);
          break;
        }

        case 'r': {
          // Forwarded as the server's own /r command rather than tracked
          // client-side, so "last person who messaged you" always matches
          // whatever the server itself considers the last conversation.
          const message = interaction.options.getString('message', true);
          mc.sendChat(`/r ${message}`);
          await interaction.reply(`Replied: ${message}`);
          break;
        }

        default:
          await interaction.reply({ content: 'Unknown command.', ephemeral: true });
      }
    } catch (err) {
      const content = `Error: ${err.message}`;
      if (interaction.deferred || interaction.replied) {
        await interaction.editReply(content).catch(() => {});
      } else {
        await interaction.reply({ content, ephemeral: true }).catch(() => {});
      }
    }
  });

  // ---- events pushed from the Minecraft bot into Discord ----

  mc.on('joinedSmp', async () => {
    if (!cmdChannel) return;
    await cmdChannel.send('Successfully joined the SMP!').catch(() => {});
    const embed = await buildStatusEmbed();
    cmdChannel.send({ embeds: [embed] }).catch(() => {});
  });

  mc.on('offline', (text) => {
    if (!cmdChannel) return;
    const embed = new EmbedBuilder().setColor(0xed4245).setTitle('SMP appears offline').setDescription(text).setTimestamp();
    cmdChannel.send({ embeds: [embed] }).catch(() => {});
  });

  mc.on('queue', (text) => {
    if (!cmdChannel) return;
    const embed = new EmbedBuilder().setColor(0x5865f2).setTitle('Queue update').setDescription(text).setTimestamp();
    cmdChannel.send({ embeds: [embed] }).catch(() => {});
  });

  // In-game mentions - plain text only, no embed.
  mc.on('mention', (text) => {
    if (!mentionsChannel) return;
    mentionsChannel.send(`Mentioned in game: ${text}`).catch(() => {});
  });

  // /tell, /msg, /w (private message) sent to you in-game - Rich Embed with
  // Sender/Receiver fields, alongside the compact "[sender]->me : message"
  // description line.
  mc.on('tell', ({ from, message }) => {
    if (!mentionsChannel) return;
    const embed = new EmbedBuilder()
      .setColor(0x9b59b6)
      .setDescription(`[${from}]->me : ${message}`)
      .addFields(
        { name: 'Sender', value: from, inline: true },
        { name: 'Receiver', value: mc.getStatusData().username || 'You', inline: true }
      )
      .setTimestamp();
    mentionsChannel.send({ embeds: [embed] }).catch(() => {});
  });

  // Ghost-block alert. Only sent while alerts are toggled on (/alerts), and
  // only to the dedicated alerts channel - nothing else gets routed there.
  mc.on('ghostBlock', ({ player, world, coords, offset, raw }) => {
    if (!state.alertsEnabled || !alertsChannel) return;
    const embed = new EmbedBuilder().setColor(0xe67e22).setTitle('Ghost Block Alert').setDescription(raw).setTimestamp();

    const fields = [];
    if (world) fields.push({ name: 'World', value: world, inline: true });
    fields.push({
      name: 'Coordinates',
      value: coords ? `\`${coords.x}, ${coords.y}, ${coords.z}\`` : 'Not available',
      inline: true,
    });
    if (offset) fields.push({ name: 'Offset', value: offset, inline: true });
    embed.addFields(fields);

    if (player) {
      // Player's name as a clickable embed author - name + skin-face icon
      // link straight to a lookup page.
      embed.setAuthor({
        name: player,
        iconURL: `https://mc-heads.net/avatar/${encodeURIComponent(player)}/32`,
        url: `https://namemc.com/profile/${encodeURIComponent(player)}`,
      });
    } else {
      embed.setAuthor({ name: 'Unknown player' });
    }

    alertsChannel.send({ embeds: [embed] }).catch(() => {});
  });

  return client;
}

module.exports = { createDiscordClient };
