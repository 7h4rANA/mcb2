require('dotenv').config();
const MinecraftController = require('./minecraftBot');
const { createDiscordClient } = require('./discordBot');
const { version } = require('../package.json');

const env = process.env;
const config = require('../config');

console.log(`Mc-Controller v${version} starting...`);

const required = ['DISCORD_TOKEN', 'OWNER_ID', 'COMMAND_CHANNEL_ID', 'MC_HOST', 'MC_EMAIL'];
const missing = required.filter((key) => !env[key]);
if (missing.length) {
  console.error(`Missing required .env value(s): ${missing.join(', ')}`);
  console.error('Copy .env.example to .env and fill it in before starting.');
  process.exit(1);
}

const mc = new MinecraftController(env, config);
const client = createDiscordClient(env, config, mc);

client.login(env.DISCORD_TOKEN).catch((err) => {
  console.error('Failed to log in to Discord - check DISCORD_TOKEN in .env.', err.message);
  process.exit(1);
});

let shuttingDown = false;
async function shutdown(signal) {
  if (shuttingDown) return;
  shuttingDown = true;
  console.log(`Received ${signal}, shutting down...`);
  try {
    await mc.stop();
  } catch {
    // ignore - exiting anyway
  }
  try {
    client.destroy();
  } catch {
    // ignore
  }
  process.exit(0);
}

process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));

// Log but don't crash on unexpected errors - the goal is "always online".
// The systemd unit's Restart=always is the real safety net if something
// does eventually take the process down.
process.on('unhandledRejection', (err) => console.error('Unhandled rejection:', err));
process.on('uncaughtException', (err) => console.error('Uncaught exception:', err));
