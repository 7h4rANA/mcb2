# Minecraft AFK Bot + Discord Controller

A single Node.js process that runs a Minecraft bot (Microsoft account login, real
player physics) and a Discord bot side by side in the same process, so they stay
perfectly in sync with no IPC/sockets/extra RAM overhead. Built to run comfortably
on a 750MB Ubuntu VPS.

## Changelog

### v1.3.1 (cont.) - reconnect coverage

- **Fixed: smp being offline used to be a dead end.** Getting bounced
  smp→hub, a full network disconnect, and a server restart were all already
  auto-retried - but if smp itself came back with "currently offline" while
  the bot was still connected and sitting in hub, it would alert once and
  then just sit there, since nothing scheduled another attempt. It now
  retries the join command indefinitely on `server.offlineRetryDelayMs`
  (15s default) until it actually gets in - no cap, matching "keep trying
  until I'm in smp." Verified with a timed simulation: two consecutive
  "offline" responses each triggered exactly one retry, and the loop
  correctly stopped the instant smp was reached with no extra attempts
  after.

### v1.3.1 - major update

- **Fixed: ghost-block alerts not showing up.** The root cause was almost
  certainly legacy Minecraft formatting codes (`§c`, `§l`, etc) embedded in a
  styled/colored alert message - they don't affect how the message looks to
  a human, but left in, they silently break an exact-text regex match. All
  server chat is now stripped of formatting codes and has repeated
  whitespace collapsed *before* any detection pattern runs (see
  `minecraftBot.js` -> `_stripFormatting`). Verified with a test that fed the
  exact same message through both clean and color-code-polluted, and
  confirmed both extract identically now.
- **Ghost-block detection rewritten around the real, precise format:**
  `ANTI CHEAT » PlayerName's position was updated for being on a ghost
  block! (world, x, y, z) [offset]` - now also extracts the **world name**
  and the **offset** value, shown as their own embed fields.
- **Scope narrowed to ghost-block only, on purpose.** General anti-cheat
  violation alerts (Scaffold, Speed, Reach, etc) and the `!allalerts` toggle
  from the previous version have been **removed** - this build only tracks
  ghost-block/desync events, matching a narrower admin-tooling scope.
- **All commands converted from `!prefix` text commands to native Discord
  slash commands** (`/start`, `/stop`, `/restart`, `/status`, `/alerts`,
  `/cmd`, `/chat`, `/tell`, `/r`). See the Commands section below. A real
  side benefit: slash commands need **no privileged intents at all**, so the
  "enable MESSAGE CONTENT INTENT" step from earlier versions is gone
  entirely - one less manual setup step to forget.
- **New: `/tell` command** sends a private message in-game, and **new:
  `/r`** replies to the last private message using the server's own `/r`
  command (not tracked client-side, so it always matches whatever the
  server itself considers the last conversation).
- **New `GUILD_ID` env var** for instant (guild-scoped) slash command
  registration instead of waiting up to an hour for global registration.
- **Defensive hardening per the spec:** a no-op guard for unrecognized proxy
  "custom_payload" plugin messages, and try/catch guards around the
  `message`/`chat` packet listener bodies so one bad/unexpected message
  can't take down the whole process.
- **Scoreboard ping extraction** now also matches a region-label format like
  `Asia (74ms)`, alongside the existing `ping: 42`/`latency: 42` patterns.
- **Corrected a technical claim from the spec this version was built from:**
  hardcoding `version: '1.21.1'` does **not** fix the
  `BadPacketException`/decoder error - that exception happens on the
  server's own BungeeCord decoder during a backend handoff race, which is a
  server-side issue a client-side version string can't fix (and was already
  mitigated separately - see the transfer-window pause note below). You can
  still set `MC_VERSION=1.21.1` in `.env` if you want to pin it for other
  reasons; auto-detect (blank) remains the safer default.

### Earlier versions

- Real ping via the sidebar scoreboard when the tab list shows a placeholder
  (0ms), read on-demand with no polling/listener - zero added RAM.
- Exponential backoff with jitter for reconnects, plus a longer grace period
  specifically after a "restarting"/"limbo" kick, since retrying immediately
  during a server restart just fails again anyway.
- A minimum gap between join commands (avoids a "chatting too fast" kick),
  and pausing the anti-idle jiggle for a few seconds around a server-switch
  handoff (reduces the chance of racing the proxy's backend transfer, which
  is the likely trigger for the `BadPacketException` decoder error above).
- Knockback fixed via a direct raw-packet listener, since mineflayer's
  built-in handling of the server's own velocity packet for the bot's own
  entity is inconsistent across protocol versions.
- Discord presence shows a live 🟢/🔴 + the server address instead of a
  static "Playing ..." line, updating automatically on connection changes.
- Dedicated `MENTIONS_CHANNEL_ID` (mentions + /tell) and `ALERTS_CHANNEL_ID`
  (ghost-block only) channels, each optional and falling back to
  `COMMAND_CHANNEL_ID`.
- All alert embeds carry a timestamp for an audit trail.

## Architecture (why it's built this way)

- **One process, not two.** Running the Discord bot and the Minecraft bot as
  separate processes would mean setting up IPC (a socket, a file, a queue) just so
  they can talk to each other, and paying for two Node runtimes in RAM. Instead,
  `src/index.js` starts both in the same process and they talk directly through
  function calls and a shared `state.js` + event emitter. This is the "sync"
  between them: Discord commands call straight into the Minecraft controller, and
  the Minecraft controller emits events (`log`, `joinedSmp`, `queue`, `offline`,
  `mention`) that the Discord side listens to and relays.
- **The Discord bot never goes down when the Minecraft bot does.** Minecraft
  connection errors are caught and turned into log lines / reconnect logic, not
  thrown - so a server restart or a bad kick on the MC side never kills your
  Discord connection. `/status` will happily tell you the MC bot is offline.
- **No pathfinding library.** Server-to-server travel on your network happens via
  proxy commands (`/smp`, `/hub-01`, ...), not by physically walking, so
  `mineflayer-pathfinder` isn't included - one less (fairly heavy) dependency.
- **No native modules.** `.npmrc` skips optional native add-ons (`bufferutil`,
  `utf-8-validate`, `zlib-sync`) that `discord.js`/`ws` can use for a small speed
  boost. Skipping them means you don't need `build-essential`/`gcc` on the VPS at
  all, and there's nothing to fail to compile. The pure-JS fallbacks are plenty
  fast for a single-bot controller.

## What you get

```
mc-discord-controller/
├── config.js                  # tunable behavior (view distance, zones, regex, delays)
├── .env.example                # copy to .env - secrets & IDs
├── package.json
├── .npmrc
├── deploy/
│   └── mc-controller.service  # systemd unit for always-on deployment
└── src/
    ├── index.js                # entry point / wiring / shutdown
    ├── discordBot.js           # commands, status embed, log relay
    ├── minecraftBot.js         # mineflayer connection, join/queue/kick logic
    ├── state.js                 # shared state both bots read/write
    ├── logger.js
    └── utils.js
```

## 1. Server prerequisites (do this once)

SSH into your VPS as a sudo-capable user.

```bash
sudo apt update && sudo apt upgrade -y
```

**Add swap.** A 750MB box has very little headroom - a 1GB swapfile is cheap
insurance against the OOM killer taking down the process during a GC spike or a
temporary memory blip, at the cost of some disk I/O if it's ever actually used:

```bash
sudo fallocate -l 1G /swapfile
sudo chmod 600 /swapfile
sudo mkswap /swapfile
sudo swapon /swapfile
echo '/swapfile none swap sw 0 0' | sudo tee -a /etc/fstab
```

**Install Node.js 20 LTS** (via NodeSource - avoids compiling anything):

```bash
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs
node -v   # should print v20.x
```

**Create a dedicated user** to run the bot (good practice, keeps it isolated):

```bash
sudo adduser --disabled-password --gecos "" mcbot
sudo su - mcbot
```

## 2. Get the files onto the VPS

Upload this whole folder to `/home/mcbot/mc-discord-controller` (via `scp`,
`rsync`, or `git clone` if you've pushed it to your own repo), then:

```bash
cd /home/mcbot/mc-discord-controller
npm install --omit=dev
```

This pulls in `discord.js`, `mineflayer`, and `dotenv` only (plus their required
sub-dependencies like `prismarine-auth` for Microsoft login). No `pathfinder`, no
viewer, no build tools required.

## 3. Create your Discord application

1. Go to https://discord.com/developers/applications → **New Application**.
2. **Bot** tab → **Add Bot**. Copy the token → this is your `DISCORD_TOKEN`.
   No privileged intents need enabling - slash commands don't require any of
   the toggles on that page.
3. **OAuth2 → URL Generator**: scopes `bot` **and** `applications.commands`
   (both are required - the second is what lets slash commands register at
   all), permissions `Send Messages`, `Embed Links`, `Read Message History`,
   `Add Reactions`. Open the generated URL and invite the bot to your server.
4. In Discord, enable Developer Mode (User Settings → Advanced), then right
   click your target text channel → **Copy Channel ID** (`COMMAND_CHANNEL_ID`),
   right click your own name → **Copy User ID** (`OWNER_ID`), and right click
   your server icon → **Copy Server ID** (`GUILD_ID`, recommended - without
   it, slash commands register globally and can take up to an hour to show
   up in the `/` menu).

## 4. Configure

```bash
cp .env.example .env
nano .env
```

Fill in `DISCORD_TOKEN`, `OWNER_ID`, `GUILD_ID`, `COMMAND_CHANNEL_ID`,
`MC_HOST`, `MC_PORT`, `MC_EMAIL`. Leave `MC_VERSION` blank (auto-detect).

Open `config.js` and, at minimum, set `server.joinCommand` if your SMP isn't
literally `/joinqueue smp`, and fill in `zones` with your farm/spawn
coordinates if you want `/status` to show a friendly zone name instead of
just "Overworld".

## 5. First run (interactive - do this before installing the service)

The very first time you connect, Microsoft's device-code login flow needs to
happen, so run it in the foreground first where you can see the output:

```bash
npm start
```

Watch the console for a line like:

```
MICROSOFT LOGIN REQUIRED: To sign in, use a web browser to open the page
https://microsoft.com/link and enter the code ABCD-EFGH to authenticate.
```

(The same message is also relayed to your Discord log channel once the Discord
side is connected, in case you're not watching the terminal.) Open that URL on
**any** device, enter the code, and log in with the Microsoft account tied to
the Minecraft profile you want the bot to use. This only needs to happen once -
after a successful login, tokens are cached in `./mc-auth-cache/` and reused on
future starts (until they eventually expire, at which point you'll be asked to
repeat this step).

**`mc-auth-cache/` is sensitive** - treat it like a password file. It's already
excluded via `.gitignore`; don't upload it anywhere public.

Once you see `Discord bot logged in as ...` and `Slash commands registered`
in the console, go to your `COMMAND_CHANNEL_ID` channel in Discord and try
`/status` - it should appear in the `/` autocomplete menu. Press `Ctrl+C` to
stop the foreground run once you've confirmed it works.

## 6. Install as a systemd service (always-on)

`/restart` and automatic crash-recovery both depend on the process being
managed by systemd with `Restart=always` - this isn't optional if you want
those to work.

```bash
exit   # back to your sudo user, out of the mcbot shell
sudo cp /home/mcbot/mc-discord-controller/deploy/mc-controller.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now mc-controller
sudo systemctl status mc-controller
```

View logs any time with:

```bash
journalctl -u mc-controller -f
```

## Commands

`/start`, `/stop`, `/restart`, `/status`, and `/alerts` only work in
`COMMAND_CHANNEL_ID`. `/cmd`, `/chat`, `/tell`, and `/r` also work in
`MENTIONS_CHANNEL_ID` if set, so you can reply right from the channel where
you saw a mention or private message. None of them work in
`ALERTS_CHANNEL_ID`, which is output-only.

| Command | What it does |
|---|---|
| `/start` | Connects the Minecraft bot. Streams connect/join/queue logs to Discord. On success, posts a confirmation and automatically shows `/status`. |
| `/status` | Embed with in-game username, online/offline, ping (see note below), uptime, current backend server (hub/smp), world/zone, health, skin face, and RAM usage. |
| `/stop` | Disconnects the Minecraft bot cleanly so you can log in normally. |
| `/restart` | Stops everything and exits the process; systemd brings it back up. |
| `/cmd command:<text>` | Sends `/<command>` in-game (adds the leading `/` for you if you omit it) and replies with whatever the server sent back. E.g. `/cmd command:smp`, `/cmd command:balance`. |
| `/chat message:<text>` | Sends `<message>` as regular public in-game chat, as you. |
| `/tell player:<name> message:<text>` | Sends a private message to `player` in-game. |
| `/r message:<text>` | Replies to the last private message in-game, via the server's own `/r` command. |
| `/alerts` | Toggles ghost-block alerts on/off (default **ON**). Replies with a Rich Embed showing `🟢 ENABLED`/`🔴 DISABLED`. |

## Channels

Besides `COMMAND_CHANNEL_ID`, three more channels are optional - each falls
back to `COMMAND_CHANNEL_ID` if left blank in `.env`:

- `LOG_CHANNEL_ID` - the batched technical log stream.
- `MENTIONS_CHANNEL_ID` - in-game mentions (plain text) and `/tell`/`/msg`/`/w`
  alerts (embed). Chat-facing commands also work here.
- `ALERTS_CHANNEL_ID` - ghost-block alerts **only**. Nothing else is ever
  routed here. General anti-cheat violation logs (Scaffold, Speed, Reach,
  etc) are intentionally not tracked at all by this bot.

Bonus behavior (no command needed):
- If someone's message in-game contains your username, it's relayed as a
  plain message to `MENTIONS_CHANNEL_ID`.
- A `/tell`, `/msg`, or `/w` sent to you in-game is relayed as an embed to
  `MENTIONS_CHANNEL_ID` - the compact `[player]->me : message` line plus
  separate Sender/Receiver fields.
- A detected ghost-block alert is relayed as an embed - player name as a
  clickable link with their skin-face icon, world, coordinates, offset, the
  full raw message, and a timestamp - to `ALERTS_CHANNEL_ID`, as long as
  `/alerts` is ON. The default pattern matches this server's real format:
  `ANTI CHEAT » PlayerName's position was updated for being on a ghost
  block! (world, x, y, z) [offset]`; adjust in `config.js` →
  `detection.ghostBlock` if yours differs. The message is stripped of
  legacy formatting codes (`§c`, `§l`, etc) before matching, since those can
  silently break an exact-text match even in a message that looks fine to a
  human - this was the fix for alerts not showing up at all.
- Ghost-block alerts are throttled to one per player every `cooldownMs` (10s
  default) even if the anti-cheat fires repeatedly.
- If the bot gets bounced from smp back to the hub, it waits
  `kickToHubRetryDelayMs` and automatically resends the join command.
- If the bot gets fully disconnected from the network, it waits and
  reconnects with exponential backoff (see the changelog above), then
  repeats the hub→smp join sequence - up to `maxReconnectAttempts` before
  giving up and waiting for a manual `/start`.
- If smp itself comes back "currently offline" while the bot is still
  connected in hub, it keeps resending the join command every
  `offlineRetryDelayMs` (15s default) - **indefinitely, no cap** - until it
  actually gets in.

**Ping note:** if your server places a placeholder (e.g. 0ms) in the tab
list, `/status` automatically falls back to reading the real ping from the
sidebar scoreboard instead (see `config.js` → `detection.pingScoreboard`).

## Tuning the join/queue/offline/tell/ghost-block detection (important)

Every network words its queue/offline/tell/anti-cheat messages differently,
and there's no way to know your specific SMP's exact wording in advance.
`config.js`'s `detection` block ships with generic patterns as a starting
point - you should verify (and likely tweak) them:

1. Set `DEBUG_RAW_CHAT=true` in `.env`.
2. Restart the bot and run `/start`, watching the Discord log channel.
3. Note the exact text your server sends for: being queued, smp being
   offline, what a private message looks like (have someone send you
   `/tell YourName hi` or `/msg`), and - if you can trigger a test detection
   safely - what a Vulcan ghost-block/setback alert looks like.
4. Update `config.js` → `detection.queue` / `detection.offline` /
   `detection.tell` / `detection.ghostBlock` to match. `detection.tell`
   patterns need exactly two capture groups - `(sender name)` and
   `(message text)`. `detection.ghostBlock.player` needs one capture group
   (the player's name); `detection.ghostBlock.coords` needs three, in
   `x, y, z` order - either can be left unmatched and the alert still sends
   with whatever was found (falling back to "Unknown"/"Not available").
5. Set `DEBUG_RAW_CHAT=false` again once you're happy (it's noisy).

Note: `detection.joinedHub` / `detection.joinedSmp` do **not** need tuning -
they're only used for an extra confirmation line in the logs. Which server
you're actually on (shown in `/status`) is detected reliably via the game's
respawn event, not by guessing chat text - see the changelog above.

## Real physics, knockback, and the farm

The bot uses mineflayer's default physics simulation (gravity, collision, and
server-authoritative velocity packets), so it takes knockback and falls/collides
like a real client - nothing extra to configure there. The bot also never digs,
places, or interacts with blocks anywhere in this codebase; it only moves its
camera slightly for the anti-idle jiggle (position unchanged) and responds to
chat/commands. That's deliberate - it's the surest way to avoid ever disturbing
a bonemeal farm or triggering a "bugged" state, since the bot simply never
issues a block-interaction packet in the first place.

## Memory tuning notes

- `npm start` runs with `--max-old-space-size=256`, capping the V8 heap so a
  leak or a big GC spike can't eat the whole box; the systemd unit sets a hard
  `MemoryMax=400M` as a second line of defense.
- `viewDistance: 3` in `config.js` keeps mineflayer's chunk cache small
  (~7x7 chunks, the closest fit to "6x6" - view distance in Minecraft is a
  radius, so it's always an odd-numbered square). Raise it if you need the bot
  to see further; lower it for even less RAM.
- Discord.js caches are capped (`makeCache` limits + a message sweeper) so
  memory doesn't creep up over days of uptime.
- Logs to Discord are batched (max one message per 2 seconds) instead of one
  API call per line, which also happens to keep CPU/network usage low.

## Ping

Since both the VPS and the SMP are in Singapore, you shouldn't need to do
anything special - the connection is already about as short as it can be. No
extra tuning was added here; if you ever move the VPS or the server, latency is
mostly a function of that distance, not this code.

## Troubleshooting

| Symptom | Likely cause |
|---|---|
| Slash commands don't show up in the `/` menu | `applications.commands` OAuth scope wasn't included when inviting the bot (step 3.3), or `GUILD_ID` is wrong/unset (global registration can take up to an hour). |
| Bot doesn't respond to a command it does show | `COMMAND_CHANNEL_ID`/`MENTIONS_CHANNEL_ID` is wrong, or you're not in `ALLOWED_USER_IDS`/`OWNER_ID`. |
| `Missing required .env value(s)` on start | One of `DISCORD_TOKEN`, `OWNER_ID`, `COMMAND_CHANNEL_ID`, `MC_HOST`, `MC_EMAIL` is empty in `.env`. |
| Stuck asking for Microsoft login every restart | The `mc-auth-cache/` folder got deleted or isn't writable by the `mcbot` user - check `ls -la mc-auth-cache`. |
| `/start` connects but never detects smp/queue/offline | The detection patterns in `config.js` don't match your server's actual wording - see the tuning section above. |
| `/restart` stops the bot and it never comes back | You're not running it via the systemd service (`Restart=always`) - see step 6. |
| Process gets killed under memory pressure | Confirm the swapfile is active (`swapon --show`), and that `MemoryMax` in the service file isn't set below `--max-old-space-size`. |

## A quick note on server rules

AFK/macro bots are against the rules on some servers and fine on others - it's
worth double-checking your SMP's rules before running this long-term, since
that's between you and the server, not something this code can know for you.

## Security

- `.env` and `mc-auth-cache/` contain real credentials/tokens - never commit or
  share them.
- Only `OWNER_ID` (plus anyone listed in `ALLOWED_USER_IDS`) can run commands;
  everyone else gets an "unauthorized" reply.
- Consider restricting the command channel to a private channel only you can
  see, as a second layer on top of the ID check.
