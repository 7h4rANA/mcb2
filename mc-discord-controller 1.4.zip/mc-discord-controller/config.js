// Non-secret behavior configuration. Secrets/IDs go in .env instead.
// This file is loaded with require(), so plain JS + comments are fine.

module.exports = {
  // Chunk view distance requested from the server, as a RADIUS (not diameter).
  // 3 => roughly a 7x7 chunk area around the bot, the closest standard value
  // to a "6x6" request (Minecraft view distance is always an odd-sized square
  // centered on the player: radius 2 = 5x5, radius 3 = 7x7, etc).
  // Lower = less RAM used to store loaded chunks. Raise only if you actually
  // need the bot to "see" further (e.g. for future pathfinding).
  viewDistance: 3,

  server: {
    // Command sent once the bot lands in the hub, to join your target server.
    joinCommand: '/joinqueue smp',

    // How long to wait after spawning in the hub before sending joinCommand.
    hubWaitMs: 10000,

    // If the bot gets bounced from smp back to the hub, wait this long before
    // automatically retrying joinCommand.
    kickToHubRetryDelayMs: 10000,

    // If the bot gets fully disconnected from the whole network (not just
    // bounced to hub), this is the BASE delay before the first reconnect
    // attempt. Later attempts back off from here - see reconnectBackoffFactor.
    fullDisconnectRetryDelayMs: 10000,

    // Each reconnect attempt's delay is multiplied by this factor (capped at
    // maxReconnectDelayMs), with +/-15% random jitter applied on top. This
    // spreads retries out during a server restart instead of hammering it on
    // a perfectly fixed interval - which is both friendlier to the server and
    // less likely to trip an anti-bot "limbo"/rate check that flags rapid,
    // mechanically-regular reconnects.
    reconnectBackoffFactor: 1.5,
    maxReconnectDelayMs: 60000,

    // Stop auto-reconnecting after this many consecutive failed attempts.
    // Use !start in Discord to try again manually after that. With the
    // backoff above, 15 attempts covers several minutes of retrying, enough
    // for most server restarts.
    maxReconnectAttempts: 15,

    // When a disconnect reason matches detection.restarting (below), the
    // server just told us it's mid-restart - reconnecting immediately just
    // hits ECONNREFUSED or an anti-bot "limbo check" kick, since the backend
    // genuinely isn't ready yet. In that specific case we wait this much
    // longer before even starting the normal backoff sequence, instead of
    // burning through fast attempts against a server we already know isn't up.
    restartGraceMs: 45000,

    // While smp is confirmed offline (a chat message matched
    // detection.offline), the bot resends joinCommand on this interval,
    // indefinitely, until it actually gets in - it never just gives up and
    // sits in hub. Unlike maxReconnectAttempts (which caps full network
    // reconnects), there's no cap here on purpose.
    offlineRetryDelayMs: 15000,
  },

  // How long (ms) to collect the server's response lines after a !cmd before
  // replying in Discord with what was captured.
  cmdOutputCaptureMs: 5000,

  antiAfk: {
    enabled: true,
    // Small look-direction jiggle on this interval. Does NOT move the bot's
    // position, so it will not disturb a bonemeal/AFK farm - it only exists
    // to look "active" to anti-idle checks some servers run. Set
    // enabled: false if your farm spot doesn't need this.
    intervalMs: 60000,
  },

  // Optional named zones for the "World / Zone" field in !status, matched
  // against the bot's X/Z coordinates. First match wins; falls back to the
  // dimension name (Overworld/Nether/End) if nothing matches.
  // Fill these in with your own farm/spawn coordinates.
  zones: [
    // { name: 'AFK Farm', bounds: { x1: 100, z1: 200, x2: 120, z2: 220 } },
    // { name: 'Spawn',    bounds: { x1: -50,  z1: -50,  x2: 50,  z2: 50  } },
  ],

  // Regex patterns (case-insensitive) used to classify incoming server
  // messages while connecting/joining/handling kicks. Every network's
  // plugins word these differently, so these WILL need tuning to match
  // yours. Set DEBUG_RAW_CHAT=true in .env, watch the log channel/console
  // for the exact wording your server uses, then update the patterns below.
  //
  // NOTE: joinedHub/joinedSmp here are only used for an extra confirmation
  // line in the logs. The bot's actual "which server am I on" state (shown
  // in !status) is no longer decided by guessing chat text - it's driven by
  // the game's respawn event, which fires every time the proxy switches you
  // to a different backend server. That's reliable on any network/proxy
  // (Velocity, BungeeCord, Flamecord, etc) without needing to know its exact
  // wording, which is what was causing !status to get stuck showing "hub".
  detection: {
    queue: ['position\\s*\\d+', '\\bqueue\\b'],
    offline: ['currently offline', 'server.*offline', 'unable to connect'],
    joinedHub: ['joined.*hub', 'welcome.*hub'],
    joinedSmp: ['joined.*smp', 'welcome.*smp', 'teleport(ed|ing)?.*smp'],

    // Matches a disconnect/kick reason that means "the server is restarting,
    // not actually rejecting you" (including anti-bot "limbo check" kicks
    // that tend to happen during a restart window). When matched, the bot
    // waits server.restartGraceMs before its first retry instead of jumping
    // straight into the normal backoff sequence.
    restarting: ['restarting', 'limbo'],

    // Patterns for detecting an in-game /tell or /msg (private message) sent
    // to you, so it can be relayed to Discord. Each pattern needs exactly two
    // capture groups: (sender name) and (message text). Wording for this
    // varies a lot by server/plugin - verify with DEBUG_RAW_CHAT and add your
    // server's actual format if none of these match.
    tell: [
      '^\\[(.+?)\\s*->\\s*(?:me|you)\\]\\s*(.+)$', // [Name -> you] message
      '^(.+?)\\s+whispers(?: to you)?:\\s*(.+)$', // Name whispers to you: message
      '^(.+?)\\s*->\\s*(?:me|you):\\s*(.+)$', // Name -> you: message
    ],

    // Patterns to pull a numeric ping out of the sidebar scoreboard, used as
    // a fallback when the tab list shows a placeholder (e.g. always 0ms).
    // Needs exactly one capture group: the number itself. The
    // "(\d+)\s*ms\)" pattern matches a region-label format like
    // "Asia (74ms)"; the others are generic fallbacks.
    pingScoreboard: ['\\((\\d+)\\s*ms\\)', 'ping[:\\s]+(\\d+)', 'latency[:\\s]+(\\d+)'],

    // "Ghost block" anti-cheat position-correction alerts, relayed to a
    // dedicated alerts channel, controlled by !alerts. Scope is
    // deliberately narrow: only this specific alert type is tracked -
    // general anti-cheat violation logs (Scaffold, Speed, Reach, etc) are
    // intentionally NOT parsed or relayed by this bot.
    //
    // All chat text is stripped of legacy formatting codes (§0-9a-fk-or) and
    // has repeated whitespace collapsed before any of these patterns run
    // (see minecraftBot.js -> _stripFormatting) - a colored/styled alert
    // message can otherwise contain invisible control characters that break
    // an exact-text match even though the message reads fine to a human.
    ghostBlock: {
      // Any message matching one of these is treated as a ghost-block alert
      // worth relaying. Just needs to match - no capture groups required.
      // First pattern is this server's actual observed format:
      // "ANTI CHEAT » PlayerName's position was updated for being on a
      // ghost block! (world, x, y, z) [offset]"; the rest are fallbacks for
      // older/other formats.
      trigger: [
        'ANTI CHEAT\\s*»?\\s*.*position was updated for being on a ghost block',
        'position was updated for being on a ghost block',
        'ghost\\s*block',
      ],

      // Extracts the flagged player's name. Needs exactly one capture group.
      // [\w.*] covers word characters plus dots/asterisks, since some
      // servers show partially-censored or dotted names.
      player: [
        "ANTI CHEAT\\s*»?\\s*([\\w.*]+)'s position was updated for being on a ghost block",
        "^(.+?)'s position was updated for being on a ghost block",
        'vulcan\\]?\\s*(\\w+)',
        'anti[\\s-]*cheat\\]?\\s*(\\w+)',
        '(\\w+)\\s+(?:has been|was)\\s+(?:setback|reset)',
      ],

      // Extracts the world name from "(world, x, y, z)". Needs exactly one
      // capture group. Optional - the alert still sends without a world
      // field if this doesn't match.
      world: ['\\(([^,]+),\\s*-?\\d+,\\s*-?\\d+,\\s*-?\\d+\\)'],

      // Extracts coordinates. Needs exactly three capture groups, in x, y, z
      // order. First pattern matches this server's "(world, x, y, z)"
      // format; the rest are fallbacks for older/other formats. If none
      // match, the bot falls back to the flagged player's currently-tracked
      // position if it happens to have one (i.e. that player is within the
      // bot's loaded area).
      coords: [
        '\\((?:[^,]+),\\s*(-?\\d+),\\s*(-?\\d+),\\s*(-?\\d+)\\)',
        'x:\\s*(-?\\d+)\\s*y:\\s*(-?\\d+)\\s*z:\\s*(-?\\d+)',
        'x[:=]?\\s*(-?\\d+(?:\\.\\d+)?)[,\\s]+y[:=]?\\s*(-?\\d+(?:\\.\\d+)?)[,\\s]+z[:=]?\\s*(-?\\d+(?:\\.\\d+)?)',
      ],

      // Extracts the trailing "[offset]" value, e.g. the ping-offset number
      // some anti-cheats report alongside a position correction. Needs
      // exactly one capture group. Optional - purely cosmetic if missing.
      offset: ['\\)\\s*\\[(\\d+)\\]'],

      // Minimum time between alerts for the SAME player, so a repeatedly
      // firing anti-cheat doesn't flood the alerts channel / hit a Discord
      // rate limit. Alerts for different players are never suppressed.
      cooldownMs: 10000,
    },
  },
};
