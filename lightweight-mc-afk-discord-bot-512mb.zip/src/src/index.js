require('dotenv').config({ quiet: true });

const fs = require('node:fs');
const path = require('node:path');
const mineflayer = require('mineflayer');
const { Client, GatewayIntentBits, ActivityType, Options } = require('discord.js');

const ROOT = path.resolve(__dirname, '..');
const AUTH_DIR = path.join(ROOT, 'auth-cache');
const LOG_DIR = path.join(ROOT, 'logs');
const RUNTIME_FILE = path.join(ROOT, 'config.runtime.json');
fs.mkdirSync(AUTH_DIR, { recursive: true, mode: 0o700 });
fs.mkdirSync(LOG_DIR, { recursive: true, mode: 0o700 });

const env = (k, d='') => process.env[k] || d;
const int = (k, d) => Number.isFinite(Number.parseInt(env(k, String(d)),10)) ? Number.parseInt(env(k, String(d)),10) : d;
const list = k => env(k).split(',').map(x=>x.trim()).filter(Boolean);

const config = {
  mc: {
    host: env('MC_HOST'), port: int('MC_PORT',25565), version: env('MC_VERSION','1.21.11'),
    email: env('MC_EMAIL'), viewDistance: Math.min(3, Math.max(2,int('VIEW_DISTANCE',3))),
    hubCommand: env('HUB_COMMAND','/smp'), hubWaitMs: int('HUB_WAIT_MS',4500), smpReadyTimeoutMs: int('SMP_READY_TIMEOUT_MS',30000)
  },
  discord: {
    token: env('DISCORD_TOKEN'), owners: new Set(list('OWNER_USER_IDS')),
    log: env('LOG_CHANNEL_ID'), chat: env('CHAT_CHANNEL_ID'), report: env('REPORT_CHANNEL_ID')
  },
  reconnect: { min: int('RECONNECT_MIN_MS',7000), max: int('RECONNECT_MAX_MS',60000), maxHour: int('MAX_RECONNECTS_PER_HOUR',20) },
  alertCooldown: int('CHAT_ALERT_COOLDOWN_MS',1500), commandWait: int('COMMAND_OUTPUT_MS',3500),
  reportHour: int('DAILY_REPORT_HOUR',23), reportMinute: int('DAILY_REPORT_MINUTE',59), maxChars: int('LOG_MAX_CHARS',1500),
  smpPatterns: list('SMP_SUCCESS_PATTERNS'), hubPatterns: list('HUB_SUCCESS_PATTERNS')
};

if (!config.mc.host || !config.mc.email || !config.discord.token || !config.discord.log || !config.discord.chat || !config.discord.report || !config.discord.owners.size) {
  console.error('Missing required .env values.'); process.exit(1);
}

if (fs.existsSync(RUNTIME_FILE)) {
  try {
    const r = JSON.parse(fs.readFileSync(RUNTIME_FILE,'utf8'));
    if (Number.isFinite(r.viewDistance)) config.mc.viewDistance = Math.min(3,Math.max(2,r.viewDistance));
    for (const k of ['hubWaitMs','smpReadyTimeoutMs','alertCooldown','commandWait','maxChars']) if (Number.isFinite(r[k])) config[k] = r[k];
  } catch {}
}

const stats = { started:Date.now(), connected:0, reconnects:0, kicks:0, errors:0, chats:0, commands:0, lastKick:'', lastError:'', lastEvent:'boot' };
let bot = null, stopping = false, reconnectTimer = null, reconnectDelay = config.reconnect.min;
let reconnectWindow = Date.now(), reconnectsHour = 0, hubTimer = null, smpTimer = null, smpRequested = false, smpConfirmed = false;
let lastAlert = 0, collector = null;
const channels = { log:null, chat:null, report:null };

// Aggressively cap Discord.js caches. We only need live message events and three channels.
const discord = new Client({
  intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent],
  makeCache: Options.cacheWithLimits({
    MessageManager: 0, PresenceManager: 0, ReactionManager: 0, GuildMemberManager: 0,
    UserManager: 50, ThreadManager: 0, ThreadMemberManager: 0, VoiceStateManager: 0, StageInstanceManager: 0
  }),
  sweepers: { messages: { interval: 300, lifetime: 60 } }
});

const clean = v => { try { if (typeof v === 'string') return v; if (v?.text) return v.text; return String(v ?? ''); } catch { return ''; } };
const trim = s => String(s ?? '').slice(0, config.maxChars);
const fmtUptime = ms => { let s=Math.floor(ms/1000); const d=Math.floor(s/86400); s%=86400; const h=Math.floor(s/3600); s%=3600; const m=Math.floor(s/60); return `${d}d ${h}h ${m}m ${s%60}s`; };

async function send(kind, content, opts={}) {
  const ch = channels[kind];
  if (!ch?.isTextBased()) return false;
  try { await ch.send({ content, ...opts, allowedMentions:{parse:[]} }); return true; } catch(e) { console.error(`Discord ${kind}:`,e.message); return false; }
}
async function log(msg, level='INFO') {
  const line=`[${new Date().toISOString()}] [${level}] ${msg}`; console.log(line);
  try { fs.appendFileSync(path.join(LOG_DIR,'bot.log'),line+'\n'); } catch {}
  return send('log',`[${level}] ${trim(msg)}`);
}
function presence(online) {
  if (!discord.user) return;
  discord.user.setPresence({ status: online?'online':'idle', activities:[{name:`${online?'🟢':'🔴'} ${config.mc.host}`,type:ActivityType.Playing}] });
}
function messageMatches(text, patterns) { const l=text.toLowerCase(); return patterns.some(p=>l.includes(p.toLowerCase())); }
function privateMsg(text) { return /(?:^|\s)(?:\/?tell|\/?msg|\/?w|whisper)(?:\s|:)/i.test(text) || /(?:whispers to you|-> you|to you:)/i.test(text); }

function saveRuntime() {
  fs.writeFileSync(RUNTIME_FILE, JSON.stringify({ viewDistance:config.mc.viewDistance, hubWaitMs:config.mc.hubWaitMs, smpReadyTimeoutMs:config.mc.smpReadyTimeoutMs, alertCooldown:config.alertCooldown, commandWait:config.commandWait, maxChars:config.maxChars },null,2));
}
function clearTimers() { if(hubTimer)clearTimeout(hubTimer); if(smpTimer)clearTimeout(smpTimer); hubTimer=smpTimer=null; if(collector){clearTimeout(collector.timer);collector=null;} }
function resetReconnectWindow(){ if(Date.now()-reconnectWindow>=3600000){reconnectWindow=Date.now();reconnectsHour=0;} }
function scheduleReconnect(reason) {
  if(stopping||reconnectTimer)return; resetReconnectWindow();
  if(reconnectsHour>=config.reconnect.maxHour){ log(`Reconnect limit reached. Reason: ${reason}`,'WARN'); return; }
  const delay=Math.min(config.reconnect.max, reconnectDelay+Math.floor(Math.random()*1500)); reconnectsHour++; stats.reconnects++;
  log(`Reconnect scheduled in ${delay}ms: ${reason}`,'WARN');
  reconnectTimer=setTimeout(()=>{ reconnectTimer=null; connectMinecraft(); },delay);
  reconnectDelay=Math.min(config.reconnect.max,Math.floor(reconnectDelay*1.7));
}
function destroyMinecraft() {
  clearTimers();
  const old=bot; bot=null; stats.connected=0; presence(false);
  if(old){ try{ old.quit('controller stop'); }catch{} }
}
function scheduleSmp() {
  if(!bot||stopping||smpRequested)return; smpRequested=true;
  hubTimer=setTimeout(()=>{
    if(!bot||stopping)return;
    try { bot.chat(config.mc.hubCommand.startsWith('/')?config.mc.hubCommand:`/${config.mc.hubCommand}`); stats.commands++; stats.lastEvent='smp-command-sent'; log(`Sent ${config.mc.hubCommand}`); }
    catch(e){ stats.errors++; stats.lastError=e.message; log(`SMP command failed: ${e.message}`,'ERROR'); return; }
    smpTimer=setTimeout(()=>{ if(!smpConfirmed)log(`SMP not confirmed after ${config.mc.smpReadyTimeoutMs}ms`,'WARN'); },config.mc.smpReadyTimeoutMs);
  },config.mc.hubWaitMs);
}
function confirmSmp(src){ if(smpRequested&&!smpConfirmed){smpConfirmed=true;if(smpTimer)clearTimeout(smpTimer);smpTimer=null;log(`SMP ready (${src})`); } }
function onMcMessage(msg) {
  const text=clean(msg); if(!text)return;
  if(collector) collector.lines.push(text);
  if(!smpRequested && messageMatches(text,config.hubPatterns)) scheduleSmp();
  if(smpRequested && messageMatches(text,config.smpPatterns)) confirmSmp('message');
  const name=bot?.username||''; if(name&&(text.toLowerCase().includes(name.toLowerCase())||privateMsg(text))){
    const now=Date.now(); if(now-lastAlert>=config.alertCooldown){lastAlert=now; send('chat',`🚨 ${trim(text)}`);}
  }
}

function connectMinecraft() {
  if(stopping||bot)return; clearTimers(); smpRequested=false; smpConfirmed=false; stats.lastEvent='connecting'; presence(false);
  log(`Connecting ${config.mc.host}:${config.mc.port}`);
  try {
    bot=mineflayer.createBot({ host:config.mc.host, port:config.mc.port, username:config.mc.email, auth:'microsoft', profilesFolder:AUTH_DIR,
      version:config.mc.version, viewDistance:config.mc.viewDistance, physicsEnabled:true, hideErrors:true, checkTimeoutInterval:30000 });
    bot.once('login',()=>{stats.lastEvent='login';log(`Minecraft login as ${bot.username||'unknown'}`);});
    bot.once('spawn',()=>{
      stats.connected=Date.now(); stats.lastEvent='spawn'; reconnectDelay=config.reconnect.min; presence(true);
      log(`Spawned as ${bot.username||'unknown'}`); scheduleSmp();
    });
    bot.on('respawn',()=>{stats.lastEvent='respawn'; if(smpRequested)confirmSmp('respawn');});
    bot.on('message',onMcMessage);
    bot.on('chat',(username,message)=>{
      if(username===bot.username)return; stats.chats++; send('chat',`💬 <${username}> ${trim(message)}`);
      if(bot.username&&message.toLowerCase().includes(bot.username.toLowerCase())){const now=Date.now();if(now-lastAlert>=config.alertCooldown){lastAlert=now;send('chat',`🔔 <${username}> mentioned ${bot.username}: ${trim(message)}`);}}
    });
    // Telemetry only. Mineflayer's normal physics remains enabled for server velocity/knockback.
    bot._client.on('set_entity_velocity',p=>{if(bot?.entity&&p?.entityId===bot.entity.id)stats.lastEvent=`velocity ${p.velocityX},${p.velocityY},${p.velocityZ}`;});
    bot.once('kicked',reason=>{stats.kicks++;stats.lastKick=clean(reason);stats.connected=0;stats.lastEvent='kicked';presence(false);log(`Kicked: ${trim(stats.lastKick)}`,'WARN');if(!stopping)scheduleReconnect('kick');});
    bot.once('error',e=>{stats.errors++;stats.lastError=e?.message||String(e);stats.lastEvent='error';log(`Minecraft error: ${trim(stats.lastError)}`,'ERROR');});
    bot.once('end',reason=>{stats.connected=0;stats.lastEvent='end';presence(false);log(`Connection ended: ${trim(reason||'unknown')}`,'WARN');bot=null;if(!stopping)scheduleReconnect('end');});
  } catch(e){stats.errors++;stats.lastError=e.message;bot=null;log(`createBot failed: ${e.message}`,'ERROR');scheduleReconnect('createBot');}
}
function statusText(){const online=!!bot&&!!stats.connected;const mem=process.memoryUsage();const pos=bot?.entity?.position?.floored?.().toString()||'n/a';return [
  `**Minecraft:** ${online?'🟢 ONLINE':'🔴 OFFLINE'}`,`**Account:** ${bot?.username||config.mc.email}`,`**Server:** \`${config.mc.host}:${config.mc.port}\``,
  `**View distance:** ${config.mc.viewDistance} (7x7 target)`,`**Uptime:** ${fmtUptime(Date.now()-stats.started)}`,`**MC session:** ${online?fmtUptime(Date.now()-stats.connected):'offline'}`,
  `**Position:** ${pos}`,`**Reconnects:** ${stats.reconnects}`,`**Kicks:** ${stats.kicks}`,`**Errors:** ${stats.errors}`,`**Chat:** ${stats.chats}`,`**Commands:** ${stats.commands}`,`**RSS:** ${(mem.rss/1048576).toFixed(1)} MB`,`**Heap:** ${(mem.heapUsed/1048576).toFixed(1)} MB`,`**Last:** ${stats.lastEvent}`,
  stats.lastKick?`**Last kick:** ${trim(stats.lastKick)}`:'',stats.lastError?`**Last error:** ${trim(stats.lastError)}`:''
].filter(Boolean).join('\n');}
async function dailyReport(){const mem=process.memoryUsage();await send('report',`📊 **Daily performance**\n${statusText()}\n**Node:** ${process.version} | **RSS:** ${(mem.rss/1048576).toFixed(1)} MB | **Heap:** ${(mem.heapUsed/1048576).toFixed(1)} MB`);}
function scheduleReport(){const tick=()=>{const n=new Date(),t=new Date(n);t.setHours(config.reportHour,config.reportMinute,0,0);if(t<=n)t.setDate(t.getDate()+1);setTimeout(async()=>{await dailyReport();tick();},Math.max(1000,t-n));};tick();}

const runtimeKeys=['viewDistance','hubWaitMs','smpReadyTimeoutMs','alertCooldown','commandWait','maxChars'];
function setRuntime(k,v){if(!runtimeKeys.includes(k))return `Allowed: ${runtimeKeys.join(', ')}`;const n=Number(v);if(!Number.isFinite(n))return 'Value must be numeric.';
  if(k==='viewDistance')config.mc.viewDistance=Math.min(3,Math.max(2,n)); else if(k==='hubWaitMs')config.mc.hubWaitMs=Math.min(30000,Math.max(1000,n)); else if(k==='smpReadyTimeoutMs')config.mc.smpReadyTimeoutMs=Math.min(120000,Math.max(5000,n)); else if(k==='alertCooldown')config.alertCooldown=Math.min(30000,Math.max(250,n)); else if(k==='commandWait')config.commandWait=Math.min(15000,Math.max(1000,n)); else config.maxChars=Math.min(1800,Math.max(500,n)); saveRuntime(); return `Set ${k}=${n}.`;
}
async function discordCommand(m){if(m.author.bot||!m.content.startsWith('!'))return;if(!config.discord.owners.has(m.author.id))return m.reply('❌ Not authorized.');const a=m.content.trim().split(/\s+/),cmd=a.shift().slice(1).toLowerCase(),rest=a.join(' ');
  if(cmd==='help')return m.reply('`!start` `!stop` `!status` `!chat <text>` `!cmd <command>` `!config [key value]`');
  if(cmd==='start'){if(bot)return m.reply('🟡 Already connected/connecting.');stopping=false;reconnectDelay=config.reconnect.min;connectMinecraft();return m.reply('🟢 Start requested.');}
  if(cmd==='stop'){stopping=true;if(reconnectTimer){clearTimeout(reconnectTimer);reconnectTimer=null;}destroyMinecraft();return m.reply('🔴 Stopped. You can log in.');}
  if(cmd==='status')return m.reply(statusText());
  if(cmd==='chat'){if(!bot)return m.reply('❌ Minecraft is offline.');if(!rest)return m.reply('Usage: !chat <message>');if(rest.length>256)return m.reply('❌ Max 256 chars.');try{bot.chat(rest);stats.commands++;return m.reply('💬 Sent.');}catch(e){return m.reply(`❌ ${e.message}`);}}
  if(cmd==='cmd'){if(!bot)return m.reply('❌ Minecraft is offline.');if(!rest)return m.reply('Usage: !cmd <command>');if(rest.length>240)return m.reply('❌ Command too long.');if(collector)return m.reply('⏳ Another command is collecting output.');const c=rest.startsWith('/')?rest.slice(1):rest;collector={lines:[],timer:null};try{bot.chat('/'+c);stats.commands++;collector.timer=setTimeout(()=>{const lines=collector?.lines||[];collector=null;send('log',`🧾 **/${c}**\n\`\`\`\n${trim(lines.join('\n')||'(no output captured)')}\n\`\`\``);},config.commandWait);return m.reply('⚙️ Command sent; output is in logs.');}catch(e){collector=null;return m.reply(`❌ ${e.message}`);}}
  if(cmd==='config'){if(!a.length)return m.reply(`viewDistance=${config.mc.viewDistance}\nhubWaitMs=${config.mc.hubWaitMs}\nsmpReadyTimeoutMs=${config.mc.smpReadyTimeoutMs}\nalertCooldown=${config.alertCooldown}\ncommandWait=${config.commandWait}\nmaxChars=${config.maxChars}`);if(a.length<2)return m.reply('Usage: !config <key> <number>');return m.reply(setRuntime(a[0],a[1]));}
}

discord.once('ready',async()=>{console.log(`Discord ready as ${discord.user.tag}`);for(const [k,id] of Object.entries({log:config.discord.log,chat:config.discord.chat,report:config.discord.report})){try{channels[k]=await discord.channels.fetch(id);}catch(e){console.error(`Channel ${k}:`,e.message);}}presence(false);scheduleReport();await log(`Controller online; MC=${config.mc.host}:${config.mc.port}; heap cap should be set by service.`);stopping=false;connectMinecraft();});
discord.on('messageCreate',m=>discordCommand(m).catch(e=>console.error('Discord command:',e.message)));
discord.on('error',e=>console.error('Discord:',e.message));
process.on('unhandledRejection',e=>{stats.errors++;stats.lastError=e?.message||String(e);console.error('Unhandled rejection:',e);});
process.on('uncaughtException',e=>{stats.errors++;stats.lastError=e?.message||String(e);console.error('Uncaught exception:',e);});
async function shutdown(sig){if(stopping)return;stopping=true;if(reconnectTimer)clearTimeout(reconnectTimer);destroyMinecraft();try{await discord.destroy();}catch{}process.exit(0);}
process.on('SIGINT',()=>shutdown('SIGINT'));process.on('SIGTERM',()=>shutdown('SIGTERM'));
discord.login(config.discord.token).catch(e=>{console.error('Discord login failed:',e.message);process.exit(1);});
