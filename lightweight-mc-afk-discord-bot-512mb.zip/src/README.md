# Ultra-Light Minecraft AFK + Discord Controller v2

Designed for a **512 MB / 1 vCPU Linux VPS** running one Microsoft-authenticated Minecraft Java account. The goal is to keep the bot itself small while retaining normal Minecraft physics and a 3-chunk client view distance (7x7 target).

## What changed for 512 MB

- Discord.js cache limits are aggressively reduced; messages, reactions, members, presence, voice states and threads are not retained.
- The three Discord channels are fetched once instead of repeatedly resolving channel IDs.
- No Discord embeds, HTTP dashboard, database, browser, viewer, pathfinder, PvP or anti-AFK loop.
- Only one Minecraft client is created at a time.
- Reconnects use exponential backoff and a per-hour cap so a broken proxy cannot create a reconnect storm.
- Event listeners that only need to happen once (`login`, `spawn`, `kicked`, `error`, `end`) use one-shot listeners.
- Local logging is tiny and only one file is used.
- Runtime config is a small JSON file.
- The systemd example caps V8 heap at 160 MB and adds a service memory guard.

## Important: 512 MB is tight

A 512 MB VPS means the **entire machine/container** needs RAM for the OS, SSH, systemd, Node/V8, Discord connection, Mineflayer, protocol buffers and Minecraft chunk data. `--max-old-space-size=160` is deliberately conservative, but it is not an absolute RSS cap.

If your provider/container has **no swap and a very small RAM limit**, Mineflayer can still be killed when the Minecraft world/chunk state grows. For this reason, use a minimal Linux image and no other services on the VPS.

Do not run a Minecraft server on the same 512 MB VPS.

## 7x7 chunks

`VIEW_DISTANCE=3` requests a 3-chunk radius, i.e. a **7x7 target area (49 chunks)**. The actual streamed area is also constrained by the server/proxy's view distance and chunk sending behavior.

Do not increase it on a 512 MB / 1 vCPU VPS.

## Install

Recommended Node.js: **Node 24 LTS**.

```bash
sudo apt update
sudo apt install -y ca-certificates curl unzip
node -v
npm -v
mkdir -p ~/mc-bot
cd ~/mc-bot
unzip lightweight-mc-afk-discord-bot.zip
npm ci --omit=dev
cp .env.example .env
nano .env
chmod 600 .env
chmod 700 auth-cache logs
```

## Discord

Create a Discord application/bot and enable **Message Content Intent**. Give it only:

- View Channels
- Send Messages
- Embed Links (not actually required by v2, but harmless)
- Read Message History

Put the bot token, your Discord user ID, and the three channel IDs in `.env`.

No webhooks are used.

## Microsoft authentication

Put the Microsoft email in `MC_EMAIL`. Do not put the Microsoft password in `.env`.

On the first run, Mineflayer's Microsoft device-code flow will ask you to authenticate. The token cache is stored in `auth-cache/` and should never be shared.

## Proxy

Set `MC_HOST` and `MC_PORT` to the same public address players use through **FlameCord/Papyrus**. Do not expose or use a backend Paper server address if the proxy is the intended entry point.

The bot uses normal Minecraft protocol behavior. There is no special DDoS-bypass or proxy manipulation code.

## Start manually first

Do this before systemd:

```bash
cd ~/mc-bot
NODE_OPTIONS='--max-old-space-size=160' UV_THREADPOOL_SIZE=1 npm start
```

Complete Microsoft login. Watch memory in another SSH session:

```bash
ps -o pid,rss,vsz,cmd -C node
free -h
```

If this works and stays comfortably below your VPS limit, install systemd.

## 24/7 systemd

Copy `mc-bot.service.example` to `/etc/systemd/system/mc-bot.service`, replace `YOUR_LINUX_USER`, then:

```bash
sudo systemctl daemon-reload
sudo systemctl enable --now mc-bot
journalctl -u mc-bot -f
```

The service automatically restarts after a process crash. It does **not** add any artificial Minecraft movement.

## Discord commands

```text
!start
!stop
!status
!chat hello
!cmd balance
!config
!config viewDistance 3
```

Only IDs in `OWNER_USER_IDS` can use these commands.

`!stop` intentionally disconnects the Minecraft account so you can log in yourself. It also disables automatic reconnect until `!start` is used.

## Hub -> SMP

After the first Minecraft spawn, the bot waits `HUB_WAIT_MS` and sends `/smp`.

It considers the transfer confirmed when a configured SMP phrase appears or the proxy/server sends a post-transfer respawn event.

If your network uses different messages, change `SMP_SUCCESS_PATTERNS` and `HUB_SUCCESS_PATTERNS` in `.env` and restart.

## Chat and alerts

Normal Minecraft chat is forwarded to `CHAT_CHANNEL_ID`.

Messages containing the bot's username and private-message formats such as `/tell`, `/msg`, `/w`, `whisper`, `-> you` and `to you:` are highlighted. Alerts are cooldown-limited so chat spam does not create a Discord API flood.

## Knockback

`physicsEnabled=true` remains enabled. The bot does not inject movement or anti-AFK behavior. Server velocity packets are allowed to go through Mineflayer's normal physics implementation.

For Minecraft 1.21.11, test knockback on your exact server before depending on it for a farm; Mineflayer has had upstream 1.21.11 physics reports.

## Why this is safer on 512 MB

Do not install any of these into the same Node project:

- prismarine-viewer
- mineflayer-pathfinder
- mineflayer-pvp
- puppeteer / Chromium
- Express dashboard
- SQLite/Redis
- extra Minecraft bots
- large Discord logging/cache plugins

Also do not run npm development tools, compilers or multiple Node processes on the VPS.

## Optional swap

If your VPS provider permits swap, a small **512 MB to 1 GB swapfile** can prevent a transient allocation from immediately killing Node. Swap is a safety net, not extra performance; Minecraft networking should remain in RAM.

Example on a normal Ubuntu/Debian VPS:

```bash
sudo fallocate -l 512M /swapfile
sudo chmod 600 /swapfile
sudo mkswap /swapfile
sudo swapon /swapfile
free -h
```

Check your provider's terms first. Some containers/VPS products do not permit guest swap.

## If the VPS still crashes

Run:

```bash
free -h
journalctl -k --no-pager | tail -100
journalctl -u mc-bot --no-pager | tail -200
```

If you see `Out of memory`, `oom-kill`, `Killed process node`, or a provider memory-limit event, the VPS is exhausting its total memory rather than simply having a JavaScript exception.

At that point the reliable choices are:

1. Add permitted swap.
2. Move to 768 MB/1 GB RAM.
3. Reduce Minecraft view distance below 3 (but that breaks the requested 7x7 target).
4. Remove other services from the VPS.

## Performance philosophy

This version intentionally does **less**, not more. A one-vCPU VPS should spend CPU on the Minecraft protocol/physics and Discord Gateway, not on dashboards, pathfinding, rendering, databases or artificial movement.
