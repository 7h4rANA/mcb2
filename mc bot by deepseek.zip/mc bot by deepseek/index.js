// Load environment variables
require('dotenv').config();

const { Client, GatewayIntentBits, EmbedBuilder, ActivityType } = require('discord.js');
const mineflayer = require('mineflayer');

// ------------------------------
// Configuration & State
// ------------------------------
const config = {
    discordToken: process.env.DISCORD_TOKEN,
    discordChannelId: process.env.DISCORD_CHANNEL_ID,
    minecraftHost: process.env.MINECRAFT_HOST,
    minecraftPort: parseInt(process.env.MINECRAFT_PORT || '25565', 10),
    minecraftUsername: process.env.MINECRAFT_USERNAME,
    minecraftAuth: process.env.MINECRAFT_AUTH || 'microsoft'
};

// Bot state management
let minecraftBot = null;
let botState = 'offline'; // 'offline' | 'connecting' | 'online'
let botStartTime = null;

// Discord client (runs 24/7)
const discordClient = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent
    ],
    // Reduce cache sizes to save memory
    makeCache: discordjs => new discordjs.Options.defaultMakeCacheSettings({
        MessageManager: 0,
        PresenceManager: 0,
        GuildMemberManager: 0,
        UserManager: 0,
        GuildManager: 0,
        ChannelManager: 0,
        GuildScheduledEventManager: 0,
        GuildInviteManager: 0,
        ReactionManager: 0,
        ReactionUserManager: 0,
        StageInstanceManager: 0,
        ThreadManager: 0,
        ThreadMemberManager: 0,
        VoiceStateManager: 0
    })
});

// ------------------------------
// Utility Functions
// ------------------------------
function sendDiscordLog(message) {
    if (!config.discordChannelId) return;
    const channel = discordClient.channels.cache.get(config.discordChannelId);
    if (channel && channel.isTextBased()) {
        channel.send(message).catch(() => {});
    }
}

function formatMemory() {
    const mem = process.memoryUsage();
    return `${(mem.heapUsed / 1024 / 1024).toFixed(2)} MB`;
}

function getBotUptime() {
    if (!botStartTime) return 'N/A';
    const seconds = Math.floor((Date.now() - botStartTime) / 1000);
    return `${Math.floor(seconds / 3600)}h ${Math.floor((seconds % 3600) / 60)}m ${seconds % 60}s`;
}

// ------------------------------
// Minecraft Bot Management
// ------------------------------
async function startMinecraftBot() {
    if (minecraftBot || botState !== 'offline') return;

    botState = 'connecting';
    sendDiscordLog(`🟡 **Connecting** to ${config.minecraftHost}:${config.minecraftPort}...`);

    const botOptions = {
        host: config.minecraftHost,
        port: config.minecraftPort,
        username: config.minecraftUsername,
        auth: config.minecraftAuth,
        // Cache Microsoft OAuth tokens to avoid re-auth every restart
        profilesFolder: './.minecraft-profiles',
        // Minimal view distance
        viewDistance: 'tiny', // or 3
        // Disable physics to save CPU/RAM
        physicsEnabled: false,
        // Prevent block storage – critical for memory
        loadFilter: () => false,
        // No default plugins that consume resources
        loadInternalPlugins: false,
        // Only load essential plugins
        plugins: {
            chat: true,
            physics: false,
            entities: false,
            ray_trace: false,
            block_actions: false,
            crafting: false,
            chest: false,
            digger: false,
            inventory: false,
            sound: false,
            brewing: false,
            enchantment_table: false,
            villager: false,
            book: false,
            boss_bar: false,
            scoreboard: false,
            tablist: false,
            place_block: false,
            anvil: false,
            beacon: false,
            fishing: false,
            game: false,
            experience: false,
            health: false,
            food: false,
            weather: false,
            time: false,
            team: false,
            title: false,
            particle: false,
            command_block: false,
            map: false,
            settings: false,
            pathfinder: false,
            chest_ui: false
        }
    };

    try {
        minecraftBot = mineflayer.createBot(botOptions);

        // Immediately set physics off after spawn (extra safety)
        minecraftBot.once('spawn', () => {
            minecraftBot.physicsEnabled = false;
        });

        // ---- Core Event Handlers ----
        minecraftBot.on('login', () => {
            botState = 'online';
            botStartTime = Date.now();
            sendDiscordLog(`✅ **Bot online** as \`${minecraftBot.username}\` on ${config.minecraftHost}`);
        });

        minecraftBot.on('spawn', () => {
            // Ensure physics disabled
            minecraftBot.physicsEnabled = false;
            // Reduce internal listeners
            minecraftBot.removeAllListeners('physicTick');
            minecraftBot.removeAllListeners('move');
            minecraftBot.removeAllListeners('forcedMove');
            minecraftBot.removeAllListeners('entitySpawn');
            minecraftBot.removeAllListeners('entityMoved');
        });

        minecraftBot.on('kicked', (reason) => {
            const reasonStr = reason ? JSON.stringify(reason) : 'Unknown';
            sendDiscordLog(`⛔ **Kicked**: ${reasonStr}`);
        });

        minecraftBot.on('end', (reason) => {
            const reasonStr = reason || 'Connection closed';
            sendDiscordLog(`🔴 **Disconnected**: ${reasonStr}`);
            cleanupMinecraftBot();
        });

        minecraftBot.on('error', (err) => {
            sendDiscordLog(`⚠️ **Minecraft error**: ${err.message}`);
        });

        // ---- Chat Forwarding ----
        // Public chat mentions
        minecraftBot.on('message', (jsonMsg, position) => {
            if (position !== 'chat') return;
            const message = jsonMsg.toString();
            // Check if bot's name is mentioned (case-insensitive)
            const regex = new RegExp(`\\b${minecraftBot.username}\\b`, 'i');
            if (regex.test(message)) {
                sendDiscordLog(`🔔 **Mention** in chat:\n${message}`);
            }
        });

        // Private messages / whispers
        minecraftBot.on('whisper', (username, message) => {
            sendDiscordLog(`📩 **PM from ${username}**: ${message}`);
        });

        // Cleanup old listeners on end to help GC
        minecraftBot.on('end', () => {
            cleanupMinecraftBot();
        });

    } catch (err) {
        botState = 'offline';
        sendDiscordLog(`❌ **Failed to start bot**: ${err.message}`);
    }
}

function stopMinecraftBot() {
    if (!minecraftBot) return;
    try {
        minecraftBot.quit('Discord command: stop');
    } catch (err) {
        // Fallback: forcibly end
        minecraftBot.end('Discord command: stop');
    }
    // Cleanup happens in 'end' event, but call now in case event doesn't fire
    setTimeout(cleanupMinecraftBot, 2000);
}

function cleanupMinecraftBot() {
    if (minecraftBot) {
        // Remove all listeners to free memory
        try {
            minecraftBot.removeAllListeners();
            minecraftBot._client.removeAllListeners();
        } catch (e) {}
        minecraftBot = null;
    }
    botState = 'offline';
    botStartTime = null;
}

async function restartMinecraftBot() {
    if (minecraftBot) {
        stopMinecraftBot();
        // Wait for cleanup
        await new Promise(resolve => setTimeout(resolve, 3000));
    }
    await startMinecraftBot();
}

// ------------------------------
// Discord Bot Setup
// ------------------------------
discordClient.once('ready', () => {
    console.log(`Discord bot logged in as ${discordClient.user.tag}`);
    discordClient.user.setActivity('Monitoring Minecraft', { type: ActivityType.Watching });
    sendDiscordLog('🤖 Discord bridge is online.');
});

discordClient.on('messageCreate', async (message) => {
    if (message.author.bot) return;
    if (!message.content.startsWith('!')) return;

    const args = message.content.slice(1).trim().split(/ +/);
    const command = args.shift().toLowerCase();

    switch (command) {
        case 'start':
            if (botState === 'offline') {
                await startMinecraftBot();
                message.reply('🟡 Starting Minecraft bot...');
            } else {
                message.reply(`Bot is already ${botState}.`);
            }
            break;

        case 'stop':
            if (botState === 'offline') {
                message.reply('Bot is already offline.');
            } else {
                stopMinecraftBot();
                message.reply('🔴 Stopping Minecraft bot...');
            }
            break;

        case 'restart':
            message.reply('🔄 Restarting Minecraft bot...');
            await restartMinecraftBot();
            break;

        case 'status':
            const embed = new EmbedBuilder()
                .setColor(botState === 'online' ? 0x00FF00 : botState === 'connecting' ? 0xFFFF00 : 0xFF0000)
                .setTitle('Minecraft Bot Status')
                .addFields(
                    { name: 'State', value: botState, inline: true },
                    { name: 'Server', value: `${config.minecraftHost}:${config.minecraftPort}`, inline: true },
                    { name: 'Uptime', value: getBotUptime(), inline: true },
                    { name: 'Ping', value: minecraftBot?.player?.ping ? `${minecraftBot.player.ping} ms` : 'N/A', inline: true },
                    { name: 'Memory (Heap)', value: formatMemory(), inline: true },
                    { name: 'Process RSS', value: `${(process.memoryUsage().rss / 1024 / 1024).toFixed(2)} MB`, inline: true }
                )
                .setTimestamp();
            message.reply({ embeds: [embed] });
            break;

        default:
            // ignore unknown commands
            break;
    }
});

// Discord error handling
discordClient.on('error', (err) => {
    console.error('Discord client error:', err);
});

discordClient.on('shardError', (err) => {
    console.error('Discord shard error:', err);
});

process.on('unhandledRejection', (reason, promise) => {
    console.error('Unhandled Rejection at:', promise, 'reason:', reason);
    sendDiscordLog(`⚠️ **Unhandled rejection**: ${reason}`);
});

// ------------------------------
// Startup
// ------------------------------
(async () => {
    // Validate environment
    if (!config.discordToken || !config.discordChannelId || !config.minecraftHost || !config.minecraftUsername) {
        console.error('Missing required environment variables. Check .env file.');
        process.exit(1);
    }

    // Start Discord client (bot remains connected 24/7)
    try {
        await discordClient.login(config.discordToken);
    } catch (err) {
        console.error('Failed to login to Discord:', err);
        process.exit(1);
    }

    console.log('Discord bot is running. Use !start to connect to Minecraft.');
})();