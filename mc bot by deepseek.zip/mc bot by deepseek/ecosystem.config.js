module.exports = {
  apps: [{
    name: 'minecraft-discord',
    script: 'index.js',
    node_args: '--max-old-space-size=128',
    max_memory_restart: '100M',
    env: {
      NODE_ENV: 'production'
    }
  }]
};