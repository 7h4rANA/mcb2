# Discord Minecraft Bridge (Ultra-Low-Footprint)

A single Node.js script that combines a **Mineflayer** Minecraft bot with a **Discord.js v14** bot, designed specifically for a **512 MB RAM / 1 vCPU VPS**.  
It runs 24/7 on Discord, with the Minecraft bot toggled via simple prefix commands.

---

## ✨ Features

- **Discord Bot (always online)** – Manage the Minecraft bot via `!start`, `!stop`, `!restart`, `!status`.
- **Minecraft Bot** – Connects using Microsoft authentication (cached OAuth tokens).
- **Event Forwarding** – Sends system logs, name mentions, and private messages to a Discord channel.
- **Memory Optimized** – Disables physics, block tracking, pathfinding, and internal plugins.  
  **Expected memory usage: 50–80 MB RSS** during full operation.
- **Graceful error handling** – All socket and bot events wrapped to prevent crashes.
- **Discord cache minimization** – Zero-size caches for all major managers.

---

## 🧠 Memory Optimization Highlights

- `physicsEnabled = false` immediately on spawn.
- `viewDistance: 'tiny'` – minimal chunk loading.
- `loadFilter: () => false` – never load block data.
- `loadInternalPlugins: false` – only `chat` plugin enabled.
- `profilesFolder` – caches Microsoft OAuth tokens to avoid re‑auth.
- All bot listeners removed on disconnect to free heap.
- Discord.js `makeCache` reduces guild/message/user caches to zero.
- No chat logs stored; messages are forwarded and discarded.

---

## 📋 Prerequisites

- **Node.js v18+** (tested with v18.16.0)
- **npm** (comes with Node.js)
- **PM2** (optional, but recommended for process management)
- A **Discord Bot Token** and a **Minecraft account** (Microsoft account)

---

## 🚀 Installation

1. **Clone or download** this repository.

2. **Install dependencies**:
   ```bash
   npm install