'use strict';

const {
  EmbedBuilder,
  ActionRowBuilder,
  StringSelectMenuBuilder,
  ButtonBuilder,
  ButtonStyle,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
} = require('discord.js');

/**
 * The settings exposed in the GUI. Owner/sub-owner lists are deliberately
 * NOT here - they're add/remove operations on a list, not a single
 * current-value-to-edit, so they stay as the explicit text commands
 * (!config addowner / removeowner / addsubowner / removesubowner).
 */
const EDITABLE_FIELDS = [
  { key: 'minecraft.host', label: 'Server host' },
  { key: 'minecraft.port', label: 'Server port' },
  { key: 'minecraft.version', label: 'Minecraft version' },
  { key: 'minecraft.msaEmail', label: 'Microsoft/Minecraft account email' },
  { key: 'minecraft.smpCommand', label: 'SMP join command' },
  { key: 'minecraft.commandDelayMs', label: 'Command delay (ms)' },
  { key: 'minecraft.rejoinDelayMs', label: 'Rejoin delay (ms)' },
  { key: 'minecraft.spawnConfirmTimeoutMs', label: 'SMP confirm timeout (ms)' },
  { key: 'minecraft.viewDistance', label: 'View distance' },
  { key: 'minecraft.autoStartOnBoot', label: 'Auto-start on boot' },
  { key: 'minecraft.antiAfk.enabled', label: 'Anti-AFK jitter enabled' },
  { key: 'discord.prefix', label: 'Command prefix' },
  { key: 'detection.crateKeyRegex', label: 'Crate key match pattern' },
];

// token -> { key, newValueRaw, invokerId, panelMessage }
// Short-lived: entries are removed on save/cancel, or after 5 minutes if
// the user never gets back to them.
const pendingEdits = new Map();
let tokenCounter = 0;
function nextToken() {
  tokenCounter += 1;
  return `${Date.now()}-${tokenCounter}`;
}

function truncate(value, max) {
  const str = String(value);
  return str.length > max ? str.slice(0, max - 1) + '…' : str;
}

function buildPanel(config, invokerId) {
  const embed = new EmbedBuilder()
    .setColor(0x5865f2)
    .setTitle('⚙️ Bot configuration')
    .setDescription(
      'Pick a setting below to edit it.\n' +
        '-# Set "Microsoft/Minecraft account email" to the real email your Minecraft license is ' +
        "under - it doesn't log you in by itself (no password goes through this bot, ever), but it " +
        "should still be your actual account email: it's used to label the saved login cache, and " +
        "mismatches here are a known source of confusing sign-in issues. Signing in always happens " +
        "through the link/code Microsoft sends when you run !start, on Microsoft's own site.\n" +
        '-# Owners/sub-owners are managed separately with `!config addowner`, `!config removeowner`, ' +
        '`!config addsubowner`, `!config removesubowner`.'
    )
    .setTimestamp();

  for (const field of EDITABLE_FIELDS) {
    embed.addFields({ name: field.label, value: '`' + truncate(config.get(field.key), 200) + '`', inline: true });
  }

  const select = new StringSelectMenuBuilder()
    .setCustomId(`config_select:${invokerId}`)
    .setPlaceholder('Choose a setting to edit...')
    .addOptions(
      EDITABLE_FIELDS.map((field) => ({
        label: truncate(field.label, 100),
        value: field.key,
        description: truncate(`Currently: ${config.get(field.key)}`, 100),
      }))
    );

  const closeButton = new ButtonBuilder().setCustomId(`config_close:${invokerId}`).setLabel('Close').setStyle(ButtonStyle.Secondary);

  return {
    embeds: [embed],
    components: [new ActionRowBuilder().addComponents(select), new ActionRowBuilder().addComponents(closeButton)],
  };
}

async function handleSelect(interaction, config) {
  const invokerId = interaction.customId.split(':')[1];
  if (interaction.user.id !== invokerId) {
    await interaction.reply({ content: "This isn't your config panel.", ephemeral: true });
    return;
  }

  const key = interaction.values[0];
  const field = EDITABLE_FIELDS.find((f) => f.key === key);
  const currentValue = config.get(key);

  const modal = new ModalBuilder()
    .setCustomId(`config_modal:${key}`)
    .setTitle(truncate(`Edit ${field ? field.label : key}`, 45));

  const input = new TextInputBuilder()
    .setCustomId('value')
    .setLabel(truncate(key, 45))
    .setStyle(TextInputStyle.Short)
    .setValue(truncate(currentValue ?? '', 400))
    .setRequired(true)
    .setMaxLength(400);

  modal.addComponents(new ActionRowBuilder().addComponents(input));
  await interaction.showModal(modal);
}

async function handleModalSubmit(interaction, config) {
  const key = interaction.customId.slice('config_modal:'.length);
  const newValueRaw = interaction.fields.getTextInputValue('value');
  const currentValue = config.get(key);

  const token = nextToken();
  pendingEdits.set(token, {
    key,
    newValueRaw,
    invokerId: interaction.user.id,
    // Available when the modal was opened from a component on an existing
    // message (which is always true here) on recent discord.js versions.
    // If it's ever missing on your installed version, we just skip
    // auto-refreshing the panel below - nothing breaks.
    panelMessage: interaction.message || null,
  });
  setTimeout(() => pendingEdits.delete(token), 5 * 60 * 1000);

  const embed = new EmbedBuilder()
    .setColor(0xfee75c)
    .setTitle('Confirm change')
    .addFields(
      { name: 'Setting', value: `\`${key}\`` },
      { name: 'Current', value: `\`${truncate(currentValue, 500)}\``, inline: true },
      { name: 'New', value: `\`${truncate(newValueRaw, 500)}\``, inline: true }
    );

  const saveBtn = new ButtonBuilder().setCustomId(`config_save:${token}`).setLabel('Save').setStyle(ButtonStyle.Success);
  const cancelBtn = new ButtonBuilder().setCustomId(`config_cancel:${token}`).setLabel('Cancel').setStyle(ButtonStyle.Danger);

  await interaction.reply({
    embeds: [embed],
    components: [new ActionRowBuilder().addComponents(saveBtn, cancelBtn)],
    ephemeral: true,
  });
}

async function handleSave(interaction, config) {
  const token = interaction.customId.slice('config_save:'.length);
  const pending = pendingEdits.get(token);
  if (!pending) {
    await interaction.update({ content: 'This edit has expired - run `!config` again.', embeds: [], components: [] });
    return;
  }
  if (interaction.user.id !== pending.invokerId) {
    await interaction.reply({ content: "This isn't your edit to confirm.", ephemeral: true });
    return;
  }
  pendingEdits.delete(token);

  let savedValue;
  try {
    savedValue = config.set(pending.key, pending.newValueRaw);
  } catch (err) {
    await interaction.update({ content: `❌ Could not save: ${err.message}`, embeds: [], components: [] });
    return;
  }

  await interaction.update({
    content: `✅ \`${pending.key}\` is now \`${JSON.stringify(savedValue)}\``,
    embeds: [],
    components: [],
  });

  if (pending.panelMessage) {
    try {
      await pending.panelMessage.edit(buildPanel(config, pending.invokerId));
    } catch {
      /* original panel message may have been closed/deleted already - fine */
    }
  }
}

async function handleCancel(interaction) {
  const token = interaction.customId.slice('config_cancel:'.length);
  const pending = pendingEdits.get(token);
  if (pending && interaction.user.id !== pending.invokerId) {
    await interaction.reply({ content: "This isn't your edit to cancel.", ephemeral: true });
    return;
  }
  pendingEdits.delete(token);
  await interaction.update({ content: '❌ Cancelled - no changes made.', embeds: [], components: [] });
}

async function handleClose(interaction) {
  const invokerId = interaction.customId.slice('config_close:'.length);
  if (interaction.user.id !== invokerId) {
    await interaction.reply({ content: "This isn't your config panel.", ephemeral: true });
    return;
  }
  await interaction.update({ content: 'Config panel closed.', embeds: [], components: [] });
}

module.exports = {
  EDITABLE_FIELDS,
  buildPanel,
  handleSelect,
  handleModalSubmit,
  handleSave,
  handleCancel,
  handleClose,
};
