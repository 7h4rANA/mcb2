'use strict';

const fs = require('fs');
const path = require('path');
const EventEmitter = require('events');
const mineflayer = require('mineflayer');

const logger = require('../utils/logger');
const { getRamUsage } = require('../utils/ram');
const { CommandQueue, sleep } = require('./commandQueue');
const { AntiAfk } = require('./antiAfk');

/**
 * Owns exactly one mineflayer bot instance at a time and everything about
 * its lifecycle: connecting, the hub -> "/server smp" -> confirmed-on-smp
 * sequence, automatic reconnection on kick/disconnect, and passive chat
 * scanning (mentions, whispers, crate keys).
 *
 * This file knows nothing about Discord - it only emits events
 * ('mention', 'whisper', 'crateKey', 'statusChange') that
 * src/discord/discordController.js listens to. That keeps the two halves
 * of the bot independently testable and easy to reason about.
 */
class McController extends EventEmitter {
  constructor(config) {
    super();
    this.config = config;
    this.bot = null;
    this.status = 'offline'; // offline | connecting | hub | joining_smp | smp
    this.currentServer = null; // 'hub' | 'smp' | null
    this.startedAt = null;
    this.manualStop = true; // true until the first successful !start
    this._reconnectPending = false;

    this.antiAfk = new AntiAfk(config);
    this.commandQueue = new CommandQueue(
      () => this.bot,
      () => this.config.get('minecraft.commandDelayMs') || 1500
    );
  }

  // ---------------------------------------------------------------- status

  _setStatus(status) {
    this.status = status;
    this.emit('statusChange', status);
  }

  isOnline() {
    return !!(this.bot && this.bot.entity);
  }

  getStatusData() {
    const bot = this.bot;
    const ram = getRamUsage();
    return {
      online: this.isOnline(),
      status: this.status,
      uptimeMs: this.startedAt ? Date.now() - this.startedAt : 0,
      username: bot ? bot.username : null,
      server: this.currentServer,
      health: bot ? bot.health : null,
      food: bot ? bot.food : null,
      dimension: bot && bot.game ? bot.game.dimension : null,
      ping: bot && bot.player ? bot.player.ping : null,
      ramMb: ram.rssMb,
      host: this.config.get('minecraft.host'),
      port: this.config.get('minecraft.port'),
      version: this.config.get('minecraft.version'),
    };
  }

  // -------------------------------------------------------- start / stop

  async start() {
    if (this.bot) {
      throw new Error('Bot is already connected (or connecting). Use !stop first if you need to reset it.');
    }
    if (this._reconnectPending) {
      throw new Error('An automatic reconnect is already scheduled - it will pick back up on its own shortly.');
    }
    this.manualStop = false;
    try {
      await this._runJoinSequence();
      this.startedAt = Date.now();
    } catch (err) {
      console.error('[mcController] start() failed:', err);
      this._cleanupBot();
      this._setStatus('offline');
      throw err;
    }
  }

  async stop() {
    this.manualStop = true;
    this._reconnectPending = false;
    if (this.bot) {
      try {
        this.bot.quit('stopped via Discord');
      } catch {
        /* already dead, ignore */
      }
    }
    this._cleanupBot();
    this._setStatus('offline');
  }

  async restart() {
    await this.stop();
    await sleep(2000);
    await this.start();
  }

  async logout() {
    await this.stop();
    const dir = path.resolve(process.cwd(), this.config.get('auth.profilesFolder'));
    if (fs.existsSync(dir)) {
      fs.rmSync(dir, { recursive: true, force: true });
    }
  }

  _cleanupBot() {
    this.antiAfk.stop();
    this.bot = null;
    this.currentServer = null;
    this.startedAt = null;
  }

  // ------------------------------------------------------ join sequence

  async _runJoinSequence() {
    this._setStatus('connecting');
    const bot = this._createBot();
    this.bot = bot;

    const gotHubSpawn = await this._waitForNextSpawn(bot, 45000);
    if (this.bot !== bot) return; // superseded (stop()/restart() ran while we were waiting)
    if (!gotHubSpawn) {
      throw new Error('Timed out waiting to spawn after connecting (auth or world load took too long).');
    }
    this.currentServer = 'hub';
    this._setStatus('hub');
    logger.success('Joined hub', `Connected as **${bot.username}**.`);

    await sleep(this.config.get('minecraft.commandDelayMs') || 1500);
    if (this.bot !== bot) return;

    this._setStatus('joining_smp');
    const smpCommand = this.config.get('minecraft.smpCommand');
    logger.info('Sending SMP command', `\`${smpCommand}\``);
    await this.commandQueue.push(smpCommand);

    const confirmTimeout = this.config.get('minecraft.spawnConfirmTimeoutMs') || 15000;
    const gotSmpSpawn = await this._waitForNextSpawn(bot, confirmTimeout);
    if (this.bot !== bot) return;

    if (gotSmpSpawn) {
      this.currentServer = 'smp';
      this._setStatus('smp');
      logger.success('Joined SMP', `**${bot.username}** is now on the SMP.`);
    } else {
      // Not fatal - the bot is very likely still fine, we just couldn't
      // positively confirm the server switch via a fresh spawn event.
      // Different proxies/servers can behave slightly differently here.
      this._setStatus('smp');
      this.currentServer = 'smp';
      logger.warn(
        'Could not confirm the SMP join',
        'No new spawn event arrived after sending the SMP command. The bot is probably fine - double-check in-game or with !status.'
      );
    }

    this.antiAfk.start(bot);
  }

  _waitForNextSpawn(bot, timeoutMs) {
    return new Promise((resolve) => {
      let done = false;
      const onSpawn = () => {
        if (done) return;
        done = true;
        clearTimeout(timer);
        resolve(true);
      };
      const timer = setTimeout(() => {
        if (done) return;
        done = true;
        bot.removeListener('spawn', onSpawn);
        resolve(false);
      }, timeoutMs);
      bot.once('spawn', onSpawn);
    });
  }

  _scheduleReconnect() {
    if (this._reconnectPending) return;
    this._reconnectPending = true;
    const delay = this.config.get('minecraft.rejoinDelayMs') || 5000;
    setTimeout(async () => {
      this._reconnectPending = false;
      if (this.manualStop) return;
      try {
        await this._runJoinSequence();
        this.startedAt = Date.now();
      } catch (err) {
        logger.error('Reconnect attempt failed', err.message);
        this._cleanupBot();
        this._setStatus('offline');
        this._scheduleReconnect();
      }
    }, delay);
  }

  // ------------------------------------------------------------ create

  _createBot() {
    const cfg = this.config.get('minecraft');
    const bot = mineflayer.createBot({
      host: cfg.host,
      port: cfg.port,
      username: cfg.msaEmail || 'bot-account', // see README - should be the real MS/Minecraft account email
      auth: 'microsoft',
      version: cfg.version,
      profilesFolder: path.resolve(process.cwd(), this.config.get('auth.profilesFolder')),
      viewDistance: cfg.viewDistance,
      checkTimeoutInterval: 60 * 1000,
      onMsaCode: (data) => {
        logger.warn(
          'Microsoft sign-in required',
          `Open **${data.verification_uri}** on your phone or computer and enter this code: \`${data.user_code}\`\n\n` +
            `Then sign in on Microsoft's own page with the Microsoft account that owns your Minecraft license ` +
            `(this can absolutely be a Gmail-based account - Microsoft accounts can use any email as the login). ` +
            `The bot never asks for or sees your password - you only ever type it on Microsoft's real site.\n\n` +
            `This only has to be done once - after this the bot stays signed in on its own.`
        );
      },
    });

    this._wireEvents(bot);
    return bot;
  }

  _wireEvents(bot) {
    bot.on('kicked', (reason) => {
      if (this.bot !== bot) return;
      logger.error('Bot was kicked', formatReason(reason));
    });

    bot.on('error', (err) => {
      if (this.bot !== bot) return;
      logger.error('Connection error', err && err.message ? err.message : String(err));
    });

    bot.on('end', (reason) => {
      if (this.bot !== bot) return;
      this._cleanupBot();
      this._setStatus('offline');
      if (this.manualStop) {
        logger.info('Disconnected', 'Bot was stopped intentionally - not reconnecting.');
        return;
      }
      const delay = this.config.get('minecraft.rejoinDelayMs') || 5000;
      logger.warn('Disconnected', `Reason: ${formatReason(reason)}. Rejoining the hub in ${delay}ms...`);
      this._scheduleReconnect();
    });

    bot.on('chat', (username, message) => {
      if (this.bot !== bot) return;
      if (username === bot.username) return;
      if (bot.username && message.toLowerCase().includes(bot.username.toLowerCase())) {
        this.emit('mention', { username, message });
      }
    });

    bot.on('whisper', (username, message) => {
      if (this.bot !== bot) return;
      this.emit('whisper', { username, message });
    });

    bot.on('message', (jsonMsg) => {
      if (this.bot !== bot) return;
      let text;
      try {
        text = jsonMsg.toString();
      } catch {
        return;
      }
      if (!text) return;
      try {
        const crateRe = new RegExp(this.config.get('detection.crateKeyRegex') || 'crate key', 'i');
        if (crateRe.test(text)) this.emit('crateKey', { text });
      } catch {
        /* bad regex in config - ignore rather than crash the bot */
      }
    });
  }

  // --------------------------------------------------------------- I/O

  sendPublicChat(message) {
    if (!this.bot) throw new Error('Bot is not connected.');
    return this.commandQueue.push(message);
  }

  sendTell(target, message) {
    if (!this.bot) throw new Error('Bot is not connected.');
    return this.commandQueue.push(`/tell ${target} ${message}`);
  }

  /** Sends a slash command and captures whatever text arrives in the next `windowMs`. */
  async captureCommandOutput(rawCommand, windowMs = 4000) {
    if (!this.bot) throw new Error('Bot is not connected.');
    const bot = this.bot;
    const lines = [];
    const onMessage = (jsonMsg) => {
      try {
        const text = jsonMsg.toString();
        if (text.trim()) lines.push(text);
      } catch {
        /* ignore unparsable message */
      }
    };
    bot.on('message', onMessage);
    const normalized = rawCommand.startsWith('/') ? rawCommand : `/${rawCommand}`;
    await this.commandQueue.push(normalized);
    await sleep(windowMs);
    bot.removeListener('message', onMessage);
    return lines;
  }
}

function formatReason(reason) {
  if (reason == null) return 'unknown';
  if (typeof reason === 'string') {
    try {
      const parsed = JSON.parse(reason);
      return jsonMsgToPlainText(parsed);
    } catch {
      return reason;
    }
  }
  return jsonMsgToPlainText(reason);
}

function jsonMsgToPlainText(node) {
  if (node == null) return 'unknown';
  if (typeof node === 'string') return node;
  let text = node.text || '';
  if (Array.isArray(node.extra)) {
    text += node.extra.map(jsonMsgToPlainText).join('');
  }
  return text || JSON.stringify(node);
}

module.exports = { McController };
