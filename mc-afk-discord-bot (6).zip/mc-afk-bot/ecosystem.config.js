module.exports = {
  apps: [
    {
      name: 'mc-afk-bot',
      script: 'src/index.js',
      cwd: __dirname,
      instances: 1,
      exec_mode: 'fork',
      autorestart: true,
      node_args: '--max-old-space-size=256',
      // Hard safety net: if the process somehow balloons past this (RSS,
      // not just heap), PM2 kills and restarts it rather than letting it
      // starve everything else on a 750MB box.
      max_memory_restart: '300M',
      restart_delay: 5000,
      max_restarts: 20,
      env: {
        NODE_ENV: 'production',
      },
    },
  ],
};
