# mc-afk-discord-bot

A Minecraft AFK bot (Microsoft account, stays signed in permanently) that connects to your
network's hub, waits a moment, runs `/server smp`, and stays there — auto-rejoining the same
way if it's ever kicked or disconnected. Everything is controlled from Discord: starting,
stopping, status, chat, `/tell`, arbitrary commands, and even live config edits, split across
three channels (commands / logs / chat) as requested.

Built with [mineflayer](https://github.com/PrismarineJS/mineflayer) (v4.37) and
[discord.js](https://discord.js.org/) (v14). No paid services, no external database — just two
JSON-ish files and Node.js.

> This is written on the understanding that your server's owner has publicly allowed AFK bots
> (you mentioned this is because of electricity costs). That's between you and the server —
> just keep in mind that connecting a non-standard client is still ultimately governed by
> whatever rules your server and Mojang/Microsoft's terms set, so it's worth keeping that
> announcement somewhere you can point to if it's ever questioned.

---

## 1. What you get

```
mc-afk-bot/
├── src/
│   ├── index.js                  entry point
│   ├── config/configManager.js   loads config.json, powers !config
│   ├── minecraft/
│   │   ├── mcController.js       connect / hub→smp / reconnect / chat parsing
│   │   ├── commandQueue.js       rate-limits every outgoing chat/command
│   │   └── antiAfk.js            small look/jump jitter so it isn't kicked for idling
│   ├── discord/
│   │   ├── discordController.js  Discord client (cache tuned way down), message router, presence
│   │   ├── commands.js           !start !stop !restart !status !chat !tell !cmd !config ...
│   │   ├── configPanel.js        the interactive !config GUI (select menu → modal → Save/Cancel)
│   │   ├── embeds.js             all embed builders
│   │   └── permissions.js        owner/sub-owner + channel checks
│   └── utils/ (logger.js, ram.js)
├── config/config.example.json    template — copy to config.json
├── ecosystem.config.js           PM2 process config (optional, see §6)
├── deploy/mc-afk-bot.service     systemd unit (recommended, see §6)
├── .env.example                  put your Discord bot token here
└── package.json
```

## 2. Requirements

- A VPS running Linux (Ubuntu/Debian assumed below). 512MB RAM is enough — the bot idles
  around 60–120MB.
- **Node.js 22 or newer.**
- A Microsoft account that owns the Minecraft account you're AFK'ing with.
- A Discord server you control, with three text channels created: e.g. `#mc-commands`,
  `#mc-logs`, `#mc-chat`.

### Install Node.js (skip if you already have ≥22)

```bash
curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash -
sudo apt-get install -y nodejs
node -v   # should print v22.x or similar
```

## 3. Create the Discord bot

1. Go to the [Discord Developer Portal](https://discord.com/developers/applications) →
   **New Application** → give it a name.
2. Left sidebar → **Bot** → **Add Bot**.
3. Still on the Bot page, turn on **Message Content Intent** (under *Privileged Gateway
   Intents*) — the bot can't read your `!start` etc. without this.
4. Click **Reset Token** / **Copy** to get your bot token. Keep it secret.
5. Left sidebar → **OAuth2 → URL Generator**. Check `bot`, then under Bot Permissions check
   *Send Messages*, *Embed Links*, *Read Message History*, *Add Reactions*, *Use External
   Emojis*. Open the generated URL and invite the bot to your server.
6. In Discord, enable **Developer Mode** (User Settings → Advanced), then right-click each of
   your three channels → **Copy Channel ID**. Also right-click your own username → **Copy User
   ID** — that's your owner ID.

## 4. Get the code onto your VPS and install it

Upload the project folder (or `git clone` it if you put it in a repo), then:

```bash
cd mc-afk-bot
npm install
cp .env.example .env
cp config/config.example.json config/config.json
```

Edit **`.env`**:

```
DISCORD_TOKEN=your_bot_token_from_step_3
```

Edit **`config/config.json`** (you can also do all of this later from Discord with
`!config`, except the very first owner ID and channel IDs, which must exist before the bot can
respond to anything):

```jsonc
{
  "discord": {
    "ownerIds": ["your_discord_user_id"],
    "subOwnerIds": [],
    "prefix": "!",
    "channels": {
      "commands": "commands_channel_id",
      "logs": "logs_channel_id",
      "chat": "chat_channel_id"
    }
  },
  "minecraft": {
    "host": "play.example.net",
    "port": 25565,
    "version": "1.21.4",
    "smpCommand": "/server smp",
    "commandDelayMs": 1500,
    "rejoinDelayMs": 5000
    // ...
  }
}
```

### A note on `minecraft.version`

Your server is on 1.21.11, and Flamecord (your proxy) is a multi-version anti-bot proxy — it
re-writes packets so clients on other versions can still join. `minecraft-data` (the library
mineflayer relies on for version support) may lag a patch or two behind brand-new Minecraft
releases. **You don't need to match 1.21.11 exactly** — `1.21.4` is a safe, fully-supported
default that Flamecord will happily translate. If you want to try the exact version, just set
`minecraft.version` to `"1.21.11"`; if mineflayer errors out saying the version isn't
supported yet, drop back to `1.21.4` (or whatever the latest mineflayer changelog says is
supported — `npm view mineflayer` on your VPS will show you the installed version).

## 5. First run

Before your first `!start`, it's worth setting `minecraft.msaEmail` in `config/config.json`
(or via `!config` once the bot is running - see §8) to the **real email your Minecraft
license is under**. It's not what you type a password into — it never asks for a password at
all — but mineflayer's own docs recommend matching it to your actual account email, since
mismatches here are a documented source of confusing sign-in errors.

```bash
node src/index.js
```

You should see `[discord] Logged in as YourBot#1234` in the console. In your `#mc-commands`
channel, run:

```
!start
```

### How signing in actually works (no password field, on purpose)

The **first** time you do this, mineflayer needs you to sign in with the Microsoft account
that owns your Minecraft license. There is deliberately **no field anywhere in this bot for
your password** — that's not a missing feature, it's how Microsoft's official sign-in flow
(OAuth "device code" flow) works, and it's safer than the alternative: the bot itself never
sees or asks for your password at any point. Mineflayer *does* technically still expose an
old direct username+password option for Microsoft accounts, but its own docs mark it "may be
unreliable" — Microsoft has been steadily locking that path down, it silently breaks for any
account with 2FA enabled (which is most accounts now), and it would mean your real Microsoft
password sitting in a Discord message and a plaintext config file on your VPS. That's a bad
trade for something that often doesn't even work, so this bot intentionally doesn't offer it.

Watch **#mc-logs** (and the console) for a message like:

```
Microsoft sign-in required
Open https://www.microsoft.com/link and enter this code: ABCD-EFGH
```

1. Open that link on **any device** — your phone, another tab, doesn't matter.
2. Enter the code shown.
3. Microsoft's own page then asks you to sign in normally, with whatever account owns your
   Minecraft license — **this can absolutely be a Gmail address.** Microsoft accounts aren't
   tied to `@outlook.com`/`@hotmail.com`; plenty of people sign in with a Gmail (or any other)
   email as their Microsoft account login. You type your password there, on Microsoft's real
   site — never into this bot or into Discord.

Within a few seconds of finishing that, the bot detects the sign-in, finishes connecting,
joins the hub, waits, sends `/server smp`, and posts a `!status` embed.

**This only happens once.** The auth token is cached in `./mc-auth-cache/` and refreshed
automatically — you won't be asked again unless you run `!logout` or delete that folder.
This is what stops the "not authenticated by minecraft.net" problem: that error normally
means the token expired or was never cached in the first place, and here it always is.

If sign-in itself fails or hangs after you enter the code, see §13 for the specific common
causes.

Once you're happy it works, stop it with Ctrl+C and run it under PM2 instead (next section) so
it survives reboots, crashes, and SSH disconnects.

## 6. Running it permanently

Two options. Given your box is only 750MB with something else (V2Ray) already running on it,
**systemd is the better default** — PM2 is convenient but runs its own persistent background
Node.js daemon on top of your bot's process, typically another 30-50MB you don't get back.
systemd is already part of the OS and costs nothing extra.

### Option A — systemd (recommended for tight-RAM boxes)

```bash
which node   # note the full path, e.g. /usr/bin/node - you'll need it below
```

Edit `deploy/mc-afk-bot.service`: fill in your Linux username, the project's full path, and
the `node` path from above if it's different from `/usr/bin/node`. Then:

```bash
sudo cp deploy/mc-afk-bot.service /etc/systemd/system/mc-afk-bot.service
sudo systemctl daemon-reload
sudo systemctl enable --now mc-afk-bot
```

```bash
sudo systemctl status mc-afk-bot   # running? current memory use?
journalctl -u mc-afk-bot -f        # live logs (like `pm2 logs`)
sudo systemctl restart mc-afk-bot
sudo systemctl stop mc-afk-bot
```

The unit file also sets `Nice=10` (deprioritize this bot's CPU vs. your V2Ray/game traffic on
the single core) and a hard `MemoryMax=300M` cgroup ceiling — if the bot ever balloons past
that, the kernel kills just this process and systemd restarts it; it can't take the rest of
the VPS down with it. See the comments in that file for details.

### Option B — PM2 (if you'd rather have PM2's tooling)

```bash
sudo npm install -g pm2
cd mc-afk-bot
pm2 start ecosystem.config.js
pm2 save
pm2 startup            # follow the one printed command to enable boot-start
```

```bash
pm2 logs mc-afk-bot     # live console output
pm2 restart mc-afk-bot  # restart the whole Node process (Discord + Minecraft)
pm2 stop mc-afk-bot
```

`ecosystem.config.js` already caps the V8 heap and sets a 300MB hard restart threshold, same
idea as the systemd unit.

## 7. Performance on a tiny VPS (750MB RAM, 1 vCPU, sharing with V2Ray)

### What was actually using 450MB, and what wasn't

The ping-estimation feature some earlier code had is gone now (you can see why below), but to
be direct about it: **that specific feature was not your 450MB.** It did a few number
comparisons every ~15-20 seconds (one Minecraft keep-alive cycle) - genuinely negligible CPU
and effectively zero extra memory. Removing it simplifies the code (and it's gone, along with
its `!status` field), but it isn't what was driving your RAM number up.

The real contributors, roughly biggest to smallest:

1. **discord.js's default caching.** Out of the box, discord.js caches recent messages per
   channel, reactions, presences, and more - all fine for a bot in dozens of busy servers,
   pure waste for one bot in three channels that only ever acts on the message right in front
   of it. This was almost certainly the single biggest lever, and it's now tuned down hard
   (`src/discord/discordController.js`) - message/reaction/presence caching is disabled,
   member/user caches are capped small. (`GuildManager`/`ChannelManager`/`RoleManager` etc.
   are deliberately left alone - discord.js's own docs say customizing those breaks things.)
2. **`minecraft-data`'s per-version tables.** mineflayer loads a full set of block/item/
   entity/recipe/etc. definitions for whatever Minecraft version you connect as. This is a
   core, non-optional part of mineflayer - there's no supported "lite mode" - and it's grown
   over the years as Minecraft has added content. Not something this bot's code controls.
3. **Baseline Node.js/V8 overhead**, which is normal for any Node process and also mostly
   fixed cost.

### What changed

- **discord.js cache limits**, as above - the biggest controllable win.
- **`--max-old-space-size=256`** on the Node process itself (`package.json`'s `start` script,
  `ecosystem.config.js`, and the systemd unit all set this) - caps how large V8 lets its heap
  grow before collecting more aggressively, instead of growing to whatever the OS allows.
- **A hard memory ceiling either way** - PM2's `max_memory_restart: '300M'` or systemd's
  `MemoryMax=300M` - so a leak or an unexpected spike gets the bot restarted automatically
  instead of pressuring your V2Ray server or getting the OOM killer involved.
- **CPU deprioritization** (systemd's `Nice=10`) so this bot's occasional bursts (auth,
  reconnect sequences) don't compete with latency-sensitive proxy/game traffic on your one
  core.
- Removed the ping-estimation module entirely, per your ask, even though (per above) it wasn't
  the actual cost.

### Being honest about the 150MB / 250-300MB targets

I can't make this bot report an exact RAM number to you in advance - actual usage depends on
things outside the code, like exactly which Minecraft version's data table gets loaded,
Node's own version and GC behavior, and how long the process has been running. What I can say:
the changes above target the right things (cutting real, measurable waste rather than
theoretical ones), a small AFK/chat bot like this idling in the ~100-180MB range after tuning
is a realistic outcome based on how other lean mineflayer+discord.js bots behave, and either
way you now have a hard ceiling (300MB) so it structurally cannot exceed that and take your
V2Ray server down with it - restart-and-recover instead. Watch it with `!status` (or
`systemctl status` / `pm2 status`) for a few days under real conditions and let me know the
actual numbers if you want to tune further from there - that's better data than either of us
guessing.

### One more thing worth doing: add swap

If this VPS has no swap configured, do that too - it's a free safety net against any process
(not just this bot) spiking briefly, e.g. during `npm install` or right at Node startup:

```bash
sudo fallocate -l 512M /swapfile
sudo chmod 600 /swapfile
sudo mkswap /swapfile
sudo swapon /swapfile
echo '/swapfile none swap sw 0 0' | sudo tee -a /etc/fstab
```

512MB is enough to absorb short spikes on a box this size without masking a real ongoing leak.

## 8. Commands

All commands use the `!` prefix by default (`discord.prefix` in config). Anyone in
`ownerIds` **or** `subOwnerIds` can use the operational commands below. **`!config`,
`!login` and `!logout` are owner-only** — they touch account credentials and the
owner/sub-owner list itself.

| Command | Channel(s) | Does |
|---|---|---|
| `!start` | commands | Connects, joins hub, waits, sends `/server smp`, posts `!status` when done |
| `!stop` | commands | Disconnects and **disables auto-reconnect** — safe to log in yourself |
| `!restart` | commands | `!stop` then `!start` again |
| `!status` | commands, chat | Embed: online/offline, uptime, username, skin head, real ping vs. server-reported ping, current server (hub/smp), health, world, RAM |
| `!chat <msg>` | commands, chat | Sends `<msg>` in public chat |
| `!tell <player> <msg>` | commands, chat | Sends `/tell <player> <msg>` |
| `!cmd <command>` | commands | Runs `/<command>` and replies with whatever the server said back over the next ~4s |
| `!login` | commands (owner) | Same as `!start`, but explicit — will prompt for Microsoft sign-in if not cached |
| `!logout` | commands (owner) | Stops the bot and deletes the cached Microsoft session |
| `!config` | commands (owner) | Opens the interactive config GUI, see below |
| `!config help` | commands (owner) | Text-command reference for `!config`, if you'd rather type than click |
| `!help` | commands, chat | Lists all of the above in Discord |

### `!config` — the GUI panel

Just run `!config` with no arguments. The bot posts an embed listing every editable setting
with its **current value**, plus a dropdown underneath:

1. **Pick a setting** from the dropdown (each option's subtext shows its current value too).
2. A **popup form** (a native Discord modal) appears, pre-filled with the current value in a
   text box — edit it and hit Discord's **Submit**.
3. You then get a **confirm step** showing old vs. new value with **✅ Save** and
   **❌ Cancel** buttons. Nothing is written to `config.json` until you press Save.
4. After saving, the original panel refreshes in place to show the new value.

Only the person who ran `!config` can interact with their own panel/popup — anyone else
clicking it gets told it isn't theirs. The panel doesn't expire on its own, but each individual
edit-in-progress (after you submit the popup, before you hit Save) expires after 5 minutes if
left untouched.

The GUI covers: `minecraft.host`, `port`, `version`, `msaEmail`,
`smpCommand`, `commandDelayMs`, `rejoinDelayMs`, `spawnConfirmTimeoutMs`, `viewDistance`,
`autoStartOnBoot`, `antiAfk.enabled`, `discord.prefix`, and `detection.crateKeyRegex`.

Owner/sub-owner lists aren't in the GUI (they're add/remove operations on a list, not a
single value to overwrite) — manage those with the text commands instead, which still work
exactly as before:

```
!config get minecraft.host
!config set minecraft.host play.example.net
!config set minecraft.port 25565
!config set minecraft.smpCommand "/server smp"
!config set minecraft.commandDelayMs 1500
!config addowner 123456789012345678
!config removeowner 123456789012345678
!config addsubowner 123456789012345678
!config removesubowner 123456789012345678
```

Any dotted key from `config.json` works with `get`/`set` (host, port, version, smpCommand,
commandDelayMs, rejoinDelayMs, viewDistance, etc), whether or not it's in the GUI list above.

### In-game → Discord

- Someone typing your bot's name in **public chat** → posted to `#mc-chat` as a blue
  "💬 Public chat mention" embed.
- Someone sending you a **`/tell`** → posted to `#mc-chat` as a purple "✉️ Private message"
  embed — deliberately styled differently from mentions so you can tell them apart at a
  glance.
- Any chat line matching the crate-key pattern → posted to `#mc-chat` as a yellow
  "🔑 Crate key alert!" embed. The default pattern is just `crate key` (case-insensitive,
  `detection.crateKeyRegex` in config) — tighten or loosen it with `!config set
  detection.crateKeyRegex "..."` if your server's actual message looks different.
- Getting kicked or disconnected → posted to `#mc-logs` immediately, followed by the
  reconnect attempt a few seconds later.

## 9. How the hub → SMP → reconnect logic actually works

Rather than trying to guess Flamecord's exact chat-message wording for "you switched
servers" (which varies by proxy/plugin setup and would be fragile), the bot uses the
Minecraft protocol itself: on a Bungee/Velocity/Flamecord-style network, switching backend
servers via `/server <name>` causes a **new `spawn` event** (your world/position resets).
So the flow is:

1. Connect → wait for the first `spawn` event → that means "in the hub."
2. Wait `minecraft.commandDelayMs` (default 1500ms).
3. Send `minecraft.smpCommand` (default `/server smp`) through the rate-limited queue.
4. Wait up to `minecraft.spawnConfirmTimeoutMs` (default 15s) for a **second** `spawn` event →
   that means "confirmed on the SMP."
5. If disconnected/kicked for any reason and it wasn't a manual `!stop`: wait
   `minecraft.rejoinDelayMs` (default 5s), then repeat the whole sequence from step 1.

Every outgoing chat line or command — `/server smp`, `/tell`, `!cmd`, `!chat` — goes through
one shared queue (`commandQueue.js`) that enforces `minecraft.commandDelayMs` between sends,
so you'll never get flagged for sending things "too fast," no matter which Discord command
triggered it.

## 10. View distance / chunk loading

`minecraft.viewDistance: 3` is sent to the server as the client's render distance, which is
exactly what makes it load a 7×7 chunk area (3 chunks in every direction from the bot, plus
its own chunk = 7). No separate setting needed — one config value covers both things you
asked for. If your installed mineflayer version rejects a plain number here, use one of the
string presets instead: `"tiny"`, `"short"`, `"normal"`, `"far"` (via `!config set
minecraft.viewDistance tiny`, etc.).

## 11. Things you'll likely want to adjust

The server-specific bits below are educated defaults, not guarantees — I don't have access to
your actual server to test against, so tune these once you see how your server actually talks:

- **`detection.crateKeyRegex`** — defaults to `crate key`. Adjust to match your server's real
  wording via `!config set`.
- **`minecraft.commandDelayMs`** — 1500ms is a safe starting point for most anti-bot/anti-spam
  setups; raise it if you still get kicked for spamming, lower it if you want faster hub
  navigation and it's not causing issues.
- **`!cmd` output window** — captures whatever chat/system messages arrive in the ~4 seconds
  after sending a command. Since the server doesn't tag command output specially, unrelated
  chat happening at the same moment will show up mixed in — that's an inherent limitation of
  reading plain chat, not a bug.
- **Restart semantics** — `!restart` restarts the *Minecraft connection* (stop → start), not
  the whole Node process, so it can't accidentally kill the bot permanently if you haven't set
  up process supervision yet. If you ever want to restart the entire process (Discord
  included), run `sudo systemctl restart mc-afk-bot` (or `pm2 restart mc-afk-bot`) from the
  VPS directly.

## 12. Physics, knockback, and anti-AFK

The bot does **not** cancel or fight incoming knockback, fall damage, or any other server-sent
physics — mineflayer applies velocity updates from the server to its own physics simulation
every tick exactly like a real client would, and nothing in this codebase overrides that.

The only thing it does on its own is `minecraft/antiAfk.js`: every 20–45 seconds (configurable
under `minecraft.antiAfk`) it does a tiny random look and occasionally a short jump, purely so
vanilla/plugin AFK-kick timers don't fire on a bot that would otherwise never send any input
at all. It doesn't walk anywhere or fight anything. Set `minecraft.antiAfk.enabled` to `false`
if you'd rather it stay perfectly still.

## 13. Troubleshooting

- **"DISCORD_TOKEN is not set"** → you forgot to `cp .env.example .env` and fill it in.
- **Bot doesn't respond to any `!` command** → check `discord.channels` IDs are right, the bot
  has *Message Content Intent* enabled (step 3.3), and your Discord user ID is in
  `discord.ownerIds`.
- **Stuck on "Microsoft sign-in required"** → the device code expires after a few minutes;
  just run `!login` again to get a fresh one.
- **Sign-in fails right after you enter the code** → a handful of specific, common causes:
  - **"Does this account own Minecraft?" / invalid credentials-style error** → the account
    you signed in with on Microsoft's page doesn't actually own a Minecraft Java license, or
    hasn't finished migrating from a legacy Mojang account. Double check you picked the right
    Microsoft account if you have more than one, and that it shows Minecraft under
    minecraft.net → your profile.
  - **Account needs Xbox Live / profile setup** → some Microsoft accounts that have never
    touched Xbox need to accept Xbox's terms once at
    [xbox.com](https://www.xbox.com) before external apps (including this bot) can get a
    token for them. Sign in there once, then try `!login` again.
  - **The VPS's network can't reach Microsoft's login servers** → some VPS providers/regions
    block or throttle `login.live.com` / `login.microsoftonline.com`. Test with
    `curl -I https://login.live.com` on the VPS - if that hangs or errors, it's a network/
    firewall issue on the VPS side, not the bot.
  - **You took too long** → the code in #mc-logs expires in a few minutes. `!login` again for
    a fresh one and go straight to the link.
  - Still stuck? Run `node src/index.js` directly (not via PM2/systemd) and paste the exact
    console output around the failure - `!start`'s Discord reply only shows a short message,
    but the full error with a stack trace always prints to the console now.
- **"not authenticated by minecraft.net" ever comes back** → almost always means
  `./mc-auth-cache/` got deleted or the account's refresh token was revoked (e.g. you changed
  the Microsoft account password). Run `!logout` then `!login` to redo it cleanly.
- **`windows.InventoryWindow is not a constructor` (or similar "X is not a constructor"
  errors on `!start`)** → this happens inside mineflayer's own startup code, before it even
  touches your server — it means the installed packages are mismatched/corrupted, not
  anything about your server config. Almost always caused by an old Node.js version on the
  VPS making npm silently install an outdated `mineflayer`. Fix:
  ```bash
  node -v                              # must be 22+; if not, redo README section 2
  rm -rf node_modules package-lock.json
  npm cache clean --force
  npm install
  npm ls mineflayer                    # should show 4.37.x or newer
  ```
  The bot now also checks your Node version on boot and fails with a clear message instead of
  a cryptic error if it's too old.
- **Version errors on connect** → see §4's note on `minecraft.version`; try `1.21.4` if the
  exact server version isn't supported by your installed mineflayer yet.
