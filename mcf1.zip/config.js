'use strict';

/**
 * Central configuration for the Mineflayer bot (bot.js)
 * and the Discord remote control script (discord_control.js).
 *
 * Fill in the values below before running anything.
 */
module.exports = {
  // ---------------- Minecraft connection ----------------
  host: 'play.example.net',        // Minecraft server hostname/IP
  port: 25565,                     // Minecraft server port
  username: 'you@example.com',     // Microsoft account email used for auth
  version: '1.21.1',               // Protocol version

  // ---------------- Navigation / world transition ----------------
  smpCommand: '/server smp',       // Command sent to leave the hub and join the SMP
  hubWaitDelay: 5000,              // ms to wait before sending smpCommand
  reconnectDelay: 15000,           // ms to wait before reconnecting after a dropped connection

  // Lowercase substrings checked against incoming chat/system messages to
  // detect that the bot has landed back in the network hub. Tune these to
  // match the exact wording your server uses.
  hubKeywords: ['kicked', 'hub'],

  // ---------------- Rendering ----------------
  viewDistance: 12,                // Requested client view distance, in chunks

  // ---------------- Auth token cache ----------------
  // Microsoft device-code auth tokens are cached here after the first
  // successful browser login, so subsequent runs won't need a browser.
  authCacheDir: './auth_cache',

  // ---------------- Discord remote control ----------------
  discordToken: 'YOUR_DISCORD_BOT_TOKEN',
  ownerDiscordId: 'YOUR_DISCORD_USER_ID',
};
