# Minecraft Mineflayer + Discord Manager

Files:
- `config.js` — all settings (host, port, username, commands, delays, Discord token/owner ID)
- `bot.js` — the Mineflayer bot
- `discord_control.js` — Discord.js manager (`!start` / `!stop` / `!status`, restricted to `ownerDiscordId`)
- `package.json` — dependencies

## 1. Install Node.js on the VPS

```bash
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs
node -v   # confirm v18+
```

## 2. Get the project onto the server and install dependencies

```bash
mkdir -p ~/mc-manager && cd ~/mc-manager
# copy config.js, bot.js, discord_control.js, package.json into this folder
npm install
```

## 3. Fill in `config.js`

Set `host`, `port`, `username` (your Microsoft account email), `smpCommand` if different,
`discordToken` (from the Discord Developer Portal), and `ownerDiscordId` (your Discord user ID).

## 4. Run the initial Microsoft authentication once, interactively

The first login needs a real browser, so do this manually before handing control to Discord/PM2:

```bash
node bot.js
```

Mineflayer will print a `https://microsoft.com/link` URL and a one-time code in the console.
Open that URL on any device, enter the code, and sign in with the Microsoft account tied to `username`.
Once you see `Bot spawned.` in the logs, stop it with `Ctrl+C` — the auth token is now cached in
`./auth_cache` (as set by `authCacheDir` in `config.js`) and future runs won't need a browser.

## 5. Install PM2 and run the Discord control process 24/7

`discord_control.js` is the process you keep alive with PM2 — it spawns/kills `bot.js` on demand,
so you don't run `bot.js` under PM2 directly.

```bash
sudo npm install -g pm2

# start it
pm2 start discord_control.js --name mc-manager

# make it survive reboots
pm2 startup
pm2 save
```

## 6. Day-to-day management

```bash
pm2 logs mc-manager      # tail logs (includes forwarded bot.js output)
pm2 restart mc-manager   # restart the Discord control process
pm2 stop mc-manager      # stop everything
```

In Discord, DM or message the bot (in a channel it can see) as the configured owner:
- `!start` — spawns the Mineflayer bot process
- `!stop` — sends SIGTERM (then SIGKILL after 10s if needed)
- `!status` — reports active/offline + PID

## Notes

- `config.js` contains secrets (Discord token). Don't commit it to a public repo; consider
  `chmod 600 config.js` or swapping to environment variables via `dotenv` if you prefer.
- `hubKeywords` and the dimension-change check in `bot.js` are heuristics — tune them to match
  your specific network's actual kick/transfer messages and dimension IDs.
- Double-check your target server's rules on bots/automation before running this against it —
  some networks prohibit unattended clients even when using an official account.
