'use strict';

const path = require('path');
const { spawn } = require('child_process');
const { Client, GatewayIntentBits, Partials } = require('discord.js');
const config = require('./config');

const BOT_SCRIPT = path.join(__dirname, 'bot.js');

let botProcess = null;

function log(msg) {
  console.log(`[${new Date().toISOString()}] [discord_control] ${msg}`);
}

function startBot(reply) {
  if (botProcess) {
    reply('⚠️ Bot process is already running.');
    return;
  }

  log('Starting Mineflayer bot process...');
  botProcess = spawn(process.execPath, [BOT_SCRIPT], {
    cwd: __dirname,
    stdio: ['ignore', 'pipe', 'pipe'],
  });

  botProcess.stdout.on('data', (data) => {
    process.stdout.write(`[bot.js] ${data}`);
  });
  botProcess.stderr.on('data', (data) => {
    process.stderr.write(`[bot.js ERROR] ${data}`);
  });

  botProcess.on('exit', (code, signal) => {
    log(`Bot process exited (code=${code}, signal=${signal}).`);
    botProcess = null;
  });
  botProcess.on('error', (err) => {
    log(`Failed to start bot process: ${err.message}`);
    botProcess = null;
  });

  reply('✅ Mineflayer bot process started.');
}

function stopBot(reply) {
  if (!botProcess) {
    reply('⚠️ Bot process is not running.');
    return;
  }

  log('Stopping Mineflayer bot process...');
  const pid = botProcess.pid;
  botProcess.kill('SIGTERM');

  // Force kill if it hasn't exited after 10s.
  setTimeout(() => {
    if (botProcess && botProcess.pid === pid) {
      log('Bot process did not exit cleanly, sending SIGKILL...');
      botProcess.kill('SIGKILL');
    }
  }, 10000);

  reply('🛑 Stop signal sent to bot process.');
}

function statusBot(reply) {
  if (botProcess) {
    reply(`🟢 Bot process is **active** (PID ${botProcess.pid}).`);
  } else {
    reply('🔴 Bot process is **offline**.');
  }
}

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.DirectMessages,
  ],
  partials: [Partials.Channel],
});

client.once('ready', () => {
  log(`Logged in as ${client.user.tag}.`);
});

client.on('messageCreate', (message) => {
  if (message.author.bot) return;
  if (!message.content.startsWith('!')) return;

  // Hard restriction: only the configured owner can issue commands.
  if (message.author.id !== config.ownerDiscordId) return;

  const command = message.content.trim().toLowerCase();
  const reply = (text) => message.reply(text).catch((err) => log(`Reply failed: ${err.message}`));

  switch (command) {
    case '!start':
      startBot(reply);
      break;
    case '!stop':
      stopBot(reply);
      break;
    case '!status':
      statusBot(reply);
      break;
    default:
      break;
  }
});

client.login(config.discordToken);

function shutdown() {
  if (botProcess) botProcess.kill('SIGTERM');
  process.exit(0);
}
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);
