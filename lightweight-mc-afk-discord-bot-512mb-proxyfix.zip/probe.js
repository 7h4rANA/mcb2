require('dotenv').config();
const mineflayer = require('mineflayer');
const path = require('node:path');
const { Titles } = require('prismarine-auth');
const bot = mineflayer.createBot({
  host: process.env.MC_HOST,
  port: Number(process.env.MC_PORT || 25565),
  username: process.env.MC_EMAIL,
  auth: 'microsoft',
  profilesFolder: path.join(__dirname, 'auth-cache'),
  version: process.env.MC_VERSION || false,
  authTitle: Titles.MinecraftNintendoSwitch,
  deviceType: 'Nintendo',
  hideErrors: false,
  connectTimeout: 90000
});
console.log('[PROBE] connecting...');
bot._client.on('connect', () => console.log('[PROBE] tcp connected'));
bot._client.on('state', s => console.log('[PROBE] state', s));
bot._client.on('packet', (_d,m) => { if (['disconnect','kick_disconnect','login','login_success','configuration_start','finish_configuration','join_game'].includes(m?.name)) console.log('[PROBE] packet',m.name); });
bot._client.on('disconnect', r => console.log('[PROBE] protocol disconnect', JSON.stringify(r)));
bot.once('login', () => console.log('[PROBE] MINEFLAYER LOGIN', bot.username));
bot.once('spawn', () => { console.log('[PROBE] SPAWN'); setTimeout(() => bot.quit('probe done'), 5000); });
bot.on('kicked', r => console.log('[PROBE] KICK', JSON.stringify(r)));
bot.on('error', e => console.log('[PROBE] ERROR', e));
bot.on('end', r => { console.log('[PROBE] END', JSON.stringify(r)); process.exit(0); });
