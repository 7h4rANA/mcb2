# Ultra-Light Minecraft AFK + Discord Controller v3 — Proxy/Handshake Fix

Designed for a **512 MB / 1 vCPU Linux VPS** running one Microsoft-authenticated Minecraft Java account. The goal is to keep the bot itself small while retaining normal Minecraft physics and a 3-chunk client view distance (7x7 target).

## What changed for 512 MB

- Discord.js cache limits are aggressively reduced; messages, reactions, members, presence, voice states and threads are not retained.
- The three Discord channels are fetched once instead of repeatedly resolving channel IDs.
- No Discord embeds, HTTP dashboard, database, browser, viewer, pathfinder, PvP or anti-AFK loop.
- Only one Minecraft client is created at a time.
- Reconnects use exponential backoff and a per-hour cap so a broken proxy cannot create a reconnect storm.
- Event listeners that only need to happen once (`login`, `spawn`, `kicked`, `error`, `end`) use one-shot listeners.
- Local logging is tiny and only one file is used.
- Runtime config is a small JSON file.
- The systemd example caps V8 heap at 160 MB and adds a service memory guard.

## Important: 512 MB is tight

A 512 MB VPS means the **entire machine/container** needs RAM for the OS, SSH, systemd, Node/V8, Discord connection, Mineflayer, protocol buffers and Minecraft chunk data. `--max-old-space-size=160` is deliberately conservative, but it is not an absolute RSS cap.

If your provider/container has **no swap and a very small RAM limit**, Mineflayer can still be killed when the Minecraft world/chunk state grows. For this reason, use a minimal Linux image and no other services on the VPS.

Do not run a Minecraft server on the same 512 MB VPS.

## 7x7 chunks

`VIEW_DISTANCE=3` requests a 3-chunk radius, i.e. a **7x7 target area (49 chunks)**. The actual streamed area is also constrained by the server/proxy's view distance and chunk sending behavior.

Do not increase it on a 512 MB / 1 vCPU VPS.

## Install

Recommended Node.js: **Node 24 LTS**.

```bash
sudo apt update
sudo apt install -y ca-certificates curl unzip
node -v
npm -v
mkdir -p ~/mc-bot
cd ~/mc-bot
unzip lightweight-mc-afk-discord-bot.zip
npm ci --omit=dev
cp .env.example .env
nano .env
chmod 600 .env
chmod 700 auth-cache logs
```

## Discord

Create a Discord application/bot and enable **Message Content Intent**. Give it only:

- View Channels
- Send Messages
- Embed Links (not actually required by v2, but harmless)
- Read Message History

Put the bot token, your Discord user ID, and the three channel IDs in `.env`.

No webhooks are used.

## Microsoft authentication

Put the Microsoft email in `MC_EMAIL`. Do not put the Microsoft password in `.env`.

On the first run, Mineflayer's Microsoft device-code flow will ask you to authenticate. The token cache is stored in `auth-cache/` and should never be shared.

## Proxy

Set `MC_HOST` and `MC_PORT` to the same public address players use through **FlameCord/Papyrus**. Do not expose or use a backend Paper server address if the proxy is the intended entry point.

The bot uses normal Minecraft protocol behavior. There is no special DDoS-bypass or proxy manipulation code.

## Start manually first

Do this before systemd:

```bash
cd ~/mc-bot
NODE_OPTIONS='--max-old-space-size=160' UV_THREADPOOL_SIZE=1 npm start
```

Complete Microsoft login. Watch memory in another SSH session:

```bash
ps -o pid,rss,vsz,cmd -C node
free -h
```

If this works and stays comfortably below your VPS limit, install systemd.

## 24/7 systemd

Copy `mc-bot.service.example` to `/etc/systemd/system/mc-bot.service`, replace `YOUR_LINUX_USER`, then:

```bash
sudo systemctl daemon-reload
sudo systemctl enable --now mc-bot
journalctl -u mc-bot -f
```

The service automatically restarts after a process crash. It does **not** add any artificial Minecraft movement.

## Discord commands

```text
!start
!stop
!status
!chat hello
!cmd balance
!config
!config viewDistance 3
```

Only IDs in `OWNER_USER_IDS` can use these commands.

`!stop` intentionally disconnects the Minecraft account so you can log in yourself. It also disables automatic reconnect until `!start` is used.

## Hub -> SMP

After the first Minecraft spawn, the bot waits `HUB_WAIT_MS` and sends `/smp`.

It considers the transfer confirmed when a configured SMP phrase appears or the proxy/server sends a post-transfer respawn event.

If your network uses different messages, change `SMP_SUCCESS_PATTERNS` and `HUB_SUCCESS_PATTERNS` in `.env` and restart.

## Chat and alerts

Normal Minecraft chat is forwarded to `CHAT_CHANNEL_ID`.

Messages containing the bot's username and private-message formats such as `/tell`, `/msg`, `/w`, `whisper`, `-> you` and `to you:` are highlighted. Alerts are cooldown-limited so chat spam does not create a Discord API flood.

## Knockback

`physicsEnabled=true` remains enabled. The bot does not inject movement or anti-AFK behavior. Server velocity packets are allowed to go through Mineflayer's normal physics implementation.

For Minecraft 1.21.11, test knockback on your exact server before depending on it for a farm; Mineflayer has had upstream 1.21.11 physics reports.

## Why this is safer on 512 MB

Do not install any of these into the same Node project:

- prismarine-viewer
- mineflayer-pathfinder
- mineflayer-pvp
- puppeteer / Chromium
- Express dashboard
- SQLite/Redis
- extra Minecraft bots
- large Discord logging/cache plugins

Also do not run npm development tools, compilers or multiple Node processes on the VPS.

## Optional swap

If your VPS provider permits swap, a small **512 MB to 1 GB swapfile** can prevent a transient allocation from immediately killing Node. Swap is a safety net, not extra performance; Minecraft networking should remain in RAM.

Example on a normal Ubuntu/Debian VPS:

```bash
sudo fallocate -l 512M /swapfile
sudo chmod 600 /swapfile
sudo mkswap /swapfile
sudo swapon /swapfile
free -h
```

Check your provider's terms first. Some containers/VPS products do not permit guest swap.

## If the VPS still crashes

Run:

```bash
free -h
journalctl -k --no-pager | tail -100
journalctl -u mc-bot --no-pager | tail -200
```

If you see `Out of memory`, `oom-kill`, `Killed process node`, or a provider memory-limit event, the VPS is exhausting its total memory rather than simply having a JavaScript exception.

At that point the reliable choices are:

1. Add permitted swap.
2. Move to 768 MB/1 GB RAM.
3. Reduce Minecraft view distance below 3 (but that breaks the requested 7x7 target).
4. Remove other services from the VPS.

## Performance philosophy

This version intentionally does **less**, not more. A one-vCPU VPS should spend CPU on the Minecraft protocol/physics and Discord Gateway, not on dashboards, pathfinding, rendering, databases or artificial movement.


# IMPORTANT: Fix for "Not authenticated with Minecraft.net" / Papyrus Slow Down

If you previously used an older build of this bot and saw:

```text
Not authenticated with Minecraft.net
```

follow these steps before testing the new build.

## 1. Stop every old copy of the bot

Do not run two copies of the controller or two Minecraft connections using the same account. On the VPS:

```bash
sudo systemctl stop mc-afk-bot 2>/dev/null || true
pkill -f "node.*src/index.js" 2>/dev/null || true
```

Then wait at least one minute before starting again. This matters because Papyrus can temporarily rate-limit repeated connection attempts.

## 2. The bot must complete Microsoft device authentication

Logging into the same Microsoft account in the normal Minecraft Launcher does **not** authenticate the Mineflayer process. Mineflayer's Microsoft flow needs its own Microsoft/Xbox/Minecraft Java session and caches that session locally. The official Mineflayer documentation requires `auth: 'microsoft'`; with Microsoft authentication, the library obtains and caches authentication tokens for later connections. citeturn633897search0turn633897search4

Start the bot manually from SSH the first time:

```bash
cd ~/mc-bot
NODE_OPTIONS="--max-old-space-size=160" UV_THREADPOOL_SIZE=1 npm start
```

Watch the terminal. If Microsoft authentication is required, the bot prints a device-login URL and code. Open that URL on your normal PC/phone, enter the code, and sign into the **Microsoft account that owns Minecraft Java Edition**.

The bot now performs an explicit Minecraft Java authentication preflight using `prismarine-auth` before Mineflayer connects. The preflight requests the Minecraft Java token and profile; this is specifically intended to catch a stale/broken cached session before Papyrus sees the connection. The authentication library supports cached tokens and a `forceRefresh` option. citeturn267513search1turn267513search2

## 3. If the cache is stale, remove only the bot's auth cache

Stop the bot first, then:

```bash
rm -rf ~/mc-bot/auth-cache
mkdir -m 700 ~/mc-bot/auth-cache
```

Start it again:

```bash
cd ~/mc-bot
NODE_OPTIONS="--max-old-space-size=160" UV_THREADPOOL_SIZE=1 npm start
```

You should get a fresh Microsoft device-code login. Do not delete the entire bot directory.

## 4. Expected successful startup

A healthy first connection should look roughly like:

```text
[INFO] Controller online; ... Microsoft auth preflight enabled.
[INFO] Microsoft session valid for YOUR_NAME (...)
[INFO] Connecting play.example.com:25565
[INFO] Minecraft login as YOUR_NAME
[INFO] Spawned as YOUR_NAME. Physics enabled; view distance 3.
[INFO] Sent /smp
[INFO] SMP ready (...)
```

The exact text can differ between versions.

## 5. Why the previous logs looped

Your previous sequence was effectively:

```text
connect
  -> Papyrus
  -> authentication rejected
  -> reconnect after ~13s
  -> authentication rejected
  -> reconnect after ~20s
  -> Papyrus "Slow down"
```

That is exactly the wrong pattern for a protected proxy. The revised controller changes this behavior:

```text
authentication kick
  -> refresh Microsoft/Minecraft token
  -> wait
  -> reconnect

Papyrus "Slow down"
  -> wait at least 60 seconds
  -> reconnect
```

It also limits reconnect attempts per hour and avoids spawning duplicate connection attempts.

## 6. If Papyrus still says "Not authenticated with Minecraft.net"

Run this and paste the output from the terminal (do not paste tokens or the contents of `auth-cache`):

```bash
cd ~/mc-bot
NODE_OPTIONS="--max-old-space-size=160" UV_THREADPOOL_SIZE=1 npm start
```

The new build should first report either:

```text
Microsoft session valid for <name>
```

or an authentication error.

If it says the session is valid but Papyrus still immediately replies `Not authenticated with Minecraft.net`, that strongly points to a proxy/server-side authentication compatibility problem rather than the Microsoft login itself. At that point do **not** keep restarting the bot repeatedly; leave it stopped for a few minutes so Papyrus's rate limiter can clear.

## 7. Check the account

The account in `.env` must be the actual Microsoft email used by the Minecraft Java account:

```env
MC_EMAIL=your-microsoft-email@example.com
```

Mineflayer's documentation specifically notes that the email supplied as `username` must be usable with the **Login with Microsoft** flow and that `auth: 'microsoft'` must be set. citeturn633897search0

Do not put your Microsoft password in `.env`.

# Recommended first test

For your 512 MB / 1 vCPU VPS, do the first authentication test manually rather than with systemd:

```bash
cd ~/mc-bot
npm install --omit=dev
NODE_OPTIONS="--max-old-space-size=160" UV_THREADPOOL_SIZE=1 npm start
```

Once you see `Microsoft session valid` and a successful SMP connection, stop it with `Ctrl+C` and then enable systemd:

```bash
sudo systemctl daemon-reload
sudo systemctl enable mc-afk-bot
sudo systemctl start mc-afk-bot
```

The service intentionally starts more slowly than the previous build and allows the auth cache, logs, and runtime configuration file to be writable while keeping the rest of the home directory protected.


# v3 Proxy/Handshake Fix

If v2 successfully validated Microsoft authentication but immediately reported:

```text
Connection ended: unknown
```

this build changes the Minecraft connection path in three important ways:

1. Mineflayer is the **only** component that owns the Microsoft login/session. The separate authentication preflight was removed.
2. `MC_VERSION` is **empty by default**, which lets minecraft-protocol auto-detect the protocol advertised by the public proxy instead of forcing 1.21.11 during the initial connection.
3. Low-level protocol state and only handshake/termination packet names are logged, without dumping packet contents.

This matters on proxy networks because the connection is ending before Mineflayer reaches the normal `login`/`spawn` events. Mineflayer's own documentation recommends `auth: 'microsoft'` and notes that the server version can be guessed automatically when `version` is not specified.

## Recommended `.env` for HungryBirds

```env
MC_HOST=mc.hungrybirds.xyz
MC_PORT=25565
MC_EMAIL=your-microsoft-account@example.com
MC_VERSION=
VIEW_DISTANCE=3
```

Leave `MC_VERSION` blank for the first test. Once the bot works reliably, you may set it explicitly to `1.21.11` if you need to, but automatic protocol detection is safer for a proxy/front door.

## First test

Do not use `!start` repeatedly. Stop the old service, wait for Papyrus to cool down, then run: \n
```bash
cd ~/mc-bot
NODE_OPTIONS="--max-old-space-size=160" UV_THREADPOOL_SIZE=1 npm start
```

You want to see a sequence similar to:

```text
Connecting mc.hungrybirds.xyz:25565
TCP connection established.
Protocol state: login
...
Minecraft login as Kakashi_lite
Spawned as Kakashi_lite
```

If it still ends immediately, the important lines are the **last protocol state / packet** before `Connection ended`. That tells us whether the connection died during login, configuration, or before Minecraft sent any handshake packet.

## What the old log means

Your previous log:

```text
Microsoft session valid for Kakashi_lite
Connecting mc.hungrybirds.xyz:25565
Connection ended: unknown
```

proves that Microsoft authentication was succeeding before the network connection was attempted. It does **not** prove that the second Mineflayer-created auth/session was the same valid session. v3 removes that duplicate preflight and lets Mineflayer use one cached Microsoft auth flow.

## Upstream compatibility note

Mineflayer added Minecraft 1.21.11 support in its 4.35.0 release, and there are open/closed upstream reports involving 1.21.11 proxy/server-transfer compatibility. Therefore, if v3 still closes before `spawn`, the next step is to inspect the exact protocol packet/state or test the same public address with a minimal Mineflayer-only script; it would not be honest to call that a confirmed Papyrus bug without that evidence.
