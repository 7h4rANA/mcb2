class Logger {
  constructor() {
    this._relay = null;
  }

  // discordBot.js calls this once to receive a copy of every log line.
  setRelay(fn) {
    this._relay = fn;
  }

  log(line) {
    const ts = new Date().toISOString().split('T')[1].split('.')[0];
    console.log(`[${ts}] ${line}`);
    if (this._relay) {
      try {
        this._relay(line);
      } catch {
        // never let a relay failure take down the process
      }
    }
  }
}

// Singleton - every module requiring this file shares the same instance/relay.
module.exports = new Logger();
