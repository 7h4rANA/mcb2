# Minecraft AFK Bot + Discord Controller

A single Node.js process that runs a Minecraft bot (Microsoft account login, real
player physics) and a Discord bot side by side in the same process, so they stay
perfectly in sync with no IPC/sockets/extra RAM overhead. Built to run comfortably
on a 750MB Ubuntu VPS.

## Changelog (latest fixes)

- **General Vulcan alert detection now also matches "ANTI CHEAT" branding**
  (plus `Anti-Cheat`, `AntiCheat`, any spacing/hyphenation/case), alongside
  the original `[Vulcan]` tag - some servers customize Vulcan's in-chat
  prefix. Ghost-block detection was never affected by this, since its real
  pattern never depended on the word "vulcan". The alerts-channel embed
  title for general alerts is now "Anti-cheat alert" to match.

- **Ghost-block detection updated to the real observed format:**
  `PlayerName's position was updated for being on a ghost block! (world x: ..
  y: .. z: ..)`, set as the primary pattern (old generic guesses kept as
  fallback).
- **New: `!allalerts` command** - toggles every OTHER Vulcan alert
  (Scaffold, Speed, Reach, etc), independent from `!alerts` (ghost-block
  only). Default: `!alerts` ON, `!allalerts` OFF. A ghost-block message is
  always handled by its own richer embed and never also duplicated as a
  generic Vulcan alert, regardless of `!allalerts`.
- **`!alerts` and `!allalerts` now both reply with the status of both
  toggles**, not just the one that was flipped.
- General Vulcan alerts use the same clickable-author-link + timestamp style
  as ghost-block alerts, with their own independent per-player cooldown.

## Changelog (previous fixes)

- **New: dedicated channels.** `MENTIONS_CHANNEL_ID` for in-game mentions and
  `/tell`/`/msg` alerts, `ALERTS_CHANNEL_ID` for ghost-block/Vulcan alerts
  only. Commands (`!chat`, `!cmd`, etc) now also work in
  `MENTIONS_CHANNEL_ID`, not just `COMMAND_CHANNEL_ID`. Both are optional and
  fall back to `COMMAND_CHANNEL_ID` if unset.
- **New: ghost-block/Vulcan detection + `!alerts` toggle.** Detects a
  position-correction/anti-cheat alert in chat, extracts the player and
  coordinates where possible (falling back to the bot's own tracked position
  for that player if the message doesn't include coordinates), and posts an
  embed to `ALERTS_CHANNEL_ID` - player name as a clickable link with their
  skin-face icon, coordinates in a copy-friendly code block, the full raw
  message, and a timestamp. Same-player alerts are throttled to one every
  `cooldownMs` (10s default) to avoid flooding the channel. `!alerts` toggles
  this on/off (see the newer entry above for the current reply format).
- **All alert embeds now carry a timestamp** for an audit trail.

- **Restart/limbo-check kicks now get a longer first retry.** When a
  disconnect reason matches "restarting" or "limbo" (`config.js` →
  `detection.restarting`), the bot waits `server.restartGraceMs` (45s by
  default) before its first reconnect attempt instead of jumping straight
  into the normal backoff - retrying immediately during a server restart was
  just hitting `ECONNREFUSED` or failing the anti-bot limbo check anyway.
- **Real ping on servers that placeholder the tab list.** Some networks show
  0ms (or another placeholder) for everyone in the tab list and put the real,
  live ping in the sidebar scoreboard instead. `!status` now checks the
  sidebar scoreboard first and falls back to the tab list value. This is a
  pure on-demand read - no background listener, no polling loop, no extra
  retained state - it only looks at data mineflayer already keeps internally,
  and only at the moment `!status` is actually run, so it adds no RAM
  overhead. Wording varies by server - see `config.js` → `detection.pingScoreboard`.
- **`/tell` and `/msg` alerts now render as `[player]->me : message`** in the
  embed, matching the requested format exactly.
- **Mention alerts are back to plain Discord messages** (not embeds) - only
  `/tell`/`/msg` use the embed format above; queue/offline alerts are
  unchanged (still embeds).

- **Knockback wasn't applying at all.** mineflayer's built-in handling of the
  server's velocity packet for the bot's own entity is inconsistent across
  protocol versions. Fixed by listening to the raw `entity_velocity` packet
  directly and applying it to the bot's entity every time, independent of
  mineflayer's internal handling.
- **`!status` always showed "hub" even on smp.** The old code decided "which
  server am I on" purely by matching chat text, which never matched this
  network's actual wording. Rewrote it to use the game's respawn event
  instead - every proxy server switch (hub→smp, smp→hub, etc) triggers a full
  respawn client-side, which is a reliable protocol-level signal that works
  regardless of what any specific network's plugins print to chat.
- **Raw JSON walls in the disconnect logs** (e.g. `{"type":"compound",...}`)
  are now flattened into the actual readable kick message (e.g. "You failed
  the limbo check!"). Some servers/protocol versions encode disconnect
  reasons as NBT-typed data instead of plain chat JSON; the old code just
  dumped it with `JSON.stringify`.
- **Reconnects now use exponential backoff with jitter** instead of a fixed
  10s interval. A fixed interval both burns through the attempt limit fast
  during a multi-minute server restart, and reconnecting on a perfectly
  regular clock is exactly the kind of pattern anti-bot "limbo" checks flag -
  which lines up with the `"You failed the limbo check!"` kick some of you
  hit mid-reconnect. Attempts now start at `fullDisconnectRetryDelayMs` and
  grow by `reconnectBackoffFactor` up to `maxReconnectDelayMs`, with ±15%
  randomization, and `maxReconnectAttempts` was raised to give longer
  restarts more headroom.
- **Added a minimum gap between join commands** so a retry can never fire
  close enough to a previous one to trigger a "chatting too fast" kick.
- **Join command changed to `/joinqueue smp`**, and `hubWaitMs` /
  `kickToHubRetryDelayMs` are now `10000`ms.
- **Discord presence** now shows a live `🟢`/`🔴` + the server address instead
  of a static "Playing !status", updating automatically whenever the
  connection state changes.
- **`!status` now shows RAM usage.** Since Discord and Minecraft run in one
  shared process, there's no real way to split "Discord bot RAM" from
  "Minecraft bot RAM" - they're the same process. It shows that combined
  process figure plus the actual VPS-wide used/total (read from the OS, not
  hardcoded).
- **New: `/tell` and `/msg` alerts.** A private message sent to you in-game
  now posts an embed to Discord with the sender's name and message. Like
  queue/offline detection, the exact wording varies by server - see
  `config.js` → `detection.tell` and the tuning section below.
- **All push alerts (mention, tell, queue, offline) now use embeds** instead
  of plain text.

## Architecture (why it's built this way)

- **One process, not two.** Running the Discord bot and the Minecraft bot as
  separate processes would mean setting up IPC (a socket, a file, a queue) just so
  they can talk to each other, and paying for two Node runtimes in RAM. Instead,
  `src/index.js` starts both in the same process and they talk directly through
  function calls and a shared `state.js` + event emitter. This is the "sync"
  between them: Discord commands call straight into the Minecraft controller, and
  the Minecraft controller emits events (`log`, `joinedSmp`, `queue`, `offline`,
  `mention`) that the Discord side listens to and relays.
- **The Discord bot never goes down when the Minecraft bot does.** Minecraft
  connection errors are caught and turned into log lines / reconnect logic, not
  thrown - so a server restart or a bad kick on the MC side never kills your
  Discord connection. `!status` will happily tell you the MC bot is offline.
- **No pathfinding library.** Server-to-server travel on your network happens via
  proxy commands (`/smp`, `/hub-01`, ...), not by physically walking, so
  `mineflayer-pathfinder` isn't included - one less (fairly heavy) dependency.
- **No native modules.** `.npmrc` skips optional native add-ons (`bufferutil`,
  `utf-8-validate`, `zlib-sync`) that `discord.js`/`ws` can use for a small speed
  boost. Skipping them means you don't need `build-essential`/`gcc` on the VPS at
  all, and there's nothing to fail to compile. The pure-JS fallbacks are plenty
  fast for a single-bot controller.

## What you get

```
mc-discord-controller/
├── config.js                  # tunable behavior (view distance, zones, regex, delays)
├── .env.example                # copy to .env - secrets & IDs
├── package.json
├── .npmrc
├── deploy/
│   └── mc-controller.service  # systemd unit for always-on deployment
└── src/
    ├── index.js                # entry point / wiring / shutdown
    ├── discordBot.js           # commands, status embed, log relay
    ├── minecraftBot.js         # mineflayer connection, join/queue/kick logic
    ├── state.js                 # shared state both bots read/write
    ├── logger.js
    └── utils.js
```

## 1. Server prerequisites (do this once)

SSH into your VPS as a sudo-capable user.

```bash
sudo apt update && sudo apt upgrade -y
```

**Add swap.** A 750MB box has very little headroom - a 1GB swapfile is cheap
insurance against the OOM killer taking down the process during a GC spike or a
temporary memory blip, at the cost of some disk I/O if it's ever actually used:

```bash
sudo fallocate -l 1G /swapfile
sudo chmod 600 /swapfile
sudo mkswap /swapfile
sudo swapon /swapfile
echo '/swapfile none swap sw 0 0' | sudo tee -a /etc/fstab
```

**Install Node.js 20 LTS** (via NodeSource - avoids compiling anything):

```bash
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs
node -v   # should print v20.x
```

**Create a dedicated user** to run the bot (good practice, keeps it isolated):

```bash
sudo adduser --disabled-password --gecos "" mcbot
sudo su - mcbot
```

## 2. Get the files onto the VPS

Upload this whole folder to `/home/mcbot/mc-discord-controller` (via `scp`,
`rsync`, or `git clone` if you've pushed it to your own repo), then:

```bash
cd /home/mcbot/mc-discord-controller
npm install --omit=dev
```

This pulls in `discord.js`, `mineflayer`, and `dotenv` only (plus their required
sub-dependencies like `prismarine-auth` for Microsoft login). No `pathfinder`, no
viewer, no build tools required.

## 3. Create your Discord application

1. Go to https://discord.com/developers/applications → **New Application**.
2. **Bot** tab → **Add Bot**. Copy the token → this is your `DISCORD_TOKEN`.
3. Still on the **Bot** tab, scroll to **Privileged Gateway Intents** and enable
   **MESSAGE CONTENT INTENT**. This is required or the bot will receive empty
   message content and every command will silently fail to parse - it's the
   single most common "why isn't my bot responding" bug, so don't skip it.
4. **OAuth2 → URL Generator**: scope `bot`, permissions `Send Messages`,
   `Embed Links`, `Read Message History`, `Add Reactions`. Open the generated
   URL and invite the bot to your server.
5. In Discord, enable Developer Mode (User Settings → Advanced), then right
   click your target text channel → **Copy Channel ID** (`COMMAND_CHANNEL_ID`),
   and right click your own name → **Copy User ID** (`OWNER_ID`).

## 4. Configure

```bash
cp .env.example .env
nano .env
```

Fill in `DISCORD_TOKEN`, `OWNER_ID`, `COMMAND_CHANNEL_ID`, `MC_HOST`, `MC_PORT`,
`MC_EMAIL`. Leave `MC_VERSION` blank (auto-detect).

Open `config.js` and, at minimum, set `server.joinCommand` if your SMP isn't
literally `/smp`, and fill in `zones` with your farm/spawn coordinates if you
want `!status` to show a friendly zone name instead of just "Overworld".

## 5. First run (interactive - do this before installing the service)

The very first time you connect, Microsoft's device-code login flow needs to
happen, so run it in the foreground first where you can see the output:

```bash
npm start
```

Watch the console for a line like:

```
MICROSOFT LOGIN REQUIRED: To sign in, use a web browser to open the page
https://microsoft.com/link and enter the code ABCD-EFGH to authenticate.
```

(The same message is also relayed to your Discord log channel once the Discord
side is connected, in case you're not watching the terminal.) Open that URL on
**any** device, enter the code, and log in with the Microsoft account tied to
the Minecraft profile you want the bot to use. This only needs to happen once -
after a successful login, tokens are cached in `./mc-auth-cache/` and reused on
future starts (until they eventually expire, at which point you'll be asked to
repeat this step).

**`mc-auth-cache/` is sensitive** - treat it like a password file. It's already
excluded via `.gitignore`; don't upload it anywhere public.

Once you see `Discord bot logged in as ...` in the console, go to your
`COMMAND_CHANNEL_ID` channel in Discord and try `!status`. Press `Ctrl+C` to
stop the foreground run once you've confirmed it works.

## 6. Install as a systemd service (always-on)

`!restart` and automatic crash-recovery both depend on the process being
managed by systemd with `Restart=always` - this isn't optional if you want
those to work.

```bash
exit   # back to your sudo user, out of the mcbot shell
sudo cp /home/mcbot/mc-discord-controller/deploy/mc-controller.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now mc-controller
sudo systemctl status mc-controller
```

View logs any time with:

```bash
journalctl -u mc-controller -f
```

## Commands

Commands work in `COMMAND_CHANNEL_ID` and, if set, `MENTIONS_CHANNEL_ID` -
so you can reply with `!chat`/`!cmd` right from the channel where you saw a
mention or `/tell`. They do **not** work in `ALERTS_CHANNEL_ID`, which is
output-only.

| Command | What it does |
|---|---|
| `!start` | Connects the Minecraft bot. Streams connect/join/queue logs to Discord. On success, posts a confirmation and automatically shows `!status`. |
| `!status` | Embed with in-game username, online/offline, ping (see note below), uptime, current backend server (hub/smp), world/zone, health, skin face, and RAM usage. |
| `!stop` | Disconnects the Minecraft bot cleanly so you can log in normally. |
| `!restart` | Stops everything and exits the process; systemd brings it back up. |
| `!cmd <command>` | Sends `/<command>` in-game (adds the leading `/` for you if you omit it) and replies with whatever the server sent back. E.g. `!cmd smp`, `!cmd hub-01`, `!cmd shards`, `!cmd balance`, `!cmd tell PlayerName hey`. |
| `!chat <message>` | Sends `<message>` as regular in-game chat, as you. |
| `!alerts` | Toggles ghost-block alerts on/off (default **ON**). |
| `!allalerts` | Toggles every OTHER Vulcan alert on/off (default **OFF**). |

Both `!alerts` and `!allalerts` reply with the status of **both** toggles,
e.g. `Ghost block alerts: ON | All Vulcan alerts: OFF` - so you always see
the full picture regardless of which one you just flipped.

## Channels

Besides `COMMAND_CHANNEL_ID`, three more channels are optional - each falls
back to `COMMAND_CHANNEL_ID` if left blank in `.env`:

- `LOG_CHANNEL_ID` - the batched technical log stream.
- `MENTIONS_CHANNEL_ID` - in-game mentions (plain text) and `/tell`/`/msg`
  alerts (embed, `[player]->me : message`). Commands also work here.
- `ALERTS_CHANNEL_ID` - ghost-block/Vulcan alerts **only**. Nothing else is
  ever routed here. Ghost-block alerts (`!alerts`, default ON) and every
  other Vulcan alert (`!allalerts`, default OFF) are independent toggles -
  a ghost-block message is always handled by its own richer alert (with
  coordinates) and is never also duplicated as a generic Vulcan alert, no
  matter how `!allalerts` is set.

Bonus behavior (no command needed):
- If someone's message in-game contains your username, it's relayed as a
  plain message to `MENTIONS_CHANNEL_ID`.
- A `/tell` or `/msg` sent to you in-game is relayed as an embed
  (`[player]->me : message`) to `MENTIONS_CHANNEL_ID`.
- A detected ghost-block alert is relayed as an embed - player name as a
  clickable link with their skin-face icon, coordinates, full raw message,
  and a timestamp - to `ALERTS_CHANNEL_ID`, as long as `!alerts` is ON. The
  default pattern matches the format `PlayerName's position was updated for
  being on a ghost block! (world x: .. y: .. z: ..)`; adjust in `config.js`
  → `detection.ghostBlock` if your server phrases it differently.
- Every other Vulcan alert is relayed the same way (without coordinates) to
  `ALERTS_CHANNEL_ID`, only while `!allalerts` is ON.
- Either alert type is throttled to one per player every `cooldownMs` (10s
  default, set separately for each type) even if the anti-cheat fires
  repeatedly.
- If the bot gets bounced from smp back to the hub, it waits
  `kickToHubRetryDelayMs` and automatically resends the join command.
- If the bot gets fully disconnected from the network, it waits and
  reconnects with exponential backoff (see the changelog above), then
  repeats the hub→smp join sequence - up to `maxReconnectAttempts` before
  giving up and waiting for a manual `!start`.

**Ping note:** if your server places a placeholder (e.g. 0ms) in the tab
list, `!status` automatically falls back to reading the real ping from the
sidebar scoreboard instead (see `config.js` → `detection.pingScoreboard`).

## Tuning the join/queue/offline/tell/ghost-block detection (important)

Every network words its queue/offline/tell/anti-cheat messages differently,
and there's no way to know your specific SMP's exact wording in advance.
`config.js`'s `detection` block ships with generic patterns as a starting
point - you should verify (and likely tweak) them:

1. Set `DEBUG_RAW_CHAT=true` in `.env`.
2. Restart the bot and run `!start`, watching the Discord log channel.
3. Note the exact text your server sends for: being queued, smp being
   offline, what a private message looks like (have someone send you
   `/tell YourName hi` or `/msg`), and - if you can trigger a test detection
   safely - what a Vulcan ghost-block/setback alert looks like.
4. Update `config.js` → `detection.queue` / `detection.offline` /
   `detection.tell` / `detection.ghostBlock` to match. `detection.tell`
   patterns need exactly two capture groups - `(sender name)` and
   `(message text)`. `detection.ghostBlock.player` needs one capture group
   (the player's name); `detection.ghostBlock.coords` needs three, in
   `x, y, z` order - either can be left unmatched and the alert still sends
   with whatever was found (falling back to "Unknown"/"Not available").
5. Set `DEBUG_RAW_CHAT=false` again once you're happy (it's noisy).

Note: `detection.joinedHub` / `detection.joinedSmp` do **not** need tuning -
they're only used for an extra confirmation line in the logs. Which server
you're actually on (shown in `!status`) is detected reliably via the game's
respawn event, not by guessing chat text - see the changelog above.

## Real physics, knockback, and the farm

The bot uses mineflayer's default physics simulation (gravity, collision, and
server-authoritative velocity packets), so it takes knockback and falls/collides
like a real client - nothing extra to configure there. The bot also never digs,
places, or interacts with blocks anywhere in this codebase; it only moves its
camera slightly for the anti-idle jiggle (position unchanged) and responds to
chat/commands. That's deliberate - it's the surest way to avoid ever disturbing
a bonemeal farm or triggering a "bugged" state, since the bot simply never
issues a block-interaction packet in the first place.

## Memory tuning notes

- `npm start` runs with `--max-old-space-size=256`, capping the V8 heap so a
  leak or a big GC spike can't eat the whole box; the systemd unit sets a hard
  `MemoryMax=400M` as a second line of defense.
- `viewDistance: 3` in `config.js` keeps mineflayer's chunk cache small
  (~7x7 chunks, the closest fit to "6x6" - view distance in Minecraft is a
  radius, so it's always an odd-numbered square). Raise it if you need the bot
  to see further; lower it for even less RAM.
- Discord.js caches are capped (`makeCache` limits + a message sweeper) so
  memory doesn't creep up over days of uptime.
- Logs to Discord are batched (max one message per 2 seconds) instead of one
  API call per line, which also happens to keep CPU/network usage low.

## Ping

Since both the VPS and the SMP are in Singapore, you shouldn't need to do
anything special - the connection is already about as short as it can be. No
extra tuning was added here; if you ever move the VPS or the server, latency is
mostly a function of that distance, not this code.

## Troubleshooting

| Symptom | Likely cause |
|---|---|
| Bot doesn't respond to any command | `MESSAGE CONTENT INTENT` not enabled in the Developer Portal (step 3.3), or `COMMAND_CHANNEL_ID` is wrong. |
| `Missing required .env value(s)` on start | One of `DISCORD_TOKEN`, `OWNER_ID`, `COMMAND_CHANNEL_ID`, `MC_HOST`, `MC_EMAIL` is empty in `.env`. |
| Stuck asking for Microsoft login every restart | The `mc-auth-cache/` folder got deleted or isn't writable by the `mcbot` user - check `ls -la mc-auth-cache`. |
| `!start` connects but never detects smp/queue/offline | The detection patterns in `config.js` don't match your server's actual wording - see the tuning section above. |
| `!restart` stops the bot and it never comes back | You're not running it via the systemd service (`Restart=always`) - see step 6. |
| Process gets killed under memory pressure | Confirm the swapfile is active (`swapon --show`), and that `MemoryMax` in the service file isn't set below `--max-old-space-size`. |

## A quick note on server rules

AFK/macro bots are against the rules on some servers and fine on others - it's
worth double-checking your SMP's rules before running this long-term, since
that's between you and the server, not something this code can know for you.

## Security

- `.env` and `mc-auth-cache/` contain real credentials/tokens - never commit or
  share them.
- Only `OWNER_ID` (plus anyone listed in `ALLOWED_USER_IDS`) can run commands;
  everyone else gets an "unauthorized" reply.
- Consider restricting the command channel to a private channel only you can
  see, as a second layer on top of the ID check.
