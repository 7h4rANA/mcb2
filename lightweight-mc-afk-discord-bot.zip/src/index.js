require('dotenv').config();

const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const mineflayer = require('mineflayer');
const {
  Client,
  GatewayIntentBits,
  Partials,
  ActivityType,
  EmbedBuilder
} = require('discord.js');

const ROOT = path.resolve(__dirname, '..');
const AUTH_DIR = path.join(ROOT, 'auth-cache');
const LOG_DIR = path.join(ROOT, 'logs');
const RUNTIME_CONFIG_FILE = path.join(ROOT, 'config.runtime.json');

fs.mkdirSync(AUTH_DIR, { recursive: true, mode: 0o700 });
fs.mkdirSync(LOG_DIR, { recursive: true, mode: 0o700 });

const env = (key, fallback = '') => {
  const v = process.env[key];
  return v === undefined || v === '' ? fallback : v;
};
const int = (key, fallback) => {
  const n = Number.parseInt(env(key, String(fallback)), 10);
  return Number.isFinite(n) ? n : fallback;
};
const list = (key) => env(key, '')
  .split(',')
  .map(s => s.trim())
  .filter(Boolean);

const config = {
  mc: {
    host: env('MC_HOST'),
    port: int('MC_PORT', 25565),
    version: env('MC_VERSION', '1.21.11'),
    email: env('MC_EMAIL'),
    viewDistance: int('VIEW_DISTANCE', 3),
    hubCommand: env('HUB_COMMAND', '/smp'),
    hubWaitMs: int('HUB_WAIT_MS', 4500),
    smpReadyTimeoutMs: int('SMP_READY_TIMEOUT_MS', 30000)
  },
  discord: {
    token: env('DISCORD_TOKEN'),
    owners: new Set(list('OWNER_USER_IDS')),
    logChannelId: env('LOG_CHANNEL_ID'),
    chatChannelId: env('CHAT_CHANNEL_ID'),
    reportChannelId: env('REPORT_CHANNEL_ID')
  },
  reconnect: {
    minMs: int('RECONNECT_MIN_MS', 5000),
    maxMs: int('RECONNECT_MAX_MS', 60000),
    maxPerHour: int('MAX_RECONNECTS_PER_HOUR', 30)
  },
  chatAlertCooldownMs: int('CHAT_ALERT_COOLDOWN_MS', 1500),
  commandOutputMs: int('COMMAND_OUTPUT_MS', 4000),
  dailyReportHour: int('DAILY_REPORT_HOUR', 23),
  dailyReportMinute: int('DAILY_REPORT_MINUTE', 59),
  logMaxChars: int('LOG_MAX_CHARS', 1800),
  smpSuccessPatterns: list('SMP_SUCCESS_PATTERNS'),
  hubSuccessPatterns: list('HUB_SUCCESS_PATTERNS')
};

if (!config.mc.host || !config.mc.email || !config.discord.token ||
    !config.discord.logChannelId || !config.discord.chatChannelId ||
    !config.discord.reportChannelId || config.discord.owners.size === 0) {
  console.error('Missing required .env values. Copy .env.example to .env and fill it in.');
  process.exit(1);
}

if (fs.existsSync(RUNTIME_CONFIG_FILE)) {
  try {
    const r = JSON.parse(fs.readFileSync(RUNTIME_CONFIG_FILE, 'utf8'));
    for (const k of ['viewDistance', 'hubWaitMs', 'smpReadyTimeoutMs',
      'chatAlertCooldownMs', 'commandOutputMs', 'logMaxChars']) {
      if (Number.isFinite(r[k])) {
        if (k === 'viewDistance') config.mc.viewDistance = Math.max(2, Math.min(6, r[k]));
        else config[k] = Math.max(250, Math.min(120000, r[k]));
      }
    }
  } catch (e) {
    console.warn('Could not load config.runtime.json:', e.message);
  }
}

const stats = {
  startedAt: Date.now(),
  connectedAt: 0,
  lastDisconnectAt: 0,
  reconnects: 0,
  kicks: 0,
  errors: 0,
  chats: 0,
  commands: 0,
  bytesInApprox: 0,
  lastKick: '',
  lastError: '',
  lastEvent: 'boot'
};

let bot = null;
let stopping = false;
let reconnectTimer = null;
let reconnectDelay = config.reconnect.minMs;
let reconnectWindowStart = Date.now();
let reconnectsThisHour = 0;
let hubTimer = null;
let smpTimer = null;
let smpRequested = false;
let smpConfirmed = false;
let lastChatAlertAt = 0;
let commandCollector = null;

const discord = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent
  ],
  partials: [Partials.Channel]
});

function nowIso() {
  return new Date().toISOString();
}

function uptime(ms = Date.now() - stats.startedAt) {
  const s = Math.floor(ms / 1000);
  const d = Math.floor(s / 86400);
  const h = Math.floor((s % 86400) / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  return `${d}d ${h}h ${m}m ${sec}s`;
}

function cleanText(value) {
  if (value === undefined || value === null) return '';
  if (typeof value === 'string') return value;
  try {
    if (value.text) return value.text;
    if (typeof value.toString === 'function') return value.toString();
    return JSON.stringify(value);
  } catch {
    return String(value);
  }
}

function trimDiscord(s) {
  s = String(s ?? '');
  if (s.length <= config.logMaxChars) return s;
  return s.slice(0, config.logMaxChars - 3) + '...';
}

async function send(channelId, content, extra = {}) {
  try {
    const channel = await discord.channels.fetch(channelId);
    if (!channel?.isTextBased()) return false;
    await channel.send({ content, ...extra, allowedMentions: { parse: [] } });
    return true;
  } catch (e) {
    console.error(`Discord send failed (${channelId}):`, e.message);
    return false;
  }
}

async function log(message, level = 'INFO') {
  const line = `[${nowIso()}] [${level}] ${message}`;
  console.log(line);
  try {
    fs.appendFileSync(
      path.join(LOG_DIR, 'bot.log'),
      line + os.EOL,
      { encoding: 'utf8' }
    );
  } catch {}
  await send(config.discord.logChannelId, `\`${level}\` ${trimDiscord(message)}`);
}

function setPresence(online) {
  if (!discord.user) return;
  const icon = online ? '🟢' : '🔴';
  const host = config.mc.host || 'Minecraft';
  discord.user.setPresence({
    status: online ? 'online' : 'idle',
    activities: [{ name: `${icon} ${host}`, type: ActivityType.Playing }]
  });
}

function saveRuntimeConfig() {
  const safe = {
    viewDistance: config.mc.viewDistance,
    hubWaitMs: config.mc.hubWaitMs,
    smpReadyTimeoutMs: config.mc.smpReadyTimeoutMs,
    chatAlertCooldownMs: config.chatAlertCooldownMs,
    commandOutputMs: config.commandOutputMs,
    logMaxChars: config.logMaxChars
  };
  fs.writeFileSync(RUNTIME_CONFIG_FILE, JSON.stringify(safe, null, 2));
}

function resetReconnectWindow() {
  if (Date.now() - reconnectWindowStart >= 3600000) {
    reconnectWindowStart = Date.now();
    reconnectsThisHour = 0;
  }
}

function scheduleReconnect(reason) {
  if (stopping || reconnectTimer) return;
  resetReconnectWindow();
  if (reconnectsThisHour >= config.reconnect.maxPerHour) {
    log(`Reconnect limit reached for the current hour. Last reason: ${reason}`, 'WARN');
    return;
  }

  const jitter = Math.floor(Math.random() * Math.min(2000, reconnectDelay * 0.2));
  const delay = Math.min(config.reconnect.maxMs, reconnectDelay + jitter);
  reconnectsThisHour++;
  stats.reconnects++;

  log(`Reconnecting in ${delay}ms: ${reason}`, 'WARN');
  reconnectTimer = setTimeout(() => {
    reconnectTimer = null;
    connectMinecraft();
  }, delay);

  reconnectDelay = Math.min(config.reconnect.maxMs, Math.floor(reconnectDelay * 1.8));
}

function clearMinecraftTimers() {
  if (hubTimer) clearTimeout(hubTimer);
  if (smpTimer) clearTimeout(smpTimer);
  hubTimer = null;
  smpTimer = null;
}

function destroyBot() {
  clearMinecraftTimers();
  if (commandCollector) {
    clearTimeout(commandCollector.timer);
    commandCollector = null;
  }
  if (bot) {
    try {
      bot.removeAllListeners();
      bot.quit('controller shutdown');
    } catch {}
    bot = null;
  }
  setPresence(false);
}

function messageMatches(text, patterns) {
  if (!patterns.length) return false;
  const lower = text.toLowerCase();
  return patterns.some(p => lower.includes(p.toLowerCase()));
}

function isPrivateMessage(text) {
  const lower = text.toLowerCase();
  return /(^|[\s<])(?:\/?tell|\/?msg|\/?w|whisper)(?:[\s>]|:)/i.test(text)
    || lower.includes(' whispers to you')
    || lower.includes('-> you')
    || lower.includes('to you:');
}

function scheduleSmpJoin() {
  if (!bot || stopping || smpRequested) return;
  smpRequested = true;
  log(`Hub detected. Waiting ${config.mc.hubWaitMs}ms before sending ${config.mc.hubCommand}`);
  hubTimer = setTimeout(() => {
    if (!bot || stopping) return;
    try {
      bot.chat(config.mc.hubCommand.startsWith('/') ? config.mc.hubCommand : `/${config.mc.hubCommand}`);
      stats.commands++;
      log(`Sent hub command: ${config.mc.hubCommand}`);
      smpTimer = setTimeout(() => {
        if (!smpConfirmed) {
          log(`SMP readiness timeout after ${config.mc.smpReadyTimeoutMs}ms`, 'WARN');
        }
      }, config.mc.smpReadyTimeoutMs);
    } catch (e) {
      stats.errors++;
      stats.lastError = e.message;
      log(`Failed to send SMP command: ${e.message}`, 'ERROR');
    }
  }, config.mc.hubWaitMs);
}

function confirmSmp(source) {
  if (!smpRequested || smpConfirmed) return;
  smpConfirmed = true;
  if (smpTimer) clearTimeout(smpTimer);
  smpTimer = null;
  log(`SMP appears ready (${source}).`);
}

function onMinecraftMessage(jsonMsg) {
  const text = cleanText(jsonMsg);
  if (!text) return;

  if (commandCollector) {
    commandCollector.lines.push(text);
  }

  if (messageMatches(text, config.smpSuccessPatterns)) confirmSmp('success phrase');
  if (messageMatches(text, config.hubSuccessPatterns) && !smpRequested) {
    scheduleSmpJoin();
  }

  const username = bot?.username || '';
  const mentioned = username && text.toLowerCase().includes(username.toLowerCase());
  const privateMsg = isPrivateMessage(text);

  if (mentioned || privateMsg) {
    const now = Date.now();
    if (now - lastChatAlertAt >= config.chatAlertCooldownMs) {
      lastChatAlertAt = now;
      send(config.discord.chatChannelId, `🚨 **Minecraft alert**\n\`\`\`\n${trimDiscord(text)}\n\`\`\``);
    }
  }
}

function connectMinecraft() {
  if (stopping) return;
  if (bot) return;

  stats.lastEvent = 'connecting';
  setPresence(false);
  clearMinecraftTimers();
  smpRequested = false;
  smpConfirmed = false;

  log(`Connecting to ${config.mc.host}:${config.mc.port} as ${config.mc.email}`);

  try {
    bot = mineflayer.createBot({
      host: config.mc.host,
      port: config.mc.port,
      username: config.mc.email,
      auth: 'microsoft',
      profilesFolder: AUTH_DIR,
      version: config.mc.version,
      viewDistance: config.mc.viewDistance,
      physicsEnabled: true,
      hideErrors: true
    });

    bot.on('login', () => {
      stats.lastEvent = 'login';
      log(`Minecraft login accepted as ${bot.username || 'unknown'}`);
    });

    bot.on('spawn', () => {
      stats.connectedAt = Date.now();
      stats.lastEvent = 'spawn';
      reconnectDelay = config.reconnect.minMs;
      setPresence(true);
      log(`Minecraft spawn: ${bot.username || 'unknown'} @ ${bot.entity?.position ? bot.entity.position.toString() : 'unknown'}`);

      // First spawn is treated as hub. A later respawn/position or success phrase confirms SMP.
      if (!smpRequested) scheduleSmpJoin();
      else confirmSmp('post-transfer spawn');
    });

    bot.on('respawn', () => {
      stats.lastEvent = 'respawn';
      if (smpRequested) confirmSmp('respawn event');
      log('Minecraft respawn/dimension transfer event received.');
    });

    bot.on('chat', (username, message) => {
      if (username === bot.username) return;
      stats.chats++;
      const line = `<${username}> ${message}`;
      send(config.discord.chatChannelId, `💬 ${trimDiscord(line)}`);

      const lower = message.toLowerCase();
      if (bot.username && lower.includes(bot.username.toLowerCase())) {
        const now = Date.now();
        if (now - lastChatAlertAt >= config.chatAlertCooldownMs) {
          lastChatAlertAt = now;
          send(config.discord.chatChannelId, `🔔 **Mention** <${username}> mentioned **${bot.username}**: ${trimDiscord(message)}`);
        }
      }
    });

    bot.on('message', onMinecraftMessage);

    // Mineflayer's physics layer processes normal server velocity/knockback packets.
    // This listener is telemetry only; it does not inject movement or anti-AFK behavior.
    bot._client.on('set_entity_velocity', packet => {
      if (bot?.entity && packet?.entityId === bot.entity.id) {
        const vx = Number(packet.velocityX ?? 0);
        const vy = Number(packet.velocityY ?? 0);
        const vz = Number(packet.velocityZ ?? 0);
        stats.lastEvent = `velocity ${vx},${vy},${vz}`;
      }
    });

    bot.on('kicked', reason => {
      stats.kicks++;
      stats.lastKick = cleanText(reason);
      stats.connectedAt = 0;
      stats.lastEvent = 'kicked';
      setPresence(false);
      log(`Minecraft kicked: ${trimDiscord(stats.lastKick)}`, 'WARN');
      if (!stopping) scheduleReconnect('kick');
    });

    bot.on('error', err => {
      stats.errors++;
      stats.lastError = err?.message || String(err);
      stats.lastEvent = 'error';
      log(`Minecraft error: ${trimDiscord(stats.lastError)}`, 'ERROR');
    });

    bot.on('end', reason => {
      stats.connectedAt = 0;
      stats.lastDisconnectAt = Date.now();
      stats.lastEvent = 'end';
      setPresence(false);
      log(`Minecraft connection ended: ${trimDiscord(reason || 'unknown')}`, 'WARN');
      bot = null;
      if (!stopping) scheduleReconnect('connection end');
    });
  } catch (e) {
    stats.errors++;
    stats.lastError = e.message;
    log(`Minecraft createBot failed: ${e.message}`, 'ERROR');
    bot = null;
    scheduleReconnect('createBot exception');
  }
}

function statusText() {
  const online = !!bot && !!stats.connectedAt;
  const connectedFor = online ? uptime(Date.now() - stats.connectedAt) : 'offline';
  const mem = process.memoryUsage();
  const pos = bot?.entity?.position ? bot.entity.position.floored().toString() : 'n/a';
  return [
    `**Minecraft:** ${online ? '🟢 ONLINE' : '🔴 OFFLINE'}`,
    `**Account:** ${bot?.username || config.mc.email}`,
    `**Server:** \`${config.mc.host}:${config.mc.port}\``,
    `**Version:** ${config.mc.version}`,
    `**View distance:** ${config.mc.viewDistance} (target 7x7 chunks)`,
    `**Uptime:** ${uptime()}`,
    `**MC session:** ${connectedFor}`,
    `**Position:** ${pos}`,
    `**Reconnects:** ${stats.reconnects}`,
    `**Kicks:** ${stats.kicks}`,
    `**Errors:** ${stats.errors}`,
    `**Chat seen:** ${stats.chats}`,
    `**Commands sent:** ${stats.commands}`,
    `**RSS:** ${(mem.rss / 1048576).toFixed(1)} MB`,
    `**Last event:** ${stats.lastEvent}`,
    stats.lastKick ? `**Last kick:** ${trimDiscord(stats.lastKick)}` : '',
    stats.lastError ? `**Last error:** ${trimDiscord(stats.lastError)}` : ''
  ].filter(Boolean).join('\n');
}

async function dailyReport() {
  const mem = process.memoryUsage();
  const embed = new EmbedBuilder()
    .setTitle('📊 Minecraft Bot Daily Performance')
    .setDescription(statusText())
    .addFields(
      { name: 'Node', value: process.version, inline: true },
      { name: 'Platform', value: `${process.platform}/${process.arch}`, inline: true },
      { name: 'Heap', value: `${(mem.heapUsed / 1048576).toFixed(1)} / ${(mem.heapTotal / 1048576).toFixed(1)} MB`, inline: true }
    )
    .setTimestamp();
  try {
    const channel = await discord.channels.fetch(config.discord.reportChannelId);
    if (channel?.isTextBased()) await channel.send({ embeds: [embed] });
  } catch (e) {
    console.error('Daily report failed:', e.message);
  }
}

function scheduleDailyReport() {
  const tick = () => {
    const now = new Date();
    const target = new Date(now);
    target.setHours(config.dailyReportHour, config.dailyReportMinute, 0, 0);
    if (target <= now) target.setDate(target.getDate() + 1);
    setTimeout(async () => {
      await dailyReport();
      tick();
    }, target - now);
  };
  tick();
}

const runtimeKeys = new Set([
  'viewDistance',
  'hubWaitMs',
  'smpReadyTimeoutMs',
  'chatAlertCooldownMs',
  'commandOutputMs',
  'logMaxChars'
]);

function setRuntime(key, rawValue) {
  if (!runtimeKeys.has(key)) return `Not allowed. Allowed: ${[...runtimeKeys].join(', ')}`;
  const n = Number(rawValue);
  if (!Number.isFinite(n)) return 'Value must be numeric.';

  if (key === 'viewDistance') config.mc.viewDistance = Math.max(2, Math.min(6, n));
  else if (key === 'hubWaitMs') config.mc.hubWaitMs = Math.max(1000, Math.min(30000, n));
  else if (key === 'smpReadyTimeoutMs') config.mc.smpReadyTimeoutMs = Math.max(5000, Math.min(120000, n));
  else if (key === 'chatAlertCooldownMs') config.chatAlertCooldownMs = Math.max(250, Math.min(30000, n));
  else if (key === 'commandOutputMs') config.commandOutputMs = Math.max(1000, Math.min(15000, n));
  else if (key === 'logMaxChars') config.logMaxChars = Math.max(500, Math.min(1900, n));

  saveRuntimeConfig();
  return `Set \`${key}\` = \`${n}\`.`;
}

async function handleDiscordMessage(message) {
  if (message.author.bot) return;
  if (!message.content.startsWith('!')) return;

  if (!config.discord.owners.has(message.author.id)) {
    return message.reply('❌ You are not authorized to control this bot.');
  }

  const parts = message.content.trim().split(/\s+/);
  const command = parts.shift().toLowerCase().slice(1);
  const rest = parts.join(' ');

  if (command === 'help') {
    return message.reply([
      '**Commands**',
      '`!start` — start Minecraft bot',
      '`!stop` — disconnect so you can log in',
      '`!status` — live status and memory',
      '`!chat <text>` — send chat',
      '`!cmd <command>` — run a Minecraft command and collect output',
      '`!config` — show runtime config',
      '`!config <key> <number>` — change safe runtime setting'
    ].join('\n'));
  }

  if (command === 'start') {
    if (bot || reconnectTimer) return message.reply('🟡 Minecraft bot is already running/connecting.');
    stopping = false;
    reconnectDelay = config.reconnect.minMs;
    connectMinecraft();
    return message.reply('🟢 Minecraft bot start requested.');
  }

  if (command === 'stop') {
    stopping = true;
    if (reconnectTimer) {
      clearTimeout(reconnectTimer);
      reconnectTimer = null;
    }
    destroyBot();
    return message.reply('🔴 Minecraft bot stopped. You can log in now.');
  }

  if (command === 'status') {
    return message.reply(statusText());
  }

  if (command === 'chat') {
    if (!bot) return message.reply('❌ Minecraft bot is offline.');
    if (!rest) return message.reply('Usage: `!chat <message>`');
    if (rest.length > 256) return message.reply('❌ Chat is limited to 256 characters.');
    try {
      bot.chat(rest);
      stats.commands++;
      return message.reply(`💬 Sent: ${rest}`);
    } catch (e) {
      return message.reply(`❌ Failed: ${e.message}`);
    }
  }

  if (command === 'cmd') {
    if (!bot) return message.reply('❌ Minecraft bot is offline.');
    if (!rest) return message.reply('Usage: `!cmd <minecraft command>`');
    if (rest.length > 240) return message.reply('❌ Command is too long.');
    if (commandCollector) return message.reply('⏳ Another command is already collecting output.');
    const mcCommand = rest.startsWith('/') ? rest.slice(1) : rest;

    commandCollector = { lines: [], timer: null };
    try {
      bot.chat(`/${mcCommand}`);
      stats.commands++;
      commandCollector.timer = setTimeout(async () => {
        const result = commandCollector?.lines || [];
        commandCollector = null;
        const out = result.length ? result.join('\n') : '(no message output captured)';
        await send(config.discord.logChannelId,
          `🧾 **Command:** \`/${mcCommand}\`\n\`\`\`\n${trimDiscord(out)}\n\`\`\``);
      }, config.commandOutputMs);
      return message.reply(`⚙️ Sent \`/${mcCommand}\`; output will be posted to the log channel.`);
    } catch (e) {
      commandCollector = null;
      return message.reply(`❌ Failed: ${e.message}`);
    }
  }

  if (command === 'config') {
    if (!parts.length) {
      return message.reply([
        `viewDistance=${config.mc.viewDistance}`,
        `hubWaitMs=${config.mc.hubWaitMs}`,
        `smpReadyTimeoutMs=${config.mc.smpReadyTimeoutMs}`,
        `chatAlertCooldownMs=${config.chatAlertCooldownMs}`,
        `commandOutputMs=${config.commandOutputMs}`,
        `logMaxChars=${config.logMaxChars}`
      ].join('\n'));
    }
    if (parts.length < 2) return message.reply('Usage: `!config <key> <number>`');
    return message.reply(setRuntime(parts[0], parts[1]));
  }
}

discord.once('ready', async () => {
  console.log(`Discord ready as ${discord.user.tag}`);
  setPresence(false);
  scheduleDailyReport();
  await log(`Controller online. Target=${config.mc.host}:${config.mc.port}`);
  // Start automatically on process launch. Use !stop to release the account.
  stopping = false;
  connectMinecraft();
});

discord.on('messageCreate', msg => {
  handleDiscordMessage(msg).catch(e => console.error('Discord handler:', e));
});

discord.on('error', e => console.error('Discord client error:', e));

process.on('unhandledRejection', e => {
  stats.errors++;
  stats.lastError = e?.message || String(e);
  console.error('Unhandled rejection:', e);
});

process.on('uncaughtException', e => {
  stats.errors++;
  stats.lastError = e?.message || String(e);
  console.error('Uncaught exception:', e);
});

async function shutdown(signal) {
  if (stopping) return;
  stopping = true;
  console.log(`Shutdown: ${signal}`);
  if (reconnectTimer) clearTimeout(reconnectTimer);
  destroyBot();
  try { await discord.destroy(); } catch {}
  process.exit(0);
}

process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));

discord.login(config.discord.token).catch(e => {
  console.error('Discord login failed:', e.message);
  process.exit(1);
});
