# Lightweight Minecraft AFK + Discord Controller

A deliberately small Node.js setup for one Microsoft-authenticated Minecraft account, controlled through a Discord bot.

## What it does

- Microsoft authentication through Mineflayer device-code login.
- Connects to the Minecraft address you give it, including a FlameCord/Papyrus proxy entry point.
- Requests a **3 chunk view distance**, which targets the normal 7x7 chunk area around the player.
- Lets Minecraft's normal Mineflayer physics process server velocity/knockback packets; it does NOT add fake anti-AFK movement.
- After the first hub spawn, waits a few seconds and sends `/smp`.
- Watches for the backend transfer/spawn and configurable success phrases.
- Reconnects after kick/end/error with exponential backoff.
- Discord commands:
  - `!start`
  - `!stop`
  - `!status`
  - `!chat <message>`
  - `!cmd <minecraft command>`
  - `!config <key> [value]`
  - `!help`
- Sends hub/transfer/login/kick/error logs to a configured Discord log channel.
- Sends Minecraft player chat, mentions of the bot's in-game name, and `/tell`/private-message-like messages to a chat channel.
- Uses Discord bot Gateway/REST with channel IDs. **No Discord webhook URLs are stored or used.**
- Presence changes to `🟢 server` while connected and `🔴 server` while offline.
- Daily performance report to a Discord report channel.
- Graceful shutdown.
- Rate limits sensitive Discord commands and restricts control to `OWNER_USER_IDS`.
- Keeps only small in-memory counters; no viewer, pathfinder, database, browser, or HTTP dashboard is installed.

## Important limitation: 1.21.11 knockback

Mineflayer supports Minecraft 1.21.11, but there are known upstream reports of incorrect horizontal knockback/physics behavior on 1.21.11. This project **does not pretend to fix that**. It leaves physics enabled so ordinary server velocity packets are processed and reports velocity/physics errors if they occur.

If your server requires the bot to receive exactly vanilla horizontal knockback on 1.21.11, test that behavior before relying on it for a critical farm. A server-side/proxy workaround or a future Mineflayer physics fix may be required.

## Requirements

Recommended:
- Linux VPS
- Node.js 24 LTS
- 750 MB RAM VPS is plenty for this design, but exact usage depends on Mineflayer/world chunk data and the server. The app itself avoids memory-heavy extras.
- 1 Microsoft account that owns Minecraft Java Edition.
- A Discord application/bot with Message Content intent enabled.

Node.js 24 is the current LTS line. Mineflayer 4.38.0 supports 1.21.11. Discord.js 14.27.0 is used by this project.

## 1. Create the Discord bot

1. Open the Discord Developer Portal.
2. Create an application.
3. Add a Bot user.
4. Enable **Message Content Intent** under Privileged Gateway Intents.
5. Invite it with permissions:
   - View Channels
   - Send Messages
   - Embed Links
   - Read Message History
6. Put its token in `.env`.
7. Get your own Discord user ID and put it in `OWNER_USER_IDS`.
8. Get the IDs of the log/chat/report channels and put them in `.env`.

Do not give the bot Administrator unless you actually need it.

## 2. Install

```bash
sudo apt update
sudo apt install -y curl ca-certificates
# Install Node.js 24 using your preferred official Node.js method.
node -v
npm -v
```

Then:

```bash
mkdir -p ~/mc-bot
cd ~/mc-bot
unzip lightweight-mc-afk-discord-bot.zip
npm ci
cp .env.example .env
nano .env
```

## 3. Microsoft login

Start it:

```bash
npm start
```

The first time Mineflayer may show a Microsoft device-code login in the terminal. Open the displayed Microsoft URL on your own device and enter the code.

The authentication cache is stored under `auth-cache/`. Protect this directory:

```bash
chmod 700 auth-cache
chmod 600 .env
```

Do not send the auth-cache or `.env` to anyone.

## 4. FlameCord / Papyrus

The bot is just a Minecraft Java client. Set `MC_HOST` and `MC_PORT` to the **same public proxy address and port a normal player uses**.

Do not try to connect directly to the backend Paper server unless that is how your network is designed.

Papyrus/FlameCord does not require a special Mineflayer mode here. If the proxy performs server transfer, Mineflayer's client must handle the transfer correctly. Custom proxy/plugin messages may vary by network, so the SMP success phrases are configurable.

## 5. 7x7 chunks

`VIEW_DISTANCE=3` means a radius of 3 chunks around the client: 3 left + center + 3 right = 7 chunks per axis, i.e. up to 49 chunks in the requested square.

The actual number streamed can still be affected by the server's own view-distance, chunk sending rules, proxy/backend behavior, and unloaded/empty chunks.

## 6. Run 24/7 with systemd

Create:

`/etc/systemd/system/mc-bot.service`

```ini
[Unit]
Description=Lightweight Minecraft Discord AFK Bot
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=YOUR_LINUX_USER
WorkingDirectory=/home/YOUR_LINUX_USER/mc-bot
ExecStart=/usr/bin/node /home/YOUR_LINUX_USER/mc-bot/src/index.js
Restart=always
RestartSec=5

# Keep accidental memory growth from taking the whole VPS.
Environment=NODE_OPTIONS=--max-old-space-size=256

# Security hardening
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ProtectHome=read-only
ReadWritePaths=/home/YOUR_LINUX_USER/mc-bot/auth-cache /home/YOUR_LINUX_USER/mc-bot/logs

[Install]
WantedBy=multi-user.target
```

Replace `YOUR_LINUX_USER`.

Then:

```bash
sudo systemctl daemon-reload
sudo systemctl enable --now mc-bot
sudo systemctl status mc-bot
journalctl -u mc-bot -f
```

## Discord commands

Only IDs in `OWNER_USER_IDS` can execute control commands.

```text
!start
!stop
!status
!chat hello everyone
!cmd list
!config
!config hubWaitMs 5000
!config viewDistance 3
!help
```

`!cmd` accepts a Minecraft command without requiring a leading slash:

```text
!cmd time query daytime
```

The bot collects Minecraft `message` events for a short window and sends the output to the log channel. Some plugins/proxies may send command output in formats that cannot be reliably identified as command output; those messages are still visible to the normal Minecraft message handler.

## Config changes

`!config` changes runtime configuration and writes `config.runtime.json`.

For safety, only a small allowlist of settings can be changed through Discord:

- `viewDistance`
- `hubWaitMs`
- `smpReadyTimeoutMs`
- `chatAlertCooldownMs`
- `commandOutputMs`
- `logMaxChars`

The runtime config is intentionally not allowed to change Discord tokens, Microsoft account information, owner IDs, or server host.

Restart after changing `.env`.

## Chat alerts

The bot forwards normal Minecraft chat to the Discord chat channel.

It also highlights:
- messages containing the bot's current Minecraft username
- messages containing `@BotName`-style text
- private message formats such as `/tell`, `/msg`, `/w`, `whisper`, `->`, etc.

The alert code has a cooldown so a spammer cannot generate hundreds of Discord messages per second.

## Resource-saving design

Not installed:
- prismarine-viewer
- mineflayer-pathfinder
- mineflayer-pvp
- Express
- WebSocket dashboard
- SQLite
- Redis
- Puppeteer/Chromium
- image/map rendering

No artificial walking/jumping/anti-AFK loop is included.

## Daily report

At the configured time, the bot sends a compact report containing:
- uptime
- Minecraft connected/offline state
- reconnect count
- kicks
- errors
- chat messages seen
- command count
- approximate process RSS
- Node.js version
- current view-distance setting

The report channel acts as the lightweight dashboard. No always-on HTTP dashboard is required.

## Troubleshooting

### Bot starts but never reaches SMP
Check:
- `MC_HOST`/`MC_PORT`
- `HUB_COMMAND`
- the proxy's actual transfer behavior
- `SMP_SUCCESS_PATTERNS`
- Discord log channel

Run:

```bash
journalctl -u mc-bot -f
```

### Microsoft login keeps repeating
Do not delete `auth-cache` unless you need to reauthenticate. Make sure the Microsoft account actually owns Java Edition.

### Bot is kicked
The Discord log channel should show the kick reason. The bot will reconnect with backoff unless `!stop` was requested.

### Too much RAM
First keep `VIEW_DISTANCE=3`. Do not install a viewer/pathfinder. Check:

```bash
systemctl status mc-bot
ps -o pid,rss,cmd -C node
```

If the Mineflayer world/chunk state itself exceeds your desired budget, lowering view distance below 3 is the next lever, but that no longer satisfies the 7x7 request.

## Security

- `.env` is secret.
- `auth-cache` is secret.
- Discord control is owner-ID allowlisted.
- No webhooks.
- `!cmd` is intentionally powerful: treat the Discord owner account and bot token as privileged credentials.
- Do not paste Minecraft/Microsoft session tokens into Discord.
